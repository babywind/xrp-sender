package com.quqian.p2p.common.enums;

/**
 * 是否有效
 */
public enum IsValid {
	/**
	 * 是
	 */
	S("是"),
	/**
	 * 否
	 */
	F("否");

	protected final String name;

	private IsValid(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;

	}
}
