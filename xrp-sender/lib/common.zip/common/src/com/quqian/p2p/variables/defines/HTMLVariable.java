package com.quqian.p2p.variables.defines;

import java.io.InputStreamReader;

import com.quqian.framework.config.entity.VariableBean;
import com.quqian.p2p.variables.P2PVariableType;

public enum HTMLVariable implements VariableBean {
	/**
	 * 理财产品介绍(理财体验)
	 */
	FINANCIAL_PRODUCTS_YXLCJH("理财产品介绍(理财体验)"),
	/**
	 * 理财产品介绍(散标投资)
	 */
	FINANCIAL_PRODUCTS_SBTZ("理财产品介绍(散标投资)"),
	/**
	 * 理财产品介绍(债权转让)
	 */
	FINANCIAL_PRODUCTS_ZQZR("理财产品介绍(债权转让)"),
	/**
	 * 借款产品介绍(薪金贷)
	 */
	LOAN_PRODUCTS_XJD("借款产品介绍(薪金贷)"),
	/**
	 * 借款产品介绍(生意贷)
	 */
	LOAN_PRODUCTS_SYD("借款产品介绍(生意贷)"),
	/**
	 * 借款产品介绍(机构担保（实地认证）)
	 */
	LOAN_PRODUCTS_JGDB_SDRZ("借款产品介绍(机构担保（实地认证）)"),
	/**
	 * 关注我们HTML代码
	 */
	GZWM("关注我们"),
	/**
	 * 底部图标HTML代码
	 */
	DBTB("底部图标");

	protected final String key;
	protected final String description;

	HTMLVariable(String description) {
		StringBuilder builder = new StringBuilder(getType());
		builder.append('.').append(name());
		key = builder.toString();
		this.description = description;
	}

	@Override
	public String getType() {
		return P2PVariableType.HTML.getId();
	}

	@Override
	public String getKey() {
		return key;
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public String getValue() {
		try (InputStreamReader reader = new InputStreamReader(
				P2PVariableType.class.getResourceAsStream(getKey()), "UTF-8")) {
			StringBuilder builder = new StringBuilder();
			char[] cbuf = new char[1024];
			int len = reader.read(cbuf);
			while (len > 0) {
				builder.append(cbuf, 0, len);
				len = reader.read(cbuf);
			}
			return builder.toString();
		} catch (Throwable t) {
		}
		return null;
	}
}
