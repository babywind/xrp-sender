package com.quqian.p2p.common.enums;

/**
 * 证件类型.
 * 
 */
public enum CertificateType {
	/**
	 * 身份证
	 */
	SFZ("身份证"),
	/**
	 * 护照
	 */
	HZ("护照"),
	/**
	 * 其他证件
	 */
	QTZJ("其他证件");
	protected final String name;

	private CertificateType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;

	}
}
