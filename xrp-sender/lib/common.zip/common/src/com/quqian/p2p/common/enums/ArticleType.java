package com.quqian.p2p.common.enums;

/**
 * 文章类型.
 * 
 */
public enum ArticleType {
	/**
	 * 最新资讯
	 */
	ZXZX("最新资讯"),
	/**
	 * 名词解释
	 */
	ZCZX("众筹资讯"),
	/**
	 * 下载中心
	 */
	XZZX("下载中心");
	
	protected final String name;

	private ArticleType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;

	}
}
