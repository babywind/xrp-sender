package com.quqian.p2p.common.enums;

/**
 * 平台资金类型.
 * 
 */
public enum PlatformFundType {
	TXSXF("提现手续费"),JYSXF("交易手续费"),CZSXF("充值手续费"),ZS("虚拟币赠送"),C2CMCSXF("C2C卖出手续费");
	protected final String name;

	private PlatformFundType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;

	}
}
