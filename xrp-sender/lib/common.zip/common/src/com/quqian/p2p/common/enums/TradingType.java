package com.quqian.p2p.common.enums;

/**
 * 交易类型
 */
public enum TradingType {
			CZ("充值"), CGTX("成功提现"), TXSXF("提现手续费"),C2CMR("C2C买入"),C2CMC("C2C卖出"),C2CMCSXF("C2C卖出手续费"), CGMC("成功卖出");
	protected final String name;

	private TradingType(String name) {
		this.name = name;
	}
	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;
	}
}
