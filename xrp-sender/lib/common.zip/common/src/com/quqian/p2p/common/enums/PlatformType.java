package com.quqian.p2p.common.enums;

/**
 * 平台相关
 * 
 */
public enum PlatformType {
	/**
	 * 平台简介
	 */
	PTJJ("平台简介"),
	/**
	 * 联系我们
	 */
	LXWM("联系我们"),
	/**
	 * 平台费率
	 */
	PTFL("平台费率"),
	/**
	 * 平台简介
	 */
	PTJJ_EN("Introduction"),
	/**
	 * 联系我们
	 */
	LXWM_EN("Contract"),
	/**
	 * 平台费率
	 */
	PTFL_EN("Fee")
	;
	protected final String name;

	private PlatformType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;

	}
}
