package com.quqian.p2p.common.enums;

public enum SmsType {
	/**
	 * 移动梦网
	 */
	YDMW("移动梦网"),
	/**
	 * 诚立业
	 */
	CLY("诚立业");

	protected final String name;

	private SmsType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;
	}
}
