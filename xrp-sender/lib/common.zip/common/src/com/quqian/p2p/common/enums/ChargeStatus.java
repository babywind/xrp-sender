package com.quqian.p2p.common.enums;

/**
 * 充值状态
 */
public enum ChargeStatus {
	WZF("未支付"),CLZ("处理中"),YDZ("已到账");

	protected final String name;

	private ChargeStatus(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;
	}
}
