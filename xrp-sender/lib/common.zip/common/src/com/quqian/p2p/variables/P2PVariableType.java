package com.quqian.p2p.variables;

import com.quqian.framework.config.entity.VariableBean;
import com.quqian.framework.config.entity.VariableType;
import com.quqian.p2p.variables.defines.HTMLVariable;
import com.quqian.p2p.variables.defines.SystemVariable;

/**
 * 前台参数类型.
 * 
 */
public enum P2PVariableType implements VariableType {

	SYSTEM {
		@Override
		public String getName() {
			return "系统参数";
		}

		@Override
		public VariableBean[] getVariableBeans() {
			return SystemVariable.values();
		}

	},
	HTML {
		@Override
		public String getName() {
			return "HTML代码参数";
		}

		@Override
		public VariableBean[] getVariableBeans() {
			return HTMLVariable.values();
		}

	};
	
	@Override
	public String getId() {
		return name();
	}

}
