package com.quqian.p2p.common.enums;

/**
 * 交易类型
 */
public enum C2cType {
	MR(1, "买入"), MC(2, "卖出");

	protected final int type;
	protected final String name;

	private C2cType(int type, String name) {
		this.type = type;
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;
	}

	public int getType() {
		return type;
	}

	public static C2cType get(int type) {
		for (C2cType sexEnum : C2cType.values()) {
			if (type == sexEnum.getType()) {
				return sexEnum;
			}
		}
		return null;
	}
}
