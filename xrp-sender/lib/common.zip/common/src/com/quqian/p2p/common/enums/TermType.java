package com.quqian.p2p.common.enums;

public enum TermType {
	
	YHXY("用户协议"),
	/**
	 * 隐私政策
	 */
	YSZC("隐私政策"),
	/**
	 * 防洗钱
	 */
	FXQ("防洗钱"),
	
	YHXY_EN("Terms of Service"),
	/**
	 * 隐私政策
	 */
	YSZC_EN("Privacy Policy"),
	/**
	 * 防洗钱
	 */
	FXQ_EN("Anti-Money Laundering")
	;

	protected final String name;

	private TermType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;
	}
}
