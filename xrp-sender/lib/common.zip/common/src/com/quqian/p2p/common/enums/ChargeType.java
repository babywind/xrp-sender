package com.quqian.p2p.common.enums;

/**
 * 充值类型
 */
public enum ChargeType {
	WY("转账充值(人工到账)"),HR("网银充值(自动到账)"),USAT("USAT充值");

	protected final String name;

	private ChargeType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;
	}
}
