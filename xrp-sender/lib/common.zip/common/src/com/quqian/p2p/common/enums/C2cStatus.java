package com.quqian.p2p.common.enums;

/**
 * 交易类型
 */
public enum C2cStatus {
	CLZ(1, "处理中"), WDK(2, "未打款"),JYWC(3, "交易完成"),CXMC(4, "撤销卖出");

	protected final int type;
	protected final String name;

	private C2cStatus(int type, String name) {
		this.type = type;
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;
	}

	public int getType() {
		return type;
	}

	public static C2cStatus get(int type) {
		for (C2cStatus sexEnum : C2cStatus.values()) {
			if (type == sexEnum.getType()) {
				return sexEnum;
			}
		}
		return null;
	}
}
