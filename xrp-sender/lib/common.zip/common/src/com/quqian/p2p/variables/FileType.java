package com.quqian.p2p.variables;

import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;

/**
 * 上传文件类型.
 */
public enum FileType {
	/**
	 * 文章封面图片
	 */
	ARTICLE_IMAGE,
	/**
	 * 文章附件
	 */
	ARTICLE_ATTACHMENT,
	/**
	 * 广告图片类型
	 */
	ADVERTISEMENT_IMAGE,
	/**
	 * 客服图片类型
	 */
	CUSTOMER_SERVICE_IMAGE,
	/**
	 * 合作伙伴图片类型
	 */
	PARTNER_IMAGE,
	/**
	 * 虚拟币类型图片
	 */
	VIRTUAL_CURRENCY_IMAGE,
	/**
	 * 证件类型图片
	 */
	CERTIFICATE_IMAGE;
	
}
