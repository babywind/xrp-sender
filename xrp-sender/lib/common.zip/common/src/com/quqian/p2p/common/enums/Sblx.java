package com.quqian.p2p.common.enums;

/**
 * 设备类型
 */
public enum Sblx {
	/**
	 * 电脑版
	 */
	PC("电脑版"),
	/**
	 * 手机版
	 */
	WAP("手机版");

	protected final String name;

	private Sblx(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;

	}
}
