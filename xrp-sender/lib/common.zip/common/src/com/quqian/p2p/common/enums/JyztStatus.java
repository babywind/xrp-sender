package com.quqian.p2p.common.enums;

/**
 * 交易类型
 */
public enum JyztStatus {
	MR("买入"), MC("卖出"),MRMC("买/卖");

	protected final String name;

	private JyztStatus(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;
	}
}
