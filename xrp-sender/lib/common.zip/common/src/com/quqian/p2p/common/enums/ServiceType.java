package com.quqian.p2p.common.enums;

/**
 * 服务支持
 * 
 */
public enum ServiceType {
	/**
	 * 商务合作
	 */
	SWHZ("商务合作"),
	/**
	 * API支持
	 */
	APIZC("API支持"),
	/**
	 * 商务合作
	 */
	SWHZ_EN("Business"),
	/**
	 * API支持
	 */
	APIZC_EN("API")
	;
	protected final String name;

	private ServiceType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;

	}
}
