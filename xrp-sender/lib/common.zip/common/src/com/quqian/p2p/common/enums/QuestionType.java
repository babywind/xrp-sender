package com.quqian.p2p.common.enums;

public enum QuestionType {

	/**
	 * 注册登录
	 */
	ZCDL("账户问题"),
	/**
	 * 密码安全
	 */
	/*MMAQ("密码安全"),*/
	/**
	 * 实名认证
	 */
	/*SMRZ("实名认证"),*/
	/**
	 * 充值提现
	 */
	CZTX("充值提现"),
	/**
	 * 转入转出
	 */
	ZRZC("转入转出"),
	/**
	 * 关于交易
	 */
	GYJY("关于交易");

	protected final String name;

	private QuestionType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;

	}
}
