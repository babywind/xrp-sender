package com.quqian.p2p.variables.defines;

import java.io.InputStreamReader;

import com.quqian.framework.config.entity.VariableBean;
import com.quqian.p2p.variables.P2PVariableType;

public enum SystemVariable implements VariableBean {

	/**
	 * 验证码加密串
	 */
	YZMJMC("验证码加密串") {
		@Override
		public String getValue() {
			return "XXXXXX";
		}
	},
	/**
	 * 网站授权加密串
	 */
	SITE_ACCREDIT_KEY("网站授权加密串") {
		@Override
		public String getValue() {
			return "XXXXXX";
		}
	},
	/**
	 * 网站名称
	 */
	SITE_NAME("网站名称") {
		@Override
		public String getValue() {
			return "${SYSTEM.SITE_NAME}";//"趣钱网贷";
		}
	},
	/**
	 * 网站域名
	 */
	SITE_DOMAIN("网站域名") {
		@Override
		public String getValue() {
			return "${SYSTEM.SITE_DOMAIN}";//www.quqian.com
		}
	},
	/**
	 * WAP网站域名
	 */
	WAP_DOMAIN("WAP网站域名") {
		@Override
		public String getValue() {
			return "${SYSTEM.WAP_DOMAIN}";//tm.quqian.com
		}
	},

	/**
	 * 网站版权信息
	 */
	SITE_COPYRIGTH("网站版权信息") {
		@Override
		public String getValue() {
			return "© 2014 ${SYSTEM.SITE_DOMAIN} All Rights Reserved ";
		}
	},
	/**
	 * 网站备案号
	 */
	SITE_FILING_NUM("网站备案号") {
		@Override
		public String getValue() {
			return "${SYSTEM.SITE_FILING_NUM}";//"粤ICP备88888888号";
		}
	},
	/**
	 * 客服电话
	 */
	SITE_CUSTOMERSERVICE_TEL("客服电话") {
		@Override
		public String getValue() {
			return "${SYSTEM.SITE_CUSTOMERSERVICE_TEL}";//"400-8888 8888";
		}
	},
	/**
	 * 网站口号
	 */
	SITE_WORD("网站口号") {
		@Override
		public String getValue() {
			return "${SYSTEM.SITE_WORD}";//赚钱是一件有趣的事
		}
	},
	/**
	 * 赠送虚拟币
	 */
	SMS_ZS_XNB("赠送虚拟币") {
		@Override
		public String getValue() {
			return "尊敬的%s用户，您于%s在%s获得赠送%s，感谢您的使用";
		}
	},
	/**
	 * 邮编
	 */
	SITE_POSTCODE("邮编") {
		@Override
		public String getValue() {
			return "{SYSTEM.SITE_POSTCODE}";//"518000";
		}
	},
	/**
	 * 网站Meta关键字
	 */
	SITE_META_KEYWORDS("网站Meta关键字"),
	/**
	 * 网站Meta描述
	 */
	SITE_META_DESC("网站Meta关键字"),
	/**
	 * 新浪微博
	 */
	SITE_SINA_WEIBO("新浪微博") {
		@Override
		public String getValue() {
			return "${SYSTEM.SITE_SINA_WEIBO}";//"http://weibo.com/quqianwang";
		}
	},
	/**
	 * 工作时间
	 */
	SITE_WORK_TIME("工作时间") {
		@Override
		public String getValue() {
			return "${SYSTEM.SITE_WORK_TIME}";//"GMT+7 9:00 - 21:00境内汇款";
		}
	},
	/**
	 * sitemap存放地址
	 */
	SITEMAP_PATH("sitemap存放地址") {
		@Override
		public String getValue() {
			return "/home/webapps/quqian/front/current/sitemap.xml";
		}
	},
	/**
	 * 充值最低金额(美元)
	 */
	CHARGE_MIN_AMOUNT("充值最低金额(美元)") {
		@Override
		public String getValue() {
			return "${SYSTEM.CHARGE_MIN_AMOUNT}";//"100";
		}
	},
	/**
	 * 提现最高金额（美元）
	 */
	WITHDRAW_MAX_FUNDS("提现最高金额（美元）") {
		@Override
		public String getValue() {
			return "${SYSTEM.WITHDRAW_MAX_FUNDS}";//"200000";
		}
	},
	/**
	 * 用户每日提现限额
	 */
	WIDTHDRAW_PER_LIMIT("用户每日提现限额") {
		@Override
		public String getValue() {
			return "${SYSTEM.WIDTHDRAW_PER_LIMIT}";//"200000";
		}
	},
	/**
	 * 提现最低金额（美元）
	 */
	WITHDRAW_MIN_FUNDS("提现最低金额（美元）") {
		@Override
		public String getValue() {
			return "${SYSTEM.WITHDRAW_MIN_FUNDS}";//"100";
		}
	},
	/**
	 * 提现费率
	 */
	WITHDRAW_FV("提现费率") {
		@Override
		public String getValue() {
			return "${SYSTEM.WITHDRAW_FV}";//"0.3";
		}
	},
	/**
	 * 提现最低金额（美元）
	 */
	WITHDRAW_MIN_SXF("提现最低手续费") {
		@Override
		public String getValue() {
			return "${SYSTEM.WITHDRAW_MIN_SXF}";//"2";
		}
	},
	/**
	 * 短信认证次数
	 */
	DX_RZCS("短信认证次数") {
		@Override
		public String getValue() {
			return "${SYSTEM.DX_RZCS}";//"10";
		}
	},

	/**
	 * 平台所属公司名称
	 */
	COMPANY_NAME("平台所属公司名") {
		@Override
		public String getValue() {
			return "${SYSTEM.COMPANY_NAME}";//"深圳前海齐融金融服务有限公司";
		}
	},
	/**
	 * 平台所属公司地址
	 */
	COMPANY_ADDRESS("平台所属公司地址") {
		@Override
		public String getValue() {
			return "${SYSTEM.COMPANY_ADDRESS}";//"深圳市南山区高新科技园高新中三道7号 劲嘉科技大厦21楼";
		}
	},
	/**
	 * 提现密码最大输入次数
	 */
	WITHDRAW_MAX_INPUT("提现密码最大输入次数") {
		@Override
		public String getValue() {
			return "10";
		}
	},
	/**
	 * 短信通道，1移动梦网、诚立业；2云之讯;
	 */
	MSG_CHANNEL("短信通道") {
		@Override
		public String getValue() {
			return "${SYSTEM.MSG_CHANNEL}";//"1";
		}
	},
	/**
	 * 短信通道1_走向，移动梦网(YDMW),诚立业(CLY);
	 */
	MSG_CHANNEL1_ZX("短信通道1_走向") {
		@Override
		public String getValue() {
			return "${SYSTEM.MSG_CHANNEL1_ZX}";//"YDMW";
		}
	},
	/**
	 * 会员群号
	 */
	QQ_HYQ_1("会员群号") {
		@Override
		public String getValue() {
			return "${SYSTEM.QQ_HYQ_1}";//"471227380";
		}

	},
	/**
	 * 官方账号
	 */
	CHARGE_GFZH("官方账号") {
		@Override
		public String getValue() {
			return "${SYSTEM.CHARGE_GFZH}";//"2402045509200060376";
		}
	},
	/**
	 * 开户名称
	 */
	CHARGE_KHMC("开户名称") {
		@Override
		public String getValue() {
			return "${SYSTEM.CHARGE_KHMC}";//"贵阳资汇通电子商务有限公司";
		}
	},
	/**
	 * 开户名称
	 */
	CHARGE_KHDZ("开户地址") {
		@Override
		public String getValue() {
			return "${SYSTEM.CHARGE_KHDZ}";//"中国工商银行贵阳军区支行";
		}
	},
	/**
	 * 注册验证
	 */
	SMS_ZC("注册验证") {//注册短信
		@Override
		public String getValue() {
			return "感谢您注册"+SystemVariable.SITE_NAME_EN+"，您的验证码是SMS_ZC";//短信验证码
		}
	},
	/**
	 * 提币验证
	 */
	SMS_TB("提币验证") {//提币短信
		@Override
		public String getValue() {
			return "尊敬的"+SystemVariable.SITE_NAME_EN+"用户，您的提币验证码是:SMS_TB";//短信验证码
		}
	},
	/**
	 * 提现短信
	 */
	SMS_TX("提现短信") {
		@Override
		public String getValue() {
			return "尊敬的"+SystemVariable.SITE_NAME_EN+"用户，您的提现验证码是:SMS_TX";//短信验证码
		}
	},
	/**
	 * C2C卖出短信
	 */
	SMS_C2CMC("C2C卖出短信") {
		@Override
		public String getValue() {
			return "尊敬的用户您好！C2C卖出验证码：SMS_C2CMC，验证码有效时间：10分钟。请勿向任何人包括客服提供验证码。";//短信验证码,10分钟有效
			
		}
	},
	/**
	 * 
	 */
	SMS_WJMM("忘记密码验证") {//忘记密码短信
		@Override
		public String getValue() {
			return "尊敬的"+SystemVariable.SITE_NAME_EN+"用户，您的找回密码验证码是:SMS_WJMM";//短信验证码
		}
	},
	/**
	 * 充值
	 */
	SMS_CZ("充值") {
		@Override
		public String getValue() {
			return "尊敬的%s用户，您于%s在%s充值%s美元，感谢您的使用";
		}
	},
	/**
	 * 提现
	 */
	SMS_TX_JE("提现") {
		@Override
		public String getValue() {
			return "尊敬的%s用户，您于%s在%s提现%s美元，感谢您的使用";
		}
	},
	/**
	 * 转入
	 */
	SMS_ZR("转入") {
		@Override
		public String getValue() {
			return "尊敬的%s用户，您于%s在%s转入%s枚%s，感谢您的使用。";
		}
	},
	/**
	 * 转出
	 */
	SMS_ZC_JE("转出") {
		@Override
		public String getValue() {
			return "尊敬的%s用户，您于%s在%s转出%s枚%s，感谢您的使用。";
		}
	},
	/**
	 * 修改密码验证
	 */
	SMS_XJMM("修改密码验证") {//修改密码短信
		@Override
		public String getValue() {
			return "尊敬的%s用户，您于%s在%s进行修改密码操作，请保护信息安全。";
		}
	},
	/**
	 * 实名认证通过
	 */
	SMS_GJSMRZTG("实名认证通过") {
		@Override
		public String getValue() {
			return "尊敬的%s用户，您的高级实名认证已经通过，感谢你的使用。";
		}
	},
	/**
	 * 实名认证驳回
	 */
	SMS_GJSMRZBH("实名认证驳回") {
		@Override
		public String getValue() {
			return "尊敬的%s用户，由于您上传的照片不符合要求，实名认证未被通过，请按要求重新上传，如有问题请系客服。";
		}
	},
	/**
	 * 提现驳回
	 */
	SMS_TXSB("提现驳回") {
		@Override
		public String getValue() {
			return "尊敬的%s用户，您于%s在%s 提现 %s的申请未通过审核，具体原因请咨询客服，感谢您的使用。";
		}
	}
	,
	/**
	 * 虚拟币转出驳回
	 */
	SMS_XLBZCBH("虚拟币转出驳回") {
		@Override
		public String getValue() {
			return "尊敬的%s用户，您于%s在%s转出%s枚%s的申请未通过审核，具体原因请咨询客服，感谢您的使用。";
		}
	},
	/**
	 * 华融支付PC手续费率
	 */
	HR_PC_SXF("华融支付PC手续费率") {
		@Override
		public String getValue() {
			return "${SYSTEM.HR_PC_SXF}";//"0.0016";
		}
	},
	/**
	 * 网站前台域名
	 */
	FRONT_SITE_DOMAIN("网站前台域名") {
		@Override
		public String getValue() {
			return "${SYSTEM.FRONT_SITE_DOMAIN}";//https://www.z-trade.com
		}
	},
	/**
	 * 华融支付页面通知地址
	 */
	HR_PC_RETURNURL("华融支付页面通知地址") {
		@Override
		public String getValue() {
			return "http://${SYSTEM.FRONT_SITE_DOMAIN}/pay/hr/hyPcReturnurl.htm";
		}
	},
	/**
	 * 华融支付异步通知地址
	 */
	HR_PC_NOTIFYURL("华融支付异步通知地址") {
		@Override
		public String getValue() {
			return "http://${SYSTEM.FRONT_SITE_DOMAIN}/pay/hr/hyPcNotifyurl.htm";
		}
	},
	/**
	 * 支付地址入口
	 */
	PAY_INDEX("支付地址入口") {
		@Override
		public String getValue() {
			return "http://${SYSTEM.FRONT_SITE_DOMAIN}/pay/";
		}
	},
	/**
	 * 客服QQ
	 */
	KF_QQ_1("客服QQ1") {
		@Override
		public String getValue() {
			return "${SYSTEM.KF_QQ_1}";//"2023577399";
		}
	},
	/**
	 * 客服QQ
	 */
	KF_QQ_2("客服QQ2") {
		@Override
		public String getValue() {
			return "${SYSTEM.KF_QQ_2}";//"3273585845";
		}
	},
	/**
	 * 商务邮箱
	 */
	SWYX("商务邮箱") {
		@Override
		public String getValue() {
			return "${SYSTEM.SWYX}";//services@z-trade.com
		}
	},
	/**
	 *推荐佣金比例
	 */
	WITHDRAW_YJ("推荐佣金比例") {
		@Override
		public String getValue() {
			return "${SYSTEM.WITHDRAW_YJ}";//"0.01";
		}
	},
	/**
	 * CHINA8PAY_PC手续费率
	 */
	CHINA8PAY_PC_SXF("CHINA8PAY_PC手续费率") {
		@Override
		public String getValue() {
			return "${SYSTEM.CHINA8PAY_PC_SXF}";//"0.0016";
		}
	},
	/**
	 * USDT买入费率（元）
	 */
	USDT_MR_FV("USDT买入费率") {
		@Override
		public String getValue() {
			return "${SYSTEM.USDT_MR_FV}";//"6.7";
		}
	},
	/**
	 * USDT卖出费率（元）
	 */
	USDT_MC_FV("USDT卖出费率") {
		@Override
		public String getValue() {
			return "${SYSTEM.USDT_MC_FV}";//"6.63";
		}
	}
	,
	/**
	 * USDT买入最小数量
	 */
	USDT_MR_MIN("USDT买入最小数量") {
		@Override
		public String getValue() {
			return "${SYSTEM.USDT_MR_MIN}";//"100";
		}
	},
	/**
	 * USDT最小数量
	 */
	USDT_MC_MIN("USDT卖出最小数量") {
		@Override
		public String getValue() {
			return "${SYSTEM.USDT_MC_MIN}";//"50";
		}
	},
	/**
	 * 网站中文名
	 */
	SITE_NAME_CN("网站中文名") {
		@Override
		public String getValue() {
			return "${SYSTEM.SITE_NAME_CN}";//替换常量“亚泰经合”
		}
	},
	/**
	 * 网站英文名
	 */
	SITE_NAME_EN("网站英文名") {
		@Override
		public String getValue() {
			return "${SYSTEM.SITE_NAME_EN}";//替换常量“ADCEX”
		}
	},//adcex
	/**
	 * 网站英文名二
	 */
	SITE_NAME_EN2("网站英文名2") {
		@Override
		public String getValue() {
			return "${SYSTEM.TITLE_EN2}";//替换常量“adcex”
		}
	},
	/**
	 * 网站关键字_中文
	 */
	SITE_KEYWORDS_CN("网站关键字-中文") {
		@Override
		public String getValue() {
			return "${SYSTEM.SITE_KEYWORDS_CN}";
		}
	},
	/**
	 * 网站关键字_英文
	 */
	SITE_KEYWORDS_EN("网站关键字-英文") {
		@Override
		public String getValue() {
			return "${SYSTEM.SITE_KEYWORDS_EN}";//SITE_META_KEYWORDS
		}
	},
	/**
	 * 网站币种简称
	 */
	COIN_NAME("网站币种简称") {
		@Override
		public String getValue() {
			return "${SYSTEM.COIN_NAME}";//
		}
	},
	/**
	 * 网站描述-中文
	 */
	SITE_DESCRIPTION_CN("网站描述-中文") {
		@Override
		public String getValue() {
			return "${SYSTEM.SITE_DESCRIPTION_CN}";//网站描述-中文
		}
	},
	/**
	 * 网站描述-英文
	 */
	SITE_DESCRIPTION_EN("网站描述-英文") {
		@Override
		public String getValue() {
			return "${SYSTEM.SITE_DESCRIPTION_EN}";//网站描述-英文
		}
	},
	/**
	 * 谷歌认证介绍-中文
	 */
	GGRZ_INTRO_CN("谷歌认证中文介绍") {
		@Override
		public String getValue() {
			return "${SYSTEM.GGRZ_INTRO_CN}";//谷歌认证介绍
		}
	},
	/**
	 * 谷歌认证介绍-英文
	 */
	GGRZ_INTRO_EN("谷歌认证英文介绍") {
		@Override
		public String getValue() {
			return "${SYSTEM.GGRZ_INTRO_EN}";//谷歌认证介绍
		}
	},
	/**
	 * 邮件报告收件人
	 */
	REPORT_TO_EMAIL("邮件报告收件人") {
		@Override
		public String getValue() {
			return "${SYSTEM.REPORT_TO_EMAIL}";//异常报告收件箱
		}
	},
	
	/**
	 * 节点同步区块高度的时间差
	 */
	SYNCH_BLOCKNUMBER_TIME_DIFFERENCE("节点同步区块高度的时间差") {
		@Override
		public String getValue() {
			return "${SYSTEM.SYNCH_BLOCKNUMBER_TIME_DIFFERENCE}";//节点同步区块高度的时间差
		}
	},
	
	/**
	 * 节点解析区块高度时间差
	 */
	ANALYSIS_BLOCKNUMBER_TIME_DIFFERENCE("节点解析高度时间差") {
		@Override
		public String getValue() {
			return "${SYSTEM.ANALYSIS_BLOCKNUMBER_TIME_DIFFERENCE}";//节点解析高度时间差
		}
	},
	 
	 /**
		 * 设定节点同步区块高度的差值
		 */
	SYNCH_BLOCKNUMBER_HEIGHT_DIFFERENCE("设定监测节点同步高度差") {
			@Override
			public String getValue() {
				return "${SYSTEM.SYNCH_BLOCKNUMBER_HEIGHT_DIFFERENCE}";//设定监测节点同步高度差
			}
		},
		 
	  /**
		* 设定节点解析区块高度的差值
		*/
	ANALYSIS_BLOCKNUMBER_HEIGHT_DIFFERENCE("设定监测解析高度差") {
			@Override
			public String getValue() {
				return "${SYSTEM.ANALYSIS_BLOCKNUMBER_HEIGHT_DIFFERENCE}";//设定监测解析高度差
			}
		},
	
	/**
	 * 区块同步异常邮件报告收件人
	 */
	BLOCK_EXCEPTION_EMAIL("区块同步异常邮件报告收件人") {
		@Override
		public String getValue() {
			return "${SYSTEM.BLOCK_EXCEPTION_EMAIL}";//区块同步异常邮件报告收件人
		}
	},

	/**
	 * c2c新旧版本配置
	 */
	C2C_TYPE_CONFIG("c2c新旧版本配置") {
		@Override
		public String getValue() {
			return "${SYSTEM.C2C_TYPE_CONFIG}";//c2c新旧版本配置
		}
	},
	/**
	 * c2c加密用户名的key
	 */
	C2C_KEY("c2c加密用户名的key") {
		@Override
		public String getValue() {
			return "${SYSTEM.C2C_KEY}";//c2c加密用户名的key
		}
	};
	protected final String key;
	protected final String description;

	SystemVariable(String description) {
		StringBuilder builder = new StringBuilder(getType());
		builder.append('.').append(name());
		key = builder.toString();
		this.description = description;
	}

	@Override
	public String getType() {
		return P2PVariableType.SYSTEM.getId();
	}

	@Override
	public String getKey() {
		return key;
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public String getValue() {
		try (InputStreamReader reader = new InputStreamReader(P2PVariableType.class.getResourceAsStream(getKey()),
				"UTF-8")) {
			StringBuilder builder = new StringBuilder();
			char[] cbuf = new char[1024];
			int len = reader.read(cbuf);
			while (len > 0) {
				builder.append(cbuf, 0, len);
				len = reader.read(cbuf);
			}
			return builder.toString();
		} catch (Throwable t) {
		}
		return null;
	}
}
