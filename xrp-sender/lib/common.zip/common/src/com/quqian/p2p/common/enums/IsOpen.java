package com.quqian.p2p.common.enums;

/**
 * 启用状态
 */
public enum IsOpen {
	/**
	 * 启用
	 */
	S("启用"),
	/**
	 * 禁用
	 */
	F("禁用");

	protected final String name;

	private IsOpen(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;

	}
}
