package com.quqian.p2p.common.enums;

public enum EtherenumAppleTpye {
	WZB("未转币"), CG("成功"), SB("失败"), RQB("已转到热钱包");

	protected final String name;

	private EtherenumAppleTpye(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;
	}
}
