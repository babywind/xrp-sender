package com.quqian.p2p.common.enums;

/**
 * 
 * 语言类型
 * 
 */
public enum LanguageType {
	/**
	 * 英文
	 */
	en("English"),
	/**
	 * 中文简体
	 */
	cn("中文简体");
	protected final String name;

	private LanguageType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;
	}
}
