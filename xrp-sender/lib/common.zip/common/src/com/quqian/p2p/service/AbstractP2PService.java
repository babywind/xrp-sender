package com.quqian.p2p.service;

import com.quqian.framework.service.AbstractService;
import com.quqian.framework.service.ServiceResource;

public abstract class AbstractP2PService extends AbstractService {

	public AbstractP2PService(ServiceResource serviceResource) {
		super(serviceResource);
	}

}
