package com.quqian.p2p.common.enums;

/**
 * 虚拟币类型.
 * 
 */
public enum XlbType {
	ZR("转入"), ZC("转出"),BD("补单"),TBSXF("提币手续费"),ZCJS("注册奖励88枚SWT"),ZCZS("注册赠送");
	protected final String name;

	private XlbType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;

	}
}
