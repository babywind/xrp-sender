package com.quqian.p2p.common.enums;

/**
 * 交易类型
 */
public enum EntrustType {
	JYZ("交易中"), YWC("已完成"), YCX("已撤销");

	protected final String name;

	private EntrustType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;
	}
}
