package com.quqian.p2p.common.enums;

/**
 * 平台虚拟币类型.
 * 
 */
public enum PtXlbType {
	TBSXF("提币手续费"),BDFHSXF("补单返还手续费"),ZCJS("注册奖励88枚SWT");
	protected final String name;

	private PtXlbType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;

	}
}
