package com.quqian.p2p.common.enums;

/**
 * 交易密码输入设置类型
 * 
 */
public enum JymmType {
	/**
	 * 每次交易都不需要输入交易密码
	 */
	MCJY("每次交易都不需要输入交易密码"),
	/**
	 * 每笔交易都输入交易密码
	 */
	MBJY("每笔交易都输入交易密码");
	protected final String name;

	private JymmType(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;

	}
}
