package com.quqian.p2p.common.enums;

/**
 *币转出状态
 *
 */
public enum XlbZcStatus {
	WSH("未审核"),SHTG("审核通过"),SHSB("审核失败"),ZCCG("转出成功"), ZCSB("转出失败");

	protected final String name;

	private XlbZcStatus(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;
	}
}
