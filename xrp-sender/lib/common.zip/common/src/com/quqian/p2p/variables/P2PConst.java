package com.quqian.p2p.variables;

public interface P2PConst {
	/**
	 * 主库连接器名称
	 */
	public static final String DB_MASTER_PROVIDER = "db.master.provider";
	/**
	 * 配置库
	 */
	public static final String DB_CONFIG = "ZCH_S10";
	/**
	 * 后台会话信息库
	 */
	public static final String DB_CONSOLE_SESSION = "ZCH_S10";
	/**
	 * 用户会话信息库
	 */
	public static final String DB_USER_SESSION = "ZCH_S11";
	/**
	 * 资讯库
	 */
	public static final String DB_INFORMATION = "ZCH_S50";
	/**
	 * 用户资料库
	 */
	public static final String DB_USER = "ZCH_S60";
	/**
	 * 后台库
	 */
	public static final String DB_CONSOLE = "ZCH_S70";

}
