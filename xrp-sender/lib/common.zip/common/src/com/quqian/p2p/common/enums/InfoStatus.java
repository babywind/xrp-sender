package com.quqian.p2p.common.enums;

/**
 * 消息状态.
 * 
 */
public enum InfoStatus {
	/**
	 * 未读
	 */
	WD("未读"),
	/**
	 * 已读
	 */
	YD("已读");

	protected final String name;

	private InfoStatus(String name) {
		this.name = name;
	}

	/**
	 * 获取中文名称.
	 * 
	 * @return {@link String}
	 */
	public String getName() {
		return name;

	}
}
