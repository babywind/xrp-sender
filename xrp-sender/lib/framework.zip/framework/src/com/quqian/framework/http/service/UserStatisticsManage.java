package com.quqian.framework.http.service;

import com.quqian.framework.service.Service;

import java.sql.Date;

public abstract interface UserStatisticsManage extends Service
{
  public abstract int getLoginCount(Date paramDate)
    throws Throwable;

  public abstract int getOnlineCount()
    throws Throwable;

  public abstract int[] getOnlineHistory(Date paramDate)
    throws Throwable;

  public abstract int getLoginCount(Date paramDate, String paramString)
    throws Throwable;

  public abstract int getOnlineCount(String paramString)
    throws Throwable;

  public abstract int[] getOnlineHistory(Date paramDate, String paramString)
    throws Throwable;
}