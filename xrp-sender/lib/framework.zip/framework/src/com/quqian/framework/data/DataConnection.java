package com.quqian.framework.data;

public abstract interface DataConnection extends AutoCloseable
{
}