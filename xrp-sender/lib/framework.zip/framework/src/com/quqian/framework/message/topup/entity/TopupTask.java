package com.quqian.framework.message.topup.entity;

import java.io.Serializable;
import java.math.BigDecimal;

public class TopupTask implements Serializable {
	private static final long serialVersionUID = 1L;
	public long id;
	public BigDecimal je;
	public String sjh;
	public String no;
}
