package com.quqian.framework.service;

import com.quqian.framework.resource.Resource;
import com.quqian.framework.resource.ResourceInvalidatedException;
import com.quqian.framework.resource.ResourceNotFoundException;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.framework.service.exception.ServiceNotFoundException;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collection;

public abstract interface ServiceResource extends ServiceSession, ResourceProvider
{
  public abstract <R extends Resource> R getResource(Class<R> paramClass)
    throws ResourceNotFoundException;

  /** @deprecated */
  public abstract <S extends Service> S getService(Class<S> paramClass)
    throws ServiceNotFoundException, ResourceInvalidatedException;

  public abstract void setParameters(PreparedStatement paramPreparedStatement, Collection<Object> paramCollection)
    throws SQLException;

  public abstract void setParameters(PreparedStatement paramPreparedStatement, Object[] paramArrayOfObject)
    throws SQLException;
}