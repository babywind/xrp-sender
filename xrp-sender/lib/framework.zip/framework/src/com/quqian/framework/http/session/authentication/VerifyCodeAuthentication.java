package com.quqian.framework.http.session.authentication;

import java.io.Serializable;

public class VerifyCodeAuthentication
  implements Serializable
{
  private static final long serialVersionUID = 271402867515240680L;
  protected String verifyCode;
  protected String verifyCodeType;

  public String getVerifyCode()
  {
    return verifyCode;
  }

  public void setVerifyCode(String verifyCode) {
    this.verifyCode = verifyCode;
  }

  public String getVerifyCodeType() {
    return verifyCodeType;
  }

  public void setVerifyCodeType(String verifyCodeType) {
    this.verifyCodeType = verifyCodeType;
  }
}