package com.quqian.framework.message.sms;

import com.quqian.framework.message.sms.entity.SmsTask;
import com.quqian.framework.service.Service;
import com.quqian.framework.service.query.Paging;
import com.quqian.framework.service.query.PagingResult;

public abstract interface SmsManage extends Service
{
  public abstract PagingResult<SmsTask> searchUnsendTask(SendTaskQuery paramSendTaskQuery, Paging paramPaging)
    throws Throwable;

  public abstract PagingResult<SmsTask> searchSendTask(SendTaskQuery paramSendTaskQuery, Paging paramPaging)
    throws Throwable;

  public static abstract interface SendTaskQuery
  {
    public abstract int getId();

    public abstract int getType();

    public abstract String getMessage();

    public abstract String getStatus();
  }
}