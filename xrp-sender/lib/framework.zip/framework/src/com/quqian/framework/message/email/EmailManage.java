package com.quqian.framework.message.email;

import com.quqian.framework.message.email.entity.EmailTask;
import com.quqian.framework.service.Service;
import com.quqian.framework.service.query.Paging;
import com.quqian.framework.service.query.PagingResult;

public abstract interface EmailManage extends Service
{
  public abstract PagingResult<EmailTask> searchUnsendTask(EmailTaskQuery paramEmailTaskQuery, Paging paramPaging)
    throws Throwable;

  public abstract PagingResult<EmailTask> searchSendTask(EmailTaskQuery paramEmailTaskQuery, Paging paramPaging)
    throws Throwable;

  public static abstract interface EmailTaskQuery
  {
    public abstract int getId();

    public abstract int getType();

    public abstract String getSubject();

    public abstract String getContent();

    public abstract String getStatus();
  }
}