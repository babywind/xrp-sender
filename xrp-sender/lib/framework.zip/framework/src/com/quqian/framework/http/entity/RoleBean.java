package com.quqian.framework.http.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public abstract interface RoleBean extends Serializable
{
  public abstract int getRoleId();

  public abstract String getName();

  public abstract String getDescription();

  public abstract Timestamp getCreateTime();

  public abstract int getCreaterId();

  public abstract String getStatus();
}