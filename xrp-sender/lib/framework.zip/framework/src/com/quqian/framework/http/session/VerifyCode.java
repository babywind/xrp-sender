package com.quqian.framework.http.session;

public abstract interface VerifyCode
{
  public abstract String getDisplayValue();

  public abstract String getMatchValue();
}