package com.quqian.framework.service.achieve;

import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.config.entity.ModuleBean;
import com.quqian.framework.data.DataConnectionProvider;
import com.quqian.framework.data.sql.SQLConnection;
import com.quqian.framework.data.sql.SQLConnectionProvider;
import com.quqian.framework.http.entity.RightBean;
import com.quqian.framework.http.servlet.Controller;
import com.quqian.framework.http.session.Session;
import com.quqian.framework.log.Logger;
import com.quqian.framework.resource.InitParameterProvider;
import com.quqian.framework.resource.NamedResource;
import com.quqian.framework.resource.PromptLevel;
import com.quqian.framework.resource.Prompter;
import com.quqian.framework.resource.Resource;
import com.quqian.framework.resource.ResourceAnnotation;
import com.quqian.framework.resource.ResourceInvalidatedException;
import com.quqian.framework.resource.ResourceNotFoundException;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.framework.resource.ResourceRetention;
import com.quqian.framework.service.Service;
import com.quqian.framework.service.ServiceFactory;
import com.quqian.framework.service.ServiceProvider;
import com.quqian.framework.service.ServiceResource;
import com.quqian.framework.service.ServiceSession;
import com.quqian.framework.service.achieve.proxy.SQLConnectionProviderProxy;
import com.quqian.framework.service.achieve.proxy.SQLConnectionProxy;
import com.quqian.framework.service.exception.ServiceNotFoundException;
import com.quqian.util.StringHelper;

import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

@ResourceAnnotation
public class SimpleServiceProvider extends ServiceProvider {
	protected static final Map<Class<?>, ParameterSetter> SETTERS = new HashMap();
	protected static final ParameterSetter INPUTSTREAM_SETTER = new ParameterSetter() {
		public void set(PreparedStatement pstmt, int parameterIndex,
				Object parameter) throws SQLException {
			pstmt.setBlob(parameterIndex, (InputStream) parameter);
		}
	};

	protected static final ParameterSetter ENUM_SETTER = new ParameterSetter() {
		public void set(PreparedStatement pstmt, int parameterIndex,
				Object parameter) throws SQLException {
			pstmt.setString(parameterIndex, ((Enum) parameter).name());
		}
	};

	protected static final ParameterSetter READER_SETTER = new ParameterSetter() {
		public void set(PreparedStatement pstmt, int parameterIndex,
				Object parameter) throws SQLException {
			pstmt.setClob(parameterIndex, (Reader) parameter);
		}
	};

	protected static final ParameterSetter BYTES_SETTER = new ParameterSetter() {
		public void set(PreparedStatement pstmt, int parameterIndex,
				Object parameter) throws SQLException {
			pstmt.setBytes(parameterIndex, (byte[]) parameter);
		}
	};

	protected final Map<Type, ServiceFactory<? extends Service>> serviceFactories = new HashMap();
	protected final Map<Type, Class<? extends ServiceFactory<?>>> serviceFactoryClasses = new HashMap();

	protected static void register(ParameterSetter setter, Class<?>[] types) {
		for (Class type : types)
			SETTERS.put(type, setter);
	}

	protected static ParameterSetter getSetter(Class<?> type) {
		ParameterSetter setter = (ParameterSetter) SETTERS.get(type);
		if (setter == null) {
			if (type.isArray()) {
				if ((type.getComponentType() == Byte.TYPE)
						|| (type.getComponentType() == Byte.class)) {
					setter = BYTES_SETTER;
				} else
					throw new RuntimeException("");
			} else if (Reader.class.isAssignableFrom(type))
				setter = READER_SETTER;
			else if (InputStream.class.isAssignableFrom(type))
				setter = INPUTSTREAM_SETTER;
			else if (Enum.class.isAssignableFrom(type)) {
				setter = ENUM_SETTER;
			}
		}
		return setter;
	}

	public SimpleServiceProvider(ResourceProvider resourceProvider) {
		super(resourceProvider);
	}

	private static Type getParameterizedType(Class<?> interfaceClass,
			Class<?> clazz) {
		Type type = clazz.getGenericSuperclass();
		if ((type instanceof ParameterizedType)) {
			ParameterizedType parameterizedType = (ParameterizedType) type;
			if (interfaceClass.isAssignableFrom((Class) parameterizedType
					.getRawType())) {
				return parameterizedType.getActualTypeArguments()[0];
			}
		} else {
			Type[] types = clazz.getGenericInterfaces();
			if (types != null) {
				for (Type t : types) {
					if ((t instanceof ParameterizedType)) {
						ParameterizedType parameterizedType = (ParameterizedType) t;
						if (interfaceClass
								.isAssignableFrom((Class) parameterizedType
										.getRawType())) {
							return parameterizedType.getActualTypeArguments()[0];
						}
					}
				}
			}
		}
		return null;
	}

	public <S extends Service> ServiceFactory<S> getServiceFactory(
			Class<S> serviceInterface) throws ServiceNotFoundException {
		ServiceFactory factory = (ServiceFactory) serviceFactories
				.get(serviceInterface);
		if (factory == null) {
			Class serviceFactoryClass = (Class) serviceFactoryClasses
					.get(serviceInterface);

			if (serviceFactoryClass == null) {
				throw new ServiceNotFoundException(
						serviceInterface == null ? null
								: serviceInterface.getName());
			}

			try {
				factory = (ServiceFactory) serviceFactoryClass.newInstance();
				serviceFactories.put(serviceInterface, factory);
			} catch (InstantiationException | IllegalAccessException e) {
				throw new ServiceNotFoundException(e);
			}
		}
		return factory;
	}

	public void registerServiceFactory(
			ServiceFactory<? extends Service> serviceFactory) {
		if (serviceFactory == null) {
			return;
		}
		Type serviceInterface = getParameterizedType(ServiceFactory.class,
				serviceFactory.getClass());

		if (serviceInterface != null)
			serviceFactories.put(serviceInterface, serviceFactory);
	}

	public void unRegisterServiceFactory(
			ServiceFactory<? extends Service> serviceFactory) {
		if (serviceFactory == null) {
			return;
		}
		Type serviceInterface = getParameterizedType(ServiceFactory.class,
				serviceFactory.getClass());

		if (serviceInterface != null) {
			serviceFactories.remove(serviceInterface);
			serviceFactoryClasses.remove(serviceInterface);
		}
	}

	public void close() {
	}

	public ServiceSession createServiceSession() {
		return new SimpleServiceSession();
	}

	public ServiceSession createServiceSession(Session session) {
		return new SimpleServiceSession(session);
	}

	public ServiceSession createServiceSession(Session session,
			Prompter prompter) {
		return new SimpleServiceSession(session, prompter);
	}

	public void initilize(Connection connection) {
	}

	public void registerServiceFactory(
			Class<? extends ServiceFactory<?>> serviceFactoryClass) {
		if (serviceFactoryClass == null) {
			return;
		}
		Type serviceInterface = getParameterizedType(ServiceFactory.class,
				serviceFactoryClass);

		if (serviceInterface != null)
			serviceFactoryClasses.put(serviceInterface, serviceFactoryClass);
	}

	public void registerServiceFactories(
			Set<Class<? extends ServiceFactory<?>>> serviceFactoryClasses) {
		if (serviceFactories == null) {
			return;
		}
		for (Class serviceFactoryClass : serviceFactoryClasses) {
			Type serviceInterface = getParameterizedType(ServiceFactory.class,
					serviceFactoryClass);

			if (serviceInterface != null)
				this.serviceFactoryClasses.put(serviceInterface,
						serviceFactoryClass);
		}
	}

	static {
		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				if (StringHelper.isEmpty((String) parameter))
					pstmt.setNull(parameterIndex, 0);
				else
					pstmt.setString(parameterIndex, (String) parameter);
			}
		}, new Class[] { String.class });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setInt(parameterIndex, ((Integer) parameter).intValue());
			}
		}, new Class[] { Integer.class, Integer.TYPE });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setLong(parameterIndex, ((Long) parameter).longValue());
			}
		}, new Class[] { Long.class, Long.TYPE });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setShort(parameterIndex, ((Short) parameter).shortValue());
			}
		}, new Class[] { Short.class, Short.TYPE });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setByte(parameterIndex, ((Byte) parameter).byteValue());
			}
		}, new Class[] { Byte.class, Byte.TYPE });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setDouble(parameterIndex,
						((Double) parameter).doubleValue());
			}
		}, new Class[] { Double.class, Double.TYPE });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setBoolean(parameterIndex,
						((Boolean) parameter).booleanValue());
			}
		}, new Class[] { Boolean.class, Boolean.TYPE });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setFloat(parameterIndex, ((Float) parameter).floatValue());
			}
		}, new Class[] { Float.class, Float.TYPE });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setTime(parameterIndex, (Time) parameter);
			}
		}, new Class[] { Time.class });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setTimestamp(parameterIndex, (Timestamp) parameter);
			}
		}, new Class[] { Timestamp.class });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setDate(parameterIndex, (Date) parameter);
			}
		}, new Class[] { Date.class });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setURL(parameterIndex, (URL) parameter);
			}
		}, new Class[] { URL.class });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setBigDecimal(parameterIndex, (BigDecimal) parameter);
			}
		}, new Class[] { BigDecimal.class });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setArray(parameterIndex, (Array) parameter);
			}
		}, new Class[] { Array.class });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setRowId(parameterIndex, (RowId) parameter);
			}
		}, new Class[] { RowId.class });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setBlob(parameterIndex, (Blob) parameter);
			}
		}, new Class[] { Blob.class });

		register(new ParameterSetter() {
			public void set(PreparedStatement pstmt, int parameterIndex,
					Object parameter) throws SQLException {
				pstmt.setClob(parameterIndex, (Clob) parameter);
			}
		}, new Class[] { Clob.class });
	}

	public class SimpleServiceSession implements ServiceSession {
		private ServiceResource serviceResource = null;
		private Map<Class<? extends Service>, Service> services = null;
		private boolean transactions = false;
		private Map<String, SQLConnectionProxy> sqlConnections = null;
		private Map<String, SQLConnectionProvider> connectionProviders;
		private transient boolean invalidated = false;
		private int level = -1;
		private Session session;
		private Prompter prompter;

		public SimpleServiceSession() {
			prompter = null;
			session = null;
		}

		public SimpleServiceSession(Session session) {
			this.session = session;
		}

		public SimpleServiceSession(Session session, Prompter prompter) {
			this.session = session;
			this.prompter = prompter;
		}

		public synchronized void openTransactions() throws SQLException {
			if (invalidated) {
				throw new ResourceInvalidatedException();
			}
			if (transactions)
				return;
			try {
				if (sqlConnections != null) {
					for (SQLConnection connection : sqlConnections.values()) {
						connection.setAutoCommit(false);
					}
				}
				transactions = true;
			} catch (Throwable t) {
				if (sqlConnections != null)
					for (SQLConnection connection : sqlConnections.values())
						connection.setAutoCommit(true);
			}
		}

		public void openTransactions(int level) throws Throwable {
			if (invalidated) {
				throw new ResourceInvalidatedException();
			}
			if (transactions)
				return;
			try {
				if (sqlConnections != null) {
					for (SQLConnection connection : sqlConnections.values()) {
						connection.setTransactionIsolation(level);
						connection.setAutoCommit(false);
					}
				}
				transactions = true;
				this.level = level;
			} catch (Throwable t) {
				if (sqlConnections != null)
					for (SQLConnection connection : sqlConnections.values())
						connection.setAutoCommit(true);
			}
		}

		public synchronized boolean isTransactions() throws SQLException {
			if (invalidated) {
				throw new ResourceInvalidatedException();
			}
			return transactions;
		}

		public synchronized void commit() throws SQLException {
			if (invalidated) {
				throw new ResourceInvalidatedException();
			}
			if (transactions) {
				if (sqlConnections != null) {
					for (SQLConnection connection : sqlConnections.values()) {
						connection.commit();
						connection.setAutoCommit(true);
					}
				}
				transactions = false;
			}
		}

		public synchronized void rollback() throws SQLException {
			if (invalidated) {
				throw new ResourceInvalidatedException();
			}
			if (transactions) {
				if (sqlConnections != null) {
					for (SQLConnection connection : sqlConnections.values()) {
						connection.rollback();
						connection.setAutoCommit(true);
					}
				}
				transactions = false;
			}
		}

		protected <C extends DataConnectionProvider> C getDataConnectionProvider(
				Class<C> providerType, String name)
				throws ResourceNotFoundException {
			if (SQLConnectionProvider.class.isAssignableFrom(providerType)) {
				if (connectionProviders == null) {
					connectionProviders = new HashMap();
				}
				SQLConnectionProvider provider = (SQLConnectionProvider) connectionProviders
						.get(name);
				if (provider == null) {
					provider = new SQLConnectionProviderProxy(resourceProvider,
							resourceProvider,
							(SQLConnectionProvider) resourceProvider
									.getDataConnectionProvider(providerType,
											name)) {
						public SQLConnection getConnection(String schema)
								throws SQLException {
							String providerName = getName();
							SQLConnectionProxy connection;
							if ((sqlConnections == null)
									|| ((connection = (SQLConnectionProxy) sqlConnections
											.get(providerName)) == null)) {
								connection = new SQLConnectionProxy(
										connectionProvider
												.getConnection(schema));

								if (sqlConnections == null) {
									sqlConnections = new LinkedHashMap();
								}
								sqlConnections.put(providerName, connection);
								if (transactions) {
									if (level != -1) {
										connection
												.setTransactionIsolation(level);
									}

									connection.setAutoCommit(false);
								}
							} else {
								connection.setSchema(schema);
							}
							return connection;
						}

						public SQLConnection getConnection()
								throws SQLException {
							String providerName = getName();
							SQLConnectionProxy connection;
							if ((sqlConnections == null)
									|| ((connection = (SQLConnectionProxy) sqlConnections
											.get(providerName)) == null)) {
								connection = new SQLConnectionProxy(
										connectionProvider.getConnection());

								if (sqlConnections == null) {
									sqlConnections = new LinkedHashMap();
								}
								sqlConnections.put(providerName, connection);
								if (transactions) {
									if (level != -1) {
										connection
												.setTransactionIsolation(level);
									}

									connection.setAutoCommit(false);
								}
							}
							return connection;
						}
					};
					connectionProviders.put(name, provider);
				}
				return (C) provider;
			}
			return resourceProvider.getDataConnectionProvider(providerType,
					name);
		}

		public synchronized void close() {
			if (invalidated) {
				return;
			}
			invalidated = true;
			if (sqlConnections != null) {
				for (SQLConnectionProxy connection : sqlConnections.values()) {
					try {
						if (!connection.getAutoCommit()) {
							connection.rollback();
							connection.setAutoCommit(true);
						}
					} catch (SQLException e) {
						resourceProvider.log(e);
					} finally {
						try {
							connection._release();
						} catch (SQLException e) {
							resourceProvider.log(e);
						}
					}
				}
				sqlConnections.clear();
			}

			serviceResource = null;
			if (services != null)
				services.clear();
		}

		protected final synchronized ServiceResource getServiceResource() {
			if (serviceResource == null) {
				serviceResource = new ServiceResource() {
					public Session getSession()
							throws ResourceInvalidatedException {
						return SimpleServiceProvider.SimpleServiceSession.this
								.getSession();
					}

					public void log(Throwable throwable) {
						resourceProvider.log(throwable);
					}

					public void log(String message) {
						resourceProvider.log(message);
					}

					public <R extends Resource> R getResource(
							Class<R> resourceType)
							throws ResourceNotFoundException {
						if (ServiceProvider.class
								.isAssignableFrom(resourceType)) {
							throw new ResourceNotFoundException("禁止获取服务供应商.");
						}
						return resourceProvider.getResource(resourceType);
					}

					public <R extends NamedResource> R getNamedResource(
							Class<R> resourceType, String name)
							throws ResourceNotFoundException {
						return resourceProvider.getNamedResource(resourceType,
								name);
					}

					public <S extends Service> S getService(
							Class<S> serviceInterface)
							throws ServiceNotFoundException,
							ResourceInvalidatedException {
						throw new RuntimeException("禁止业务实现内部调用其他业务接口.");
					}

					public void openTransactions() throws Throwable {
						SimpleServiceProvider.SimpleServiceSession.this
								.openTransactions();
					}

					public void commit() throws Throwable {
						SimpleServiceProvider.SimpleServiceSession.this
								.commit();
					}

					public void rollback() throws Throwable {
						SimpleServiceProvider.SimpleServiceSession.this
								.rollback();
					}

					public boolean isTransactions() throws Throwable {
						return SimpleServiceProvider.SimpleServiceSession.this
								.isTransactions();
					}

					public void close() {
					}

					public <C extends DataConnectionProvider> C getDataConnectionProvider(
							Class<C> providerType, String name)
							throws ResourceNotFoundException {
						return SimpleServiceProvider.SimpleServiceSession.this
								.getDataConnectionProvider(providerType, name);
					}

					public ModuleBean[] getModuleBeans() {
						return resourceProvider.getModuleBeans();
					}

					public ModuleBean getModuleBean(String moduleId) {
						return resourceProvider.getModuleBean(moduleId);
					}

					public RightBean getRightBean(String rightId) {
						return resourceProvider.getRightBean(rightId);
					}

					public void openTransactions(int level) throws Throwable {
						SimpleServiceProvider.SimpleServiceSession.this
								.openTransactions(level);
					}

					public void setParameters(PreparedStatement pstmt,
							Collection<Object> parameters) throws SQLException {
						if ((parameters == null) || (parameters.size() == 0)) {
							return;
						}
						int parameterIndex = 1;
						for (Iterator i$ = parameters.iterator(); i$.hasNext();) {
							Object parameter = i$.next();
							if (parameter == null)
								pstmt.setNull(parameterIndex++, 0);
							else
								SimpleServiceProvider.getSetter(
										parameter.getClass()).set(pstmt,
										parameterIndex++, parameter);
						}
					}

					public void setParameters(PreparedStatement pstmt,
							Object[] parameters) throws SQLException {
						if ((parameters == null) || (parameters.length == 0)) {
							return;
						}
						int parameterIndex = 1;
						for (Object parameter : parameters)
							if (parameter == null)
								pstmt.setNull(parameterIndex++, 0);
							else
								SimpleServiceProvider.getSetter(
										parameter.getClass()).set(pstmt,
										parameterIndex++, parameter);
					}

					public void prompt(PromptLevel level, String message) {
						SimpleServiceProvider.SimpleServiceSession.this.prompt(
								level, message);
					}

					public void clearPrompts(PromptLevel level) {
						SimpleServiceProvider.SimpleServiceSession.this
								.clearPrompts(level);
					}

					public void clearAllPrompts() {
						SimpleServiceProvider.SimpleServiceSession.this
								.clearAllPrompts();
					}

					public String getHome() {
						return resourceProvider.getHome();
					}

					public String getInitParameter(String name) {
						return resourceProvider.getInitParameter(name);
					}

					public Enumeration<String> getInitParameterNames() {
						return resourceProvider.getInitParameterNames();
					}

					public ResourceRetention getResourceRetention() {
						return resourceProvider.getResourceRetention();
					}

					public String getContextPath() {
						return resourceProvider.getContextPath();
					}

					public String getCharset() {
						return resourceProvider.getCharset();
					}

					public SystemDefine getSystemDefine() {
						return resourceProvider.getSystemDefine();
					}

					public Controller getController()
							throws ResourceNotFoundException {
						return SimpleServiceProvider.SimpleServiceSession.this
								.getController();
					}
				};
			}

			return serviceResource;
		}

		public synchronized <S extends Service> S getService(
				Class<S> serviceInterface) throws ServiceNotFoundException {
			if (invalidated) {
				throw new ResourceInvalidatedException();
			}
			if ((serviceInterface == null) || (!serviceInterface.isInterface()))
				throw new ServiceNotFoundException();
			Service service;
			if (services == null) {
				service = getServiceFactory(serviceInterface).newInstance(
						getServiceResource());

				services = new HashMap();
				services.put(serviceInterface, service);
			} else {
				service = (Service) services.get(serviceInterface);
				if (service == null) {
					service = getServiceFactory(serviceInterface).newInstance(
							getServiceResource());

					services.put(serviceInterface, service);
				}
			}
			return (S) service;
		}

		public Session getSession() {
			return session;
		}

		public void prompt(PromptLevel level, String message) {
			if (prompter != null)
				prompter.prompt(level, message);
		}

		public void clearPrompts(PromptLevel level) {
			if (prompter != null)
				prompter.clearPrompts(level);
		}

		public void clearAllPrompts() {
			if (prompter != null)
				prompter.clearAllPrompts();
		}

		public Controller getController() throws ResourceNotFoundException {
			return (Controller) resourceProvider.getResource(Controller.class);
		}
	}

	protected static abstract interface ParameterSetter {
		public abstract void set(PreparedStatement paramPreparedStatement,
				int paramInt, Object paramObject) throws SQLException;
	}
}