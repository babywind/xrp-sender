package com.quqian.framework.resource;

import java.util.Enumeration;

public abstract interface InitParameterProvider
{
  public abstract String getInitParameter(String paramString);

  public abstract Enumeration<String> getInitParameterNames();
}