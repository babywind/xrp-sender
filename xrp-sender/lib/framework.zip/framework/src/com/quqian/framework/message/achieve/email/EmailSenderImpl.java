package com.quqian.framework.message.achieve.email;

import com.quqian.framework.message.email.EmailSender;
import com.quqian.framework.service.ServiceFactory;
import com.quqian.framework.service.ServiceResource;
import com.quqian.util.StringHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

public class EmailSenderImpl extends AbstractEmailService implements
		EmailSender {
	public EmailSenderImpl(ServiceResource serviceResource) {
		super(serviceResource);
	}

	public void send(int type, String subject, String content,
			String[] addresses) throws Throwable {
		if ((StringHelper.isEmpty(subject)) || (StringHelper.isEmpty(content))
				|| (addresses == null) || (addresses.length <= 0)) {
			return;
		}
		Connection connection = getConnection();
		Throwable localThrowable5 = null;
		try {
			long msgId = 0L;
			Throwable localThrowable6 = null;
			{
				PreparedStatement ps = connection
						.prepareStatement(
								"INSERT INTO _1046(F02,F03,F04,F05,F07) VALUES(?,?,?,?,?)",
								1);
				try {
					ps.setString(1, subject);
					ps.setString(2, content);
					ps.setInt(3, type);
					ps.setTimestamp(4,
							new Timestamp(System.currentTimeMillis()));
					ps.setString(5, "W");
					ps.execute();
					ResultSet resultSet = ps.getGeneratedKeys();
					Throwable localThrowable7 = null;
					try {
						if (resultSet.next())
							msgId = resultSet.getLong(1);
					} catch (Throwable localThrowable1) {
						localThrowable7 = localThrowable1;
						throw localThrowable1;
					} finally {
					}
				} catch (Throwable localThrowable2) {
					localThrowable6 = localThrowable2;
					throw localThrowable2;
				} finally {
				}
			}
			if (msgId > 0L) {
				PreparedStatement ps = connection
						.prepareStatement("INSERT INTO _1047(F01,F02) VALUES(?,?)");
				localThrowable6 = null;
				try {
					for (String address : addresses) {
						ps.setLong(1, msgId);
						ps.setString(2, address);
						ps.addBatch();
					}
					ps.executeBatch();
				} catch (Throwable localThrowable3) {
					localThrowable6 = localThrowable3;
					throw localThrowable3;
				} finally {
				}
			}
		} catch (Throwable localThrowable4) {
			localThrowable5 = localThrowable4;
			throw localThrowable4;
		} finally {
			if (connection != null)
				if (localThrowable5 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable5.addSuppressed(x2);
					}
				else
					connection.close();
		}
	}

	public static class EmailSenderFactory implements
			ServiceFactory<EmailSender> {
		public EmailSender newInstance(ServiceResource serviceResource) {
			return new EmailSenderImpl(serviceResource);
		}
	}
}