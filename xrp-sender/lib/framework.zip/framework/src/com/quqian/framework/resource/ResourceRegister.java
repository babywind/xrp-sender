package com.quqian.framework.resource;

import javax.servlet.ServletContext;

public abstract class ResourceRegister {
	private static final String RESOURCE_PROVIDER_KEY = "QUQIAN_RESOURCE_PROVIDER";

	protected static final void initialize(ServletContext servletContext,
			ResourceProvider provider) {
		if ((servletContext == null) || (provider == null)) {
			return;
		}
		Object object = servletContext.getAttribute(RESOURCE_PROVIDER_KEY);
		if (object == null)
			servletContext.setAttribute(RESOURCE_PROVIDER_KEY, provider);
		else if (provider != object)
			if ((object instanceof ResourceProvider))
				try {
					((ResourceProvider) object).close();
				} catch (Exception e) {
					provider.log(e);
				}
			else
				servletContext.setAttribute(RESOURCE_PROVIDER_KEY, provider);
	}

	public static final ResourceProvider getResourceProvider(
			ServletContext servletContext) throws ResourceNotFoundException {
		if (servletContext == null) {
			throw new ResourceNotFoundException();
		}
		Object object = servletContext.getAttribute(RESOURCE_PROVIDER_KEY);
		if (object == null) {
			throw new ResourceNotFoundException();
		}
		if ((object instanceof ResourceProvider)) {
			return (ResourceProvider) object;
		}
		throw new ResourceNotFoundException();
	}
}