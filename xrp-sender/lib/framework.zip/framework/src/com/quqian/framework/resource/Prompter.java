package com.quqian.framework.resource;

public abstract interface Prompter
{
  public abstract void prompt(PromptLevel paramPromptLevel, String paramString);

  public abstract void clearPrompts(PromptLevel paramPromptLevel);

  public abstract void clearAllPrompts();
}