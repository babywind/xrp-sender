package com.quqian.framework.http.achieve.service;

import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.data.sql.SQLConnectionProvider;
import com.quqian.framework.http.session.SessionManager;
import com.quqian.framework.resource.ResourceNotFoundException;
import com.quqian.framework.service.AbstractService;
import com.quqian.framework.service.ServiceResource;

import java.sql.Connection;
import java.sql.SQLException;

public abstract class AbstractHttpService extends AbstractService
{
  public AbstractHttpService(ServiceResource serviceResource)
  {
    super(serviceResource);
  }

  protected SQLConnectionProvider getConnectionProvider() {
    SystemDefine systemDefine = serviceResource.getSystemDefine();
    return (SQLConnectionProvider)serviceResource.getDataConnectionProvider(SQLConnectionProvider.class, systemDefine.getDataProvider(SessionManager.class));
  }

  protected Connection getConnection()
    throws ResourceNotFoundException, SQLException
  {
    SystemDefine systemDefine = serviceResource.getSystemDefine();
    return ((SQLConnectionProvider)serviceResource.getDataConnectionProvider(SQLConnectionProvider.class, systemDefine.getDataProvider(SessionManager.class))).getConnection(systemDefine.getSchemaName(SessionManager.class));
  }

  protected Connection getConnection(String schemaName)
    throws ResourceNotFoundException, SQLException
  {
    SystemDefine systemDefine = serviceResource.getSystemDefine();
    return ((SQLConnectionProvider)serviceResource.getDataConnectionProvider(SQLConnectionProvider.class, systemDefine.getDataProvider(SessionManager.class))).getConnection(schemaName);
  }
}