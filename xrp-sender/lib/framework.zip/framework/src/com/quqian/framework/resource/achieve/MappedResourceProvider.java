package com.quqian.framework.resource.achieve;

import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.config.entity.ModuleBean;
import com.quqian.framework.data.DataConnectionProvider;
import com.quqian.framework.http.entity.RightBean;
import com.quqian.framework.log.Logger;
import com.quqian.framework.resource.InitParameterProvider;
import com.quqian.framework.resource.NamedResource;
import com.quqian.framework.resource.Resource;
import com.quqian.framework.resource.ResourceNotFoundException;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.framework.resource.ResourceRetention;
import com.quqian.util.StringHelper;

import java.nio.charset.Charset;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

abstract class MappedResourceProvider implements ResourceProvider {
	protected Map<Class<? extends Resource>, Resource> resources;
	protected Map<Class<? extends Resource>, Map<String, Resource>> namedResources;
	protected Map<Class<? extends DataConnectionProvider>, Map<String, DataConnectionProvider>> connectionProviders;
	private Map<String, ModuleBean> modules = new LinkedHashMap();
	private Map<String, RightBean> rights = new HashMap();
	protected final String home;
	protected final Logger logger;
	protected final InitParameterProvider initParameterProvider;
	protected final ResourceRetention resourceRetention;
	protected final String contextPath;
	protected final String charset;
	protected final SystemDefine systemDefine;

	public MappedResourceProvider(String home, Logger logger,
			String contextPath, InitParameterProvider initParameterProvider,
			SystemDefine systemDefine) {
		this.home = home;
		this.logger = logger;
		this.systemDefine = systemDefine;
		resources = new HashMap();
		namedResources = new HashMap();
		connectionProviders = new HashMap();
		if ((StringHelper.isEmpty(contextPath)) || ("/".equals(contextPath)))
			this.contextPath = "";
		else {
			this.contextPath = contextPath;
		}
		this.initParameterProvider = initParameterProvider;
		if (initParameterProvider == null) {
			resourceRetention = ResourceRetention.DEVELOMENT;
			charset = "UTF-8";
			return;
		}

		String parameter = initParameterProvider.getInitParameter("retention");

		if (StringHelper.isEmpty(parameter)) {
			resourceRetention = ResourceRetention.DEVELOMENT;
		} else {
			ResourceRetention retention = ResourceRetention.valueOf(parameter);

			if (retention == null) {
				if ("prd".equalsIgnoreCase(parameter))
					resourceRetention = ResourceRetention.PRODUCTION;
				else if ("test".equalsIgnoreCase(parameter))
					resourceRetention = ResourceRetention.PRE_PRODUCTION;
				else
					resourceRetention = ResourceRetention.DEVELOMENT;
			} else {
				resourceRetention = retention;
			}

		}

		parameter = initParameterProvider.getInitParameter("charset");
		if (StringHelper.isEmpty(parameter)) {
			charset = "UTF-8";
		} else {
			try {
				Charset.forName(parameter);
			} catch (Throwable t) {
				parameter = "UTF-8";
			}
			charset = parameter;
		}
	}

	public synchronized void close() {
		for (Resource resource : resources.values()) {
			try {
				resource.close();
			} catch (Exception e) {
				log(e);
			}
		}
		resources.clear();
		for (Map<String, Resource> instances : namedResources.values()) {
			for (Resource resource : instances.values()) {
				try {
					resource.close();
				} catch (Exception e) {
					log(e);
				}
			}
		}
		namedResources.clear();
		for (Map<String, DataConnectionProvider> connectionProviderMap : connectionProviders
				.values()) {
			for (DataConnectionProvider connectionProvider : connectionProviderMap
					.values())
				try {
					connectionProvider.close();
				} catch (Exception e) {
					log(e);
				}
		}
	}

	public <R extends Resource> R getResource(Class<R> resourceType) {
		Resource resource = (Resource) resources.get(resourceType);
		if (resource == null) {
			throw new ResourceNotFoundException(resourceType.getCanonicalName());
		}
		return (R) resource;
	}

	public <R extends NamedResource> R getNamedResource(Class<R> resourceType,
			String name) throws ResourceNotFoundException {
		Map instances = (Map) namedResources.get(resourceType);

		if (instances == null) {
			throw new ResourceNotFoundException();
		}
		NamedResource resource = (NamedResource) instances.get(name);
		if (resource == null) {
			throw new ResourceNotFoundException();
		}
		return (R) resource;
	}

	public synchronized <R extends Resource> void registerResource(R resource) {
		if (resource == null) {
			return;
		}

		Class type = resource.getIdentifiedType();
		Resource oldResource;
		if ((resource instanceof NamedResource)) {
			Map instances = (Map) namedResources.get(type);
			if (instances == null) {
				instances = new HashMap();
				namedResources.put(type, instances);
			}
			oldResource = (Resource) instances.put(
					((NamedResource) resource).getName(), resource);
		} else {
			oldResource = (Resource) resources.put(type, resource);
		}
		if ((oldResource != null) && (oldResource != resource)
				&& ((oldResource instanceof AutoCloseable)))
			try {
				oldResource.close();
			} catch (Exception e) {
				log(e);
			}
	}

	public void log(Throwable throwable) {
		logger.log(throwable);
	}

	public void log(String message) {
		logger.log(message);
	}

	public <C extends DataConnectionProvider> C getDataConnectionProvider(
			Class<C> providerType, String name)
			throws ResourceNotFoundException {
		Map instances = (Map) connectionProviders.get(providerType);

		if (instances == null) {
			throw new ResourceNotFoundException();
		}
		DataConnectionProvider resource = (DataConnectionProvider) instances
				.get(name);
		if (resource == null) {
			throw new ResourceNotFoundException();
		}
		return (C) resource;
	}

	public <C extends DataConnectionProvider> void registerConnectionProvider(
			C provider) {
		if (provider == null) {
			return;
		}

		Class type = provider.getIdentifiedType();

		Map instances = (Map) connectionProviders.get(type);

		if (instances == null) {
			instances = new HashMap();
			connectionProviders.put(type, instances);
		}
		DataConnectionProvider oldResource = (DataConnectionProvider) instances
				.put(provider.getName(), provider);

		if ((oldResource != null) && (oldResource != provider))
			try {
				oldResource.close();
			} catch (Exception e) {
				log(e);
			}
	}

	void setModuleBeans(ModuleBean[] moduleBeans) {
		if (moduleBeans == null) {
			return;
		}
		for (ModuleBean moduleBean : moduleBeans) {
			modules.put(moduleBean.getId(), moduleBean);
			for (RightBean rightBean : moduleBean.getRightBeans())
				rights.put(rightBean.getId(), rightBean);
		}
	}

	public ModuleBean[] getModuleBeans() {
		if (modules.size() == 0) {
			return new ModuleBean[0];
		}
		return (ModuleBean[]) modules.values().toArray(
				new ModuleBean[modules.size()]);
	}

	public ModuleBean getModuleBean(String moduleId) {
		return (ModuleBean) modules.get(moduleId);
	}

	public RightBean getRightBean(String rightId) {
		return (RightBean) rights.get(rightId);
	}

	public String getHome() {
		return home;
	}

	public String getInitParameter(String name) {
		return initParameterProvider == null ? null : initParameterProvider
				.getInitParameter(name);
	}

	public Enumeration<String> getInitParameterNames() {
		return initParameterProvider == null ? null : initParameterProvider
				.getInitParameterNames();
	}

	public ResourceRetention getResourceRetention() {
		return resourceRetention;
	}

	public String getContextPath() {
		return contextPath;
	}

	public String getCharset() {
		return charset;
	}

	public SystemDefine getSystemDefine() {
		return systemDefine;
	}
}