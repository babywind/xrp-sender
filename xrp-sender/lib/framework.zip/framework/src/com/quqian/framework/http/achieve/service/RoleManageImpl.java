package com.quqian.framework.http.achieve.service;

import com.quqian.framework.data.sql.SQLConnectionProvider;
import com.quqian.framework.http.entity.RoleBean;
import com.quqian.framework.http.service.RoleManage;
import com.quqian.framework.http.service.RoleManage.RoleQuery;
import com.quqian.framework.http.session.Session;
import com.quqian.framework.service.ServiceFactory;
import com.quqian.framework.service.ServiceResource;
import com.quqian.framework.service.exception.LogicalException;
import com.quqian.framework.service.exception.ParameterException;
import com.quqian.framework.service.query.ArrayParser;
import com.quqian.framework.service.query.ItemParser;
import com.quqian.framework.service.query.Paging;
import com.quqian.framework.service.query.PagingResult;
import com.quqian.util.StringHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

public class RoleManageImpl extends AbstractHttpService implements RoleManage {
	private static ItemParser<RoleBean> ITEM_PARSER = new ItemParser() {
		public RoleBean parse(ResultSet resultSet) throws SQLException {
			RoleManageImpl.RoleBeanImpl role = null;
			if (resultSet.next()) {
				role = new RoleManageImpl.RoleBeanImpl();
				role.roleId = resultSet.getInt(1);
				role.name = resultSet.getString(2);
				role.description = resultSet.getString(3);
				role.createTime = resultSet.getTimestamp(4);
				role.createId = resultSet.getInt(5);
				role.status = resultSet.getString(6);
			}
			return role;
		}
	};

	private static ArrayParser<RoleBean> ARRAY_PARSER = new ArrayParser() {
		public RoleBean[] parse(ResultSet resultSet) throws SQLException {
			ArrayList list = null;
			while (resultSet.next()) {
				if (list == null) {
					list = new ArrayList();
				}
				RoleManageImpl.RoleBeanImpl role = new RoleManageImpl.RoleBeanImpl();
				role.roleId = resultSet.getInt(1);
				role.name = resultSet.getString(2);
				role.description = resultSet.getString(3);
				role.createTime = resultSet.getTimestamp(4);
				role.createId = resultSet.getInt(5);
				role.status = resultSet.getString(6);
				list.add(role);
			}
			return list == null ? new RoleBean[0] : (RoleBean[]) list
					.toArray(new RoleBean[list.size()]);
		}
	};

	public RoleManageImpl(ServiceResource serviceResource) {
		super(serviceResource);
	}

	public int add(String name, String description) throws Throwable {
		if (StringHelper.isEmpty(name)) {
			throw new ParameterException("角色名称不能为空");
		}
		name = name.trim();
		Connection connection = getConnection();
		Throwable localThrowable6 = null;
		try {

			Throwable localThrowable7 = null;
			Throwable localThrowable8;
			{
				PreparedStatement pstmt = connection
						.prepareStatement("SELECT F01 FROM _1020 WHERE F02 = ? LIMIT 1");
				try {
					pstmt.setString(1, name);
					ResultSet resultSet = pstmt.executeQuery();
					localThrowable8 = null;
					try {
						if (resultSet.next())
							throw new LogicalException(String.format(
									"角色%s已经存在,不能重复添加", new Object[] { name }));
					} catch (Throwable localThrowable1) {
						localThrowable8 = localThrowable1;
						throw localThrowable1;
					} finally {
						resultSet.close();
					}
				} catch (Throwable localThrowable2) {
					localThrowable7 = localThrowable2;
					throw localThrowable2;
				} finally {
					pstmt.close();
				}
			}
			{
				PreparedStatement pstmt = connection
						.prepareStatement(
								"INSERT INTO _1020 SET F02 = ?, F03 = ?, F04 = ?, F05 = ?, F06 = ?",
								1);
				localThrowable7 = null;
				try {
					pstmt.setString(1, name);
					if (StringHelper.isEmpty(description))
						pstmt.setNull(2, 0);
					else {
						pstmt.setString(2, description.trim());
					}
					pstmt.setTimestamp(3,
							new Timestamp(System.currentTimeMillis()));
					pstmt.setInt(4, serviceResource.getSession().getAccountId());
					pstmt.setString(5, "QY");
					pstmt.execute();
					ResultSet resultSet = pstmt.getGeneratedKeys();
					localThrowable8 = null;
					try {
						if (resultSet.next()) {
							return resultSet.getInt(1);
						}
						return 0;
					} catch (Throwable localThrowable3) {
						localThrowable8 = localThrowable3;
						throw localThrowable3;
					} finally {
						resultSet.close();
					}
				} catch (Throwable localThrowable4) {
					localThrowable7 = localThrowable4;
					throw localThrowable4;
				} finally {
					pstmt.close();
				}
			}
		} catch (Throwable localThrowable5) {
			localThrowable6 = localThrowable5;
			throw localThrowable5;
		} finally {
			if (connection != null)
				if (localThrowable6 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable6.addSuppressed(x2);
					}
				else
					connection.close();
		}
	}

	public void delete(int roleId) throws Throwable {
		if (roleId <= 0) {
			return;
		}
		serviceResource.openTransactions();
		Connection connection = getConnection();
		Throwable localThrowable5 = null;
		try {
			Throwable localThrowable6 = null;
			{
				PreparedStatement pstmt = connection
						.prepareStatement("DELETE FROM _1022 WHERE F02 = ? ");
				try {
					pstmt.setInt(1, roleId);
					pstmt.execute();
				} catch (Throwable localThrowable1) {
					localThrowable6 = localThrowable1;
					throw localThrowable1;
				} finally {
					pstmt.close();
				}
			}
			{
				PreparedStatement pstmt = connection
						.prepareStatement("DELETE FROM _1021 WHERE F01 = ? ");
				localThrowable6 = null;
				try {
					pstmt.setInt(1, roleId);
					pstmt.execute();
				} catch (Throwable localThrowable2) {
					localThrowable6 = localThrowable2;
					throw localThrowable2;
				} finally {
					pstmt.close();
				}
			}
			{
				PreparedStatement pstmt = connection
						.prepareStatement("DELETE FROM _1020 WHERE F01 = ? ");
				localThrowable6 = null;
				try {
					pstmt.setInt(1, roleId);
					pstmt.execute();
				} catch (Throwable localThrowable3) {
					localThrowable6 = localThrowable3;
					throw localThrowable3;
				} finally {
					pstmt.close();
				}
			}
		} catch (Throwable localThrowable4) {
			localThrowable5 = localThrowable4;
			throw localThrowable4;
		} finally {
			if (connection != null)
				if (localThrowable5 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable5.addSuppressed(x2);
					}
				else
					connection.close();
		}
	}

	public void active(int roleId) throws Throwable {
		if (roleId <= 0) {
			return;
		}
		Connection connection = getConnection();
		Throwable localThrowable3 = null;
		try {
			PreparedStatement pstmt = connection
					.prepareStatement("UPDATE _1020 SET F06 = ? WHERE F01 = ? ");
			Throwable localThrowable4 = null;
			try {
				pstmt.setString(1, "QY");
				pstmt.setInt(2, roleId);
				pstmt.execute();
			} catch (Throwable localThrowable1) {
				localThrowable4 = localThrowable1;
				throw localThrowable1;
			} finally {
			}
		} catch (Throwable localThrowable2) {
			localThrowable3 = localThrowable2;
			throw localThrowable2;
		} finally {
			if (connection != null)
				if (localThrowable3 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable3.addSuppressed(x2);
					}
				else
					connection.close();
		}
	}

	public void inActive(int roleId) throws Throwable {
		if (roleId <= 0) {
			return;
		}
		Connection connection = getConnection();
		Throwable localThrowable3 = null;
		try {
			PreparedStatement pstmt = connection
					.prepareStatement("UPDATE _1020 SET F06 = ? WHERE F01 = ? ");
			Throwable localThrowable4 = null;
			try {
				pstmt.setString(1, "TY");
				pstmt.setInt(2, roleId);
				pstmt.execute();
			} catch (Throwable localThrowable1) {
				localThrowable4 = localThrowable1;
				throw localThrowable1;
			} finally {
			}
		} catch (Throwable localThrowable2) {
			localThrowable3 = localThrowable2;
			throw localThrowable2;
		} finally {
			if (connection != null)
				if (localThrowable3 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable3.addSuppressed(x2);
					}
				else
					connection.close();
		}
	}

	public PagingResult<RoleBean> search(RoleManage.RoleQuery condition,
			Paging paging) throws Throwable {
		StringBuilder builder = new StringBuilder(
				"SELECT F01, F02, F03, F04, F05, F06 FROM _1020 WHERE 1 = 1 ");

		ArrayList parameters = new ArrayList();
		SQLConnectionProvider connectionProvider = getConnectionProvider();
		if (condition != null) {
			if (condition.getRoleId() > 0) {
				builder.append(" AND F01 = ?");
				parameters.add(Integer.valueOf(condition.getRoleId()));
			}
			if (!StringHelper.isEmpty(condition.getName())) {
				builder.append(" AND F02 LIKE ?");
				parameters
						.add(connectionProvider.allMatch(condition.getName()));
			}

			if (!StringHelper.isEmpty(condition.getName())) {
				builder.append(" AND F03 LIKE ?");
				parameters.add(connectionProvider.allMatch(condition
						.getDescription()));
			}

			if (condition.getCreateTimeStart() != null) {
				builder.append(" AND F04 >= ?");
				parameters.add(condition.getCreateTimeStart());
			}
			if (condition.getCreateTimeEnd() != null) {
				builder.append(" AND F04 <= ?");
				parameters.add(condition.getCreateTimeEnd());
			}
			if (condition.getCreaterId() > 0) {
				builder.append(" AND F05 = ?");
				parameters.add(Integer.valueOf(condition.getCreaterId()));
			}
			if (!StringHelper.isEmpty(condition.getStatus())) {
				builder.append(" AND F06 = ?");
				parameters.add(condition.getStatus());
			}
		}
		Connection connection = getConnection();
		Throwable localThrowable2 = null;
		try {
			return selectPaging(connection, ARRAY_PARSER, paging,
					builder.toString(), parameters);
		} catch (Throwable localThrowable3) {
			localThrowable2 = localThrowable3;
			throw localThrowable3;
		} finally {
			if (connection != null)
				if (localThrowable2 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable2.addSuppressed(x2);
					}
				else
					connection.close();
		}
	}

	public RoleBean[] getRoles(int userId) throws Throwable {
		if (userId <= 0) {
			return new RoleBean[0];
		}
		Connection connection = getConnection();
		Throwable localThrowable2 = null;
		try {
			return (RoleBean[]) selectAll(
					connection,
					ARRAY_PARSER,
					"SELECT _1020.F01, _1020.F02, _1020.F03, _1020.F04, _1020.F05, _1020.F06 FROM _1022 INNER JOIN _1020 ON _1022.F02 = _1020.F01 WHERE _1022.F01 = ?",
					new Object[] { Integer.valueOf(userId) });
		} catch (Throwable localThrowable3) {
			localThrowable2 = localThrowable3;
			throw localThrowable3;
		} finally {
			if (connection != null)
				if (localThrowable2 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable2.addSuppressed(x2);
					}
				else
					connection.close();
		}
	}

	public RoleBean getRole(int roleId) throws Throwable {
		if (roleId <= 0) {
			return null;
		}
		Connection connection = getConnection();
		Throwable localThrowable2 = null;
		try {
			return (RoleBean) select(
					connection,
					ITEM_PARSER,
					"SELECT F01, F02, F03, F04, F05, F06 FROM _1020 WHERE F01 = ?",
					new Object[] { Integer.valueOf(roleId) });
		} catch (Throwable localThrowable3) {
			localThrowable2 = localThrowable3;
			throw localThrowable3;
		} finally {
			if (connection != null)
				if (localThrowable2 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable2.addSuppressed(x2);
					}
				else
					connection.close();
		}
	}

	public void setRoles(int userId, int[] roleIds) throws Throwable {
		if (userId <= 0) {
			return;
		}
		serviceResource.openTransactions();
		Connection connection = getConnection();
		Throwable localThrowable4 = null;
		try {
			Throwable localThrowable5 = null;
			{
				PreparedStatement pstmt = connection
						.prepareStatement("DELETE FROM _1022 WHERE F01 = ?");
				try {
					pstmt.setInt(1, userId);
					pstmt.execute();
				} catch (Throwable localThrowable1) {
					localThrowable5 = localThrowable1;
					throw localThrowable1;
				} finally {
					pstmt.close();
				}
			}
			if (roleIds != null) {
				PreparedStatement pstmt = connection
						.prepareStatement("INSERT INTO _1022 SET F01 = ?, F02 = ?");
				localThrowable5 = null;
				try {
					for (int roleId : roleIds)
						if (roleId > 0) {
							pstmt.setInt(1, userId);
							pstmt.setInt(2, roleId);
							pstmt.addBatch();
						}
					pstmt.executeBatch();
				} catch (Throwable localThrowable2) {
					localThrowable5 = localThrowable2;
					throw localThrowable2;
				} finally {
				}
			}
		} catch (Throwable localThrowable3) {
			localThrowable4 = localThrowable3;
			throw localThrowable3;
		} finally {
			if (connection != null)
				if (localThrowable4 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable4.addSuppressed(x2);
					}
				else
					connection.close();
		}
	}

	private static class RoleBeanImpl implements RoleBean {
		private static final long serialVersionUID = 1L;
		int roleId;
		String name;
		String description;
		Timestamp createTime;
		int createId;
		String status;

		public int getRoleId() {
			return roleId;
		}

		public String getName() {
			return name;
		}

		public String getDescription() {
			return description;
		}

		public Timestamp getCreateTime() {
			return createTime;
		}

		public int getCreaterId() {
			return createId;
		}

		public String getStatus() {
			return status;
		}
	}

	public static class RoleManageFactory implements ServiceFactory<RoleManage> {
		public RoleManage newInstance(ServiceResource serviceResource) {
			return new RoleManageImpl(serviceResource);
		}
	}
}