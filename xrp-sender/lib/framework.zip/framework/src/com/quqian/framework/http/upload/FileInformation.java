package com.quqian.framework.http.upload;

public abstract interface FileInformation
{
  public abstract int getId();

  public abstract int getYear();

  public abstract int getMonth();

  public abstract int getDay();

  public abstract int getType();

  public abstract String getSuffix();
}