package com.quqian.framework.data.sql;

import com.quqian.framework.data.DataConnection;

import java.sql.Connection;

public abstract interface SQLConnection extends Connection, DataConnection
{
}