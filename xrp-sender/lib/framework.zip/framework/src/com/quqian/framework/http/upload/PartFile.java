package com.quqian.framework.http.upload;

import java.io.IOException;
import java.io.InputStream;
import javax.servlet.http.Part;

public class PartFile
  implements UploadFile
{
  protected final Part part;
  protected String suffix;

  public PartFile(Part part)
  {
    this.part = part;
  }

  public String getSuffix()
  {
    if (suffix == null) {
      String header = part.getHeader("content-disposition");
      int idx = header.lastIndexOf(".");
      if (idx == -1)
        suffix = "";
      else {
        suffix = header.substring(header.lastIndexOf(".") + 1, header.length() - 1);
      }
    }

    return suffix;
  }

  public InputStream getInputStream() throws IOException
  {
    return part.getInputStream();
  }
}