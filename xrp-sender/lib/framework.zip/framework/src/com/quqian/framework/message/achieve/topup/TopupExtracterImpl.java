package com.quqian.framework.message.achieve.topup;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.quqian.framework.message.topup.Extracter;
import com.quqian.framework.message.topup.entity.TopupTask;
import com.quqian.framework.service.ServiceFactory;
import com.quqian.framework.service.ServiceResource;

public class TopupExtracterImpl extends AbstractTopupService implements
		Extracter {
	public TopupExtracterImpl(ServiceResource serviceResource) {
		super(serviceResource);
	}

	public TopupTask[] extract(int maxCount, int expiresMinutes)
			throws Throwable {
		if (maxCount <= 0) {
			return null;
		}
		if (expiresMinutes <= 0) {
			expiresMinutes = 15;
		}
		List<TopupTask> sendTasks = null;
		try (Connection connection = getConnection()) {
			try (PreparedStatement ps = connection
					.prepareStatement("SELECT F01,F02,F03,F11 FROM T6066 WHERE F08<>? AND F07<=CURRENT_TIMESTAMP() AND F12<=10 ORDER BY F07 ASC LIMIT 0,?")) {
				ps.setString(1, "CG");
				ps.setInt(2, maxCount);
				try (ResultSet resultSet = ps.executeQuery()) {
					while (resultSet.next()) {
						if (sendTasks == null) {
							sendTasks = new ArrayList<TopupTask>();
						}
						TopupTask sendTask = new TopupTask();
						sendTask.id = resultSet.getLong(1);
						sendTask.sjh = resultSet.getString(2);
						sendTask.je = resultSet.getBigDecimal(3);
						sendTask.no = resultSet.getString(4);
						sendTasks.add(sendTask);
					}
				}
			}

			if (sendTasks == null) {
				return null;
			}
			try (PreparedStatement ps = connection
					.prepareStatement("UPDATE T6066 SET F07=ADDDATE(CURRENT_TIMESTAMP(),INTERVAL ? MINUTE) WHERE F01=?")) {
				for (Iterator<TopupTask> i$ = sendTasks.iterator(); i$
						.hasNext();) {
					TopupTask sendTask = (TopupTask) i$.next();
					if (sendTask != null) {
						ps.setInt(1,expiresMinutes);
						ps.setLong(2, sendTask.id);
						ps.addBatch();
					}
				}
				ps.executeBatch();
			}
			getConnection().commit();
		}

		return sendTasks == null ? null : (TopupTask[]) sendTasks
				.toArray(new TopupTask[sendTasks.size()]);
	}

	public void mark(long id, boolean success, String extra,String no) throws Throwable {
		if (id <= 0L) {
			return;
		}
		String _s = "UPDATE T6066 SET F08=?,F09=?,F11=?,F12=F12+1 WHERE F01=? AND F08<>?";
		try (Connection connection = getConnection()) {
			try (PreparedStatement ps = connection.prepareStatement(_s)) {
				if (success)
					ps.setString(1, "CG");
				else {
					ps.setString(1, "SB");
				}
				ps.setString(2, extra);
				ps.setString(3, no);
				ps.setLong(4, id);
				ps.setString(5, "CG");
				ps.execute();
			}
		}

	}
	
	public String getNo(String agent_id) throws Throwable {
		String s="SELECT CONCAT(DATE_FORMAT(NOW(),'%y%m%d%H%i%s'),?,LPAD(COUNT(*)+1,8,0)) FROM T6066 WHERE YEAR(F07)=YEAR(CURRENT_DATE()) AND MONTH(F07)=MONTH(CURRENT_DATE()) AND F11 IS NOT NULL";
		return selectString(getConnection(), s,agent_id);
	}

	public static class TopupExtracterFactory implements
			ServiceFactory<Extracter> {
		public Extracter newInstance(ServiceResource serviceResource) {
			return new TopupExtracterImpl(serviceResource);
		}
	}
}