package com.quqian.framework.service.query;

public abstract interface PagingResult<T> extends Paging
{
  public abstract int getItemCount();

  public abstract int getPageCount();

  public abstract T[] getItems();
}