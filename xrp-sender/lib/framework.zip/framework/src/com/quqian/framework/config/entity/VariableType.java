package com.quqian.framework.config.entity;

public abstract interface VariableType
{
  public abstract String getId();

  public abstract String getName();

  public abstract VariableBean[] getVariableBeans();
}