package com.quqian.framework.data.sql;

import com.quqian.framework.data.DataConnectionProvider;
import com.quqian.framework.log.Logger;
import com.quqian.framework.resource.InitParameterProvider;
import com.quqian.util.StringHelper;

import java.sql.SQLException;

public abstract class SQLConnectionProvider extends DataConnectionProvider
{
  public SQLConnectionProvider(InitParameterProvider parameterProvider, Logger logger)
  {
    super(parameterProvider, logger);
  }

  public abstract SQLConnection getConnection()
    throws SQLException;

  public SQLConnection getConnection(String schema)
    throws SQLException
  {
    SQLConnection connection = getConnection();
    if (!StringHelper.isEmpty(schema)) {
      connection.setSchema(schema);
    }
    return connection;
  }

  public final Class<? extends DataConnectionProvider> getIdentifiedType()
  {
    return SQLConnectionProvider.class;
  }

  public abstract String prefixMatch(String paramString);

  public abstract String subfixMatch(String paramString);

  public abstract String allMatch(String paramString);
}