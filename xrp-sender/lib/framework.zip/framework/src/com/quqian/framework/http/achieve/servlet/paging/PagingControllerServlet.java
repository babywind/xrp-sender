package com.quqian.framework.http.achieve.servlet.paging;

import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.http.servlet.Controller;
import com.quqian.framework.http.servlet.Rewriter;
import com.quqian.framework.http.servlet.annotation.PagingServlet;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.framework.resource.ResourceRegister;
import com.quqian.util.parser.IntegerParser;

import java.io.IOException;
import java.lang.reflect.Modifier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PagingControllerServlet extends HttpServlet
{
  private static final long serialVersionUID = 1L;
  protected static final Pattern PAGING_PATTERN = Pattern.compile("^\\d+/?$");
  protected final Pattern itemPattern;
  protected final PagingServlet pagingServlet;
  protected final Class<? extends HttpServlet> paging;
  protected final String path;

  public PagingControllerServlet(PagingServlet pagingServlet, Class<? extends HttpServlet> paging, String path, Pattern itemPattern)
  {
    this.pagingServlet = pagingServlet;
    this.paging = paging;
    this.path = path;
    this.itemPattern = itemPattern;
  }

  protected void service(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    String uri = request.getRequestURI();
    ResourceProvider resourceProvider = ResourceRegister.getResourceProvider(getServletContext());

    Controller controller = (Controller)resourceProvider.getResource(Controller.class);
    Rewriter rewriter = resourceProvider.getSystemDefine().getRewriter();
    if (uri.length() <= path.length()) {
      response.sendRedirect(controller.getViewURI(request, paging));
      return;
    }
    uri = uri.substring(path.length());
    Class itemServlet = pagingServlet.itemServlet();
    if (!Modifier.isAbstract(itemServlet.getModifiers())) {
      Matcher matcher = itemPattern.matcher(uri);
      if (matcher.matches()) {
        String id = uri.substring(0, uri.length() - rewriter.getViewSuffix().length());

        StringBuilder to = new StringBuilder();
        if (pagingServlet.viewItem()) {
          to.append(controller.getViewForwardURI(request, pagingServlet.itemServlet()));
        }
        else {
          to.append(controller.getForwardURI(request, pagingServlet.itemServlet()));
        }

        to.append('?').append(pagingServlet.itemToken()).append('=').append(id);

        request.getRequestDispatcher(to.toString()).forward(request, response);

        return;
      }
    }

    Matcher matcher = PAGING_PATTERN.matcher(uri);
    if (matcher.matches()) {
      int currentPage = 0;
      int endIndex = uri.length() - 1;
      if (uri.charAt(endIndex) == '/') {
        currentPage = IntegerParser.parse(uri.substring(0, endIndex));
      }
      else {
        currentPage = IntegerParser.parse(uri);
      }
      StringBuilder to = new StringBuilder();
      if (pagingServlet.viewPaging())
        to.append(controller.getViewForwardURI(request, paging));
      else {
        to.append(controller.getForwardURI(request, paging));
      }
      to.append('?').append(pagingServlet.currentToken()).append('=').append(currentPage);

      request.getRequestDispatcher(to.toString()).forward(request, response);

      return;
    }

    response.sendError(404);
  }
}