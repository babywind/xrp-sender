package com.quqian.framework.config;

public abstract interface Envionment
{
  public abstract String get(String paramString);

  public abstract void set(String paramString1, String paramString2);

  public abstract Object getArray(String paramString);

  public abstract void setArray(String paramString, Object paramObject);
}