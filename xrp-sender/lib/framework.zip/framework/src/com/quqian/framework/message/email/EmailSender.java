package com.quqian.framework.message.email;

import com.quqian.framework.service.Service;

public abstract interface EmailSender extends Service {
	public abstract void send(int paramInt, String paramString1,
			String paramString2, String... paramArrayOfString) throws Throwable;
}