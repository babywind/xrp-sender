package com.quqian.framework.resource.achieve;

import com.quqian.framework.resource.InitParameterProvider;

import java.util.Enumeration;

import javax.servlet.ServletContext;

public class ServletInitParameterProvider
  implements InitParameterProvider
{
  protected final ServletContext servletContext;

  public ServletInitParameterProvider(ServletContext servletContext)
  {
    this.servletContext = servletContext;
  }

  public String getInitParameter(String name)
  {
    return servletContext.getInitParameter(name);
  }

  public Enumeration<String> getInitParameterNames()
  {
    return servletContext.getInitParameterNames();
  }
}