package com.quqian.framework.http.session;

import com.quqian.framework.resource.Resource;
import com.quqian.framework.resource.ResourceProvider;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract class SessionManager extends Resource
  implements AutoCloseable
{
  public SessionManager(ResourceProvider resourceProvider)
  {
    super(resourceProvider);
  }

  public abstract Session getSession(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
  
  public abstract Session getSessionApp(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);

  public abstract Session getSession(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, boolean paramBoolean);
  
  public abstract Session getSessionApp(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, boolean paramBoolean);

  public final Class<? extends Resource> getIdentifiedType()
  {
    return SessionManager.class;
  }
}