package com.quqian.framework.service.achieve.proxy;

import com.quqian.framework.data.sql.SQLConnection;
import com.quqian.util.StringHelper;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;

public class SQLConnectionProxy implements SQLConnection {
	SQLConnection connection;
	protected String previousSchema = null;

	public SQLConnectionProxy(SQLConnection connection) {
		this.connection = connection;
	}

	public void _release() throws SQLException {
		if (connection != null) {
			connection.close();
			connection = null;
		}
	}

	public <T> T unwrap(Class<T> iface) throws SQLException {
		return connection.unwrap(iface);
	}

	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		return connection.isWrapperFor(iface);
	}

	public Statement createStatement() throws SQLException {
		return new StatementProxy(connection.createStatement());
	}

	public PreparedStatement prepareStatement(String sql) throws SQLException {
		return new PreparedStatementProxy(connection.prepareStatement(sql));
	}

	public CallableStatement prepareCall(String sql) throws SQLException {
		return connection.prepareCall(sql);
	}

	public String nativeSQL(String sql) throws SQLException {
		return connection.nativeSQL(sql);
	}

	public void setAutoCommit(boolean autoCommit) throws SQLException {
		connection.setAutoCommit(autoCommit);
	}

	public boolean getAutoCommit() throws SQLException {
		return connection.getAutoCommit();
	}

	public void commit() throws SQLException {
		connection.commit();
	}

	public void rollback() throws SQLException {
		connection.rollback();
	}

	public void close() throws SQLException {
		if (!StringHelper.isEmpty(previousSchema))
			connection.setSchema(previousSchema);
	}

	public boolean isClosed() throws SQLException {
		return connection.isClosed();
	}

	public DatabaseMetaData getMetaData() throws SQLException {
		return connection.getMetaData();
	}

	public void setReadOnly(boolean readOnly) throws SQLException {
		connection.setReadOnly(readOnly);
	}

	public boolean isReadOnly() throws SQLException {
		return connection.isReadOnly();
	}

	public void setCatalog(String catalog) throws SQLException {
		connection.setCatalog(catalog);
	}

	public String getCatalog() throws SQLException {
		return connection.getCatalog();
	}

	public void setTransactionIsolation(int level) throws SQLException {
		connection.setTransactionIsolation(level);
	}

	public int getTransactionIsolation() throws SQLException {
		return connection.getTransactionIsolation();
	}

	public SQLWarning getWarnings() throws SQLException {
		return connection.getWarnings();
	}

	public void clearWarnings() throws SQLException {
		connection.clearWarnings();
	}

	public Statement createStatement(int resultSetType, int resultSetConcurrency)
			throws SQLException {
		return connection.createStatement(resultSetType, resultSetConcurrency);
	}

	public PreparedStatement prepareStatement(String sql, int resultSetType,
			int resultSetConcurrency) throws SQLException {
		return connection.prepareStatement(sql, resultSetType,
				resultSetConcurrency);
	}

	public CallableStatement prepareCall(String sql, int resultSetType,
			int resultSetConcurrency) throws SQLException {
		return connection.prepareCall(sql, resultSetType, resultSetConcurrency);
	}

	public Map<String, Class<?>> getTypeMap() throws SQLException {
		return connection.getTypeMap();
	}

	public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
		connection.setTypeMap(map);
	}

	public void setHoldability(int holdability) throws SQLException {
		connection.setHoldability(holdability);
	}

	public int getHoldability() throws SQLException {
		return connection.getHoldability();
	}

	public Savepoint setSavepoint() throws SQLException {
		return connection.setSavepoint();
	}

	public Savepoint setSavepoint(String name) throws SQLException {
		return connection.setSavepoint(name);
	}

	public void rollback(Savepoint savepoint) throws SQLException {
		connection.rollback(savepoint);
	}

	public void releaseSavepoint(Savepoint savepoint) throws SQLException {
		connection.releaseSavepoint(savepoint);
	}

	public Statement createStatement(int resultSetType,
			int resultSetConcurrency, int resultSetHoldability)
			throws SQLException {
		return connection.createStatement(resultSetType, resultSetConcurrency,
				resultSetHoldability);
	}

	public PreparedStatement prepareStatement(String sql, int resultSetType,
			int resultSetConcurrency, int resultSetHoldability)
			throws SQLException {
		return connection.prepareStatement(sql, resultSetType,
				resultSetConcurrency, resultSetHoldability);
	}

	public CallableStatement prepareCall(String sql, int resultSetType,
			int resultSetConcurrency, int resultSetHoldability)
			throws SQLException {
		return connection.prepareCall(sql, resultSetType, resultSetConcurrency,
				resultSetHoldability);
	}

	public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys)
			throws SQLException {
		return connection.prepareStatement(sql, autoGeneratedKeys);
	}

	public PreparedStatement prepareStatement(String sql, int[] columnIndexes)
			throws SQLException {
		return connection.prepareStatement(sql, columnIndexes);
	}

	public PreparedStatement prepareStatement(String sql, String[] columnNames)
			throws SQLException {
		return connection.prepareStatement(sql, columnNames);
	}

	public Clob createClob() throws SQLException {
		return connection.createClob();
	}

	public Blob createBlob() throws SQLException {
		return connection.createBlob();
	}

	public NClob createNClob() throws SQLException {
		return connection.createNClob();
	}

	public SQLXML createSQLXML() throws SQLException {
		return connection.createSQLXML();
	}

	public boolean isValid(int timeout) throws SQLException {
		return connection.isValid(timeout);
	}

	public void setClientInfo(String name, String value)
			throws SQLClientInfoException {
		connection.setClientInfo(name, value);
	}

	public void setClientInfo(Properties properties)
			throws SQLClientInfoException {
		connection.setClientInfo(properties);
	}

	public String getClientInfo(String name) throws SQLException {
		return connection.getClientInfo(name);
	}

	public Properties getClientInfo() throws SQLException {
		return connection.getClientInfo();
	}

	public Array createArrayOf(String typeName, Object[] elements)
			throws SQLException {
		return connection.createArrayOf(typeName, elements);
	}

	public Struct createStruct(String typeName, Object[] attributes)
			throws SQLException {
		return connection.createStruct(typeName, attributes);
	}

	public void setSchema(String schema) throws SQLException {
		if (StringHelper.isEmpty(schema)) {
			return;
		}
		if (previousSchema == null) {
			previousSchema = connection.getSchema();
		}
		connection.setSchema(schema);
	}

	public String getSchema() throws SQLException {
		return connection.getSchema();
	}

	public void abort(Executor executor) throws SQLException {
		connection.abort(executor);
	}

	public void setNetworkTimeout(Executor executor, int milliseconds)
			throws SQLException {
		connection.setNetworkTimeout(executor, milliseconds);
	}

	public int getNetworkTimeout() throws SQLException {
		return connection.getNetworkTimeout();
	}

	class ResultSetProxy implements ResultSet {
		ResultSet resultSet;

		public ResultSetProxy(ResultSet resultSet) {
			this.resultSet = resultSet;
		}

		public <T> T unwrap(Class<T> iface) throws SQLException {
			return resultSet.unwrap(iface);
		}

		public boolean isWrapperFor(Class<?> iface) throws SQLException {
			return resultSet.isWrapperFor(iface);
		}

		public boolean next() throws SQLException {
			return resultSet.next();
		}

		public void close() throws SQLException {
			resultSet.close();
		}

		public boolean wasNull() throws SQLException {
			return resultSet.wasNull();
		}

		public String getString(int columnIndex) throws SQLException {
			return resultSet.getString(columnIndex);
		}

		public boolean getBoolean(int columnIndex) throws SQLException {
			return resultSet.getBoolean(columnIndex);
		}

		public byte getByte(int columnIndex) throws SQLException {
			return resultSet.getByte(columnIndex);
		}

		public short getShort(int columnIndex) throws SQLException {
			return resultSet.getShort(columnIndex);
		}

		public int getInt(int columnIndex) throws SQLException {
			return resultSet.getInt(columnIndex);
		}

		public long getLong(int columnIndex) throws SQLException {
			return resultSet.getLong(columnIndex);
		}

		public float getFloat(int columnIndex) throws SQLException {
			return resultSet.getFloat(columnIndex);
		}

		public double getDouble(int columnIndex) throws SQLException {
			return resultSet.getDouble(columnIndex);
		}

		@Deprecated
		public BigDecimal getBigDecimal(int columnIndex, int scale)
				throws SQLException {
			BigDecimal bigDecimal = resultSet.getBigDecimal(columnIndex, scale);
			if (bigDecimal == null) {
				bigDecimal = new BigDecimal(0);
			}
			return bigDecimal;
		}

		public byte[] getBytes(int columnIndex) throws SQLException {
			return resultSet.getBytes(columnIndex);
		}

		public Date getDate(int columnIndex) throws SQLException {
			return resultSet.getDate(columnIndex);
		}

		public Time getTime(int columnIndex) throws SQLException {
			return resultSet.getTime(columnIndex);
		}

		public Timestamp getTimestamp(int columnIndex) throws SQLException {
			return resultSet.getTimestamp(columnIndex);
		}

		public InputStream getAsciiStream(int columnIndex) throws SQLException {
			return resultSet.getAsciiStream(columnIndex);
		}

		@Deprecated
		public InputStream getUnicodeStream(int columnIndex)
				throws SQLException {
			return resultSet.getUnicodeStream(columnIndex);
		}

		public InputStream getBinaryStream(int columnIndex) throws SQLException {
			return resultSet.getBinaryStream(columnIndex);
		}

		public String getString(String columnLabel) throws SQLException {
			return resultSet.getString(columnLabel);
		}

		public boolean getBoolean(String columnLabel) throws SQLException {
			return resultSet.getBoolean(columnLabel);
		}

		public byte getByte(String columnLabel) throws SQLException {
			return resultSet.getByte(columnLabel);
		}

		public short getShort(String columnLabel) throws SQLException {
			return resultSet.getShort(columnLabel);
		}

		public int getInt(String columnLabel) throws SQLException {
			return resultSet.getInt(columnLabel);
		}

		public long getLong(String columnLabel) throws SQLException {
			return resultSet.getLong(columnLabel);
		}

		public float getFloat(String columnLabel) throws SQLException {
			return resultSet.getFloat(columnLabel);
		}

		public double getDouble(String columnLabel) throws SQLException {
			return resultSet.getDouble(columnLabel);
		}

		@Deprecated
		public BigDecimal getBigDecimal(String columnLabel, int scale)
				throws SQLException {
			BigDecimal bigDecimal = resultSet.getBigDecimal(columnLabel, scale);
			if (bigDecimal == null) {
				bigDecimal = new BigDecimal(0);
			}
			return bigDecimal;
		}

		public byte[] getBytes(String columnLabel) throws SQLException {
			return resultSet.getBytes(columnLabel);
		}

		public Date getDate(String columnLabel) throws SQLException {
			try {
				return resultSet.getDate(columnLabel);
			} catch (SQLException e) {
			}
			return null;
		}

		public Time getTime(String columnLabel) throws SQLException {
			try {
				return resultSet.getTime(columnLabel);
			} catch (SQLException e) {
			}
			return null;
		}

		public Timestamp getTimestamp(String columnLabel) throws SQLException {
			try {
				return resultSet.getTimestamp(columnLabel);
			} catch (SQLException e) {
			}
			return null;
		}

		public InputStream getAsciiStream(String columnLabel)
				throws SQLException {
			return resultSet.getAsciiStream(columnLabel);
		}

		@Deprecated
		public InputStream getUnicodeStream(String columnLabel)
				throws SQLException {
			return resultSet.getUnicodeStream(columnLabel);
		}

		public InputStream getBinaryStream(String columnLabel)
				throws SQLException {
			return resultSet.getBinaryStream(columnLabel);
		}

		public SQLWarning getWarnings() throws SQLException {
			return resultSet.getWarnings();
		}

		public void clearWarnings() throws SQLException {
			resultSet.clearWarnings();
		}

		public String getCursorName() throws SQLException {
			return resultSet.getCursorName();
		}

		public ResultSetMetaData getMetaData() throws SQLException {
			return resultSet.getMetaData();
		}

		public Object getObject(int columnIndex) throws SQLException {
			return resultSet.getObject(columnIndex);
		}

		public Object getObject(String columnLabel) throws SQLException {
			return resultSet.getObject(columnLabel);
		}

		public int findColumn(String columnLabel) throws SQLException {
			return resultSet.findColumn(columnLabel);
		}

		public Reader getCharacterStream(int columnIndex) throws SQLException {
			return resultSet.getCharacterStream(columnIndex);
		}

		public Reader getCharacterStream(String columnLabel)
				throws SQLException {
			return resultSet.getCharacterStream(columnLabel);
		}

		public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
			BigDecimal bigDecimal = resultSet.getBigDecimal(columnIndex);
			if (bigDecimal == null) {
				bigDecimal = new BigDecimal(0);
			}
			return bigDecimal;
		}

		public BigDecimal getBigDecimal(String columnLabel) throws SQLException {
			BigDecimal bigDecimal = resultSet.getBigDecimal(columnLabel);
			if (bigDecimal == null) {
				bigDecimal = new BigDecimal(0);
			}
			return bigDecimal;
		}

		public boolean isBeforeFirst() throws SQLException {
			return resultSet.isBeforeFirst();
		}

		public boolean isAfterLast() throws SQLException {
			return resultSet.isAfterLast();
		}

		public boolean isFirst() throws SQLException {
			return resultSet.isFirst();
		}

		public boolean isLast() throws SQLException {
			return resultSet.isLast();
		}

		public void beforeFirst() throws SQLException {
			resultSet.beforeFirst();
		}

		public void afterLast() throws SQLException {
			resultSet.afterLast();
		}

		public boolean first() throws SQLException {
			return resultSet.first();
		}

		public boolean last() throws SQLException {
			return resultSet.last();
		}

		public int getRow() throws SQLException {
			return resultSet.getRow();
		}

		public boolean absolute(int row) throws SQLException {
			return resultSet.absolute(row);
		}

		public boolean relative(int rows) throws SQLException {
			return resultSet.relative(rows);
		}

		public boolean previous() throws SQLException {
			return resultSet.previous();
		}

		public void setFetchDirection(int direction) throws SQLException {
			resultSet.setFetchDirection(direction);
		}

		public int getFetchDirection() throws SQLException {
			return resultSet.getFetchDirection();
		}

		public void setFetchSize(int rows) throws SQLException {
			resultSet.setFetchSize(rows);
		}

		public int getFetchSize() throws SQLException {
			return resultSet.getFetchSize();
		}

		public int getType() throws SQLException {
			return resultSet.getType();
		}

		public int getConcurrency() throws SQLException {
			return resultSet.getConcurrency();
		}

		public boolean rowUpdated() throws SQLException {
			return resultSet.rowUpdated();
		}

		public boolean rowInserted() throws SQLException {
			return resultSet.rowInserted();
		}

		public boolean rowDeleted() throws SQLException {
			return resultSet.rowDeleted();
		}

		public void updateNull(int columnIndex) throws SQLException {
			resultSet.updateNull(columnIndex);
		}

		public void updateBoolean(int columnIndex, boolean x)
				throws SQLException {
			resultSet.updateBoolean(columnIndex, x);
		}

		public void updateByte(int columnIndex, byte x) throws SQLException {
			resultSet.updateByte(columnIndex, x);
		}

		public void updateShort(int columnIndex, short x) throws SQLException {
			resultSet.updateShort(columnIndex, x);
		}

		public void updateInt(int columnIndex, int x) throws SQLException {
			resultSet.updateInt(columnIndex, x);
		}

		public void updateLong(int columnIndex, long x) throws SQLException {
			resultSet.updateLong(columnIndex, x);
		}

		public void updateFloat(int columnIndex, float x) throws SQLException {
			resultSet.updateFloat(columnIndex, x);
		}

		public void updateDouble(int columnIndex, double x) throws SQLException {
			resultSet.updateDouble(columnIndex, x);
		}

		public void updateBigDecimal(int columnIndex, BigDecimal x)
				throws SQLException {
			resultSet.updateBigDecimal(columnIndex, x);
		}

		public void updateString(int columnIndex, String x) throws SQLException {
			resultSet.updateString(columnIndex, x);
		}

		public void updateBytes(int columnIndex, byte[] x) throws SQLException {
			resultSet.updateBytes(columnIndex, x);
		}

		public void updateDate(int columnIndex, Date x) throws SQLException {
			resultSet.updateDate(columnIndex, x);
		}

		public void updateTime(int columnIndex, Time x) throws SQLException {
			resultSet.updateTime(columnIndex, x);
		}

		public void updateTimestamp(int columnIndex, Timestamp x)
				throws SQLException {
			resultSet.updateTimestamp(columnIndex, x);
		}

		public void updateAsciiStream(int columnIndex, InputStream x, int length)
				throws SQLException {
			resultSet.updateAsciiStream(columnIndex, x, length);
		}

		public void updateBinaryStream(int columnIndex, InputStream x,
				int length) throws SQLException {
			resultSet.updateBinaryStream(columnIndex, x, length);
		}

		public void updateCharacterStream(int columnIndex, Reader x, int length)
				throws SQLException {
			resultSet.updateCharacterStream(columnIndex, x, length);
		}

		public void updateObject(int columnIndex, Object x, int scaleOrLength)
				throws SQLException {
			resultSet.updateObject(columnIndex, x, scaleOrLength);
		}

		public void updateObject(int columnIndex, Object x) throws SQLException {
			resultSet.updateObject(columnIndex, x);
		}

		public void updateNull(String columnLabel) throws SQLException {
			resultSet.updateNull(columnLabel);
		}

		public void updateBoolean(String columnLabel, boolean x)
				throws SQLException {
			resultSet.updateBoolean(columnLabel, x);
		}

		public void updateByte(String columnLabel, byte x) throws SQLException {
			resultSet.updateByte(columnLabel, x);
		}

		public void updateShort(String columnLabel, short x)
				throws SQLException {
			resultSet.updateShort(columnLabel, x);
		}

		public void updateInt(String columnLabel, int x) throws SQLException {
			resultSet.updateInt(columnLabel, x);
		}

		public void updateLong(String columnLabel, long x) throws SQLException {
			resultSet.updateLong(columnLabel, x);
		}

		public void updateFloat(String columnLabel, float x)
				throws SQLException {
			resultSet.updateFloat(columnLabel, x);
		}

		public void updateDouble(String columnLabel, double x)
				throws SQLException {
			resultSet.updateDouble(columnLabel, x);
		}

		public void updateBigDecimal(String columnLabel, BigDecimal x)
				throws SQLException {
			resultSet.updateBigDecimal(columnLabel, x);
		}

		public void updateString(String columnLabel, String x)
				throws SQLException {
			resultSet.updateString(columnLabel, x);
		}

		public void updateBytes(String columnLabel, byte[] x)
				throws SQLException {
			resultSet.updateBytes(columnLabel, x);
		}

		public void updateDate(String columnLabel, Date x) throws SQLException {
			resultSet.updateDate(columnLabel, x);
		}

		public void updateTime(String columnLabel, Time x) throws SQLException {
			resultSet.updateTime(columnLabel, x);
		}

		public void updateTimestamp(String columnLabel, Timestamp x)
				throws SQLException {
			resultSet.updateTimestamp(columnLabel, x);
		}

		public void updateAsciiStream(String columnLabel, InputStream x,
				int length) throws SQLException {
			resultSet.updateAsciiStream(columnLabel, x, length);
		}

		public void updateBinaryStream(String columnLabel, InputStream x,
				int length) throws SQLException {
			resultSet.updateBinaryStream(columnLabel, x, length);
		}

		public void updateCharacterStream(String columnLabel, Reader reader,
				int length) throws SQLException {
			resultSet.updateCharacterStream(columnLabel, reader, length);
		}

		public void updateObject(String columnLabel, Object x, int scaleOrLength)
				throws SQLException {
			resultSet.updateObject(columnLabel, x, scaleOrLength);
		}

		public void updateObject(String columnLabel, Object x)
				throws SQLException {
			resultSet.updateObject(columnLabel, x);
		}

		public void insertRow() throws SQLException {
			resultSet.insertRow();
		}

		public void updateRow() throws SQLException {
			resultSet.updateRow();
		}

		public void deleteRow() throws SQLException {
			resultSet.deleteRow();
		}

		public void refreshRow() throws SQLException {
			resultSet.refreshRow();
		}

		public void cancelRowUpdates() throws SQLException {
			resultSet.cancelRowUpdates();
		}

		public void moveToInsertRow() throws SQLException {
			resultSet.moveToInsertRow();
		}

		public void moveToCurrentRow() throws SQLException {
			resultSet.moveToCurrentRow();
		}

		public Statement getStatement() throws SQLException {
			return resultSet.getStatement();
		}

		public Object getObject(int columnIndex, Map<String, Class<?>> map)
				throws SQLException {
			return resultSet.getObject(columnIndex, map);
		}

		public Ref getRef(int columnIndex) throws SQLException {
			return resultSet.getRef(columnIndex);
		}

		public Blob getBlob(int columnIndex) throws SQLException {
			return resultSet.getBlob(columnIndex);
		}

		public Clob getClob(int columnIndex) throws SQLException {
			return resultSet.getClob(columnIndex);
		}

		public Array getArray(int columnIndex) throws SQLException {
			return resultSet.getArray(columnIndex);
		}

		public Object getObject(String columnLabel, Map<String, Class<?>> map)
				throws SQLException {
			return resultSet.getObject(columnLabel, map);
		}

		public Ref getRef(String columnLabel) throws SQLException {
			return resultSet.getRef(columnLabel);
		}

		public Blob getBlob(String columnLabel) throws SQLException {
			return resultSet.getBlob(columnLabel);
		}

		public Clob getClob(String columnLabel) throws SQLException {
			return resultSet.getClob(columnLabel);
		}

		public Array getArray(String columnLabel) throws SQLException {
			return resultSet.getArray(columnLabel);
		}

		public Date getDate(int columnIndex, Calendar cal) throws SQLException {
			return resultSet.getDate(columnIndex, cal);
		}

		public Date getDate(String columnLabel, Calendar cal)
				throws SQLException {
			return resultSet.getDate(columnLabel, cal);
		}

		public Time getTime(int columnIndex, Calendar cal) throws SQLException {
			return resultSet.getTime(columnIndex, cal);
		}

		public Time getTime(String columnLabel, Calendar cal)
				throws SQLException {
			return resultSet.getTime(columnLabel, cal);
		}

		public Timestamp getTimestamp(int columnIndex, Calendar cal)
				throws SQLException {
			return resultSet.getTimestamp(columnIndex, cal);
		}

		public Timestamp getTimestamp(String columnLabel, Calendar cal)
				throws SQLException {
			return resultSet.getTimestamp(columnLabel, cal);
		}

		public URL getURL(int columnIndex) throws SQLException {
			return resultSet.getURL(columnIndex);
		}

		public URL getURL(String columnLabel) throws SQLException {
			return resultSet.getURL(columnLabel);
		}

		public void updateRef(int columnIndex, Ref x) throws SQLException {
			resultSet.updateRef(columnIndex, x);
		}

		public void updateRef(String columnLabel, Ref x) throws SQLException {
			resultSet.updateRef(columnLabel, x);
		}

		public void updateBlob(int columnIndex, Blob x) throws SQLException {
			resultSet.updateBlob(columnIndex, x);
		}

		public void updateBlob(String columnLabel, Blob x) throws SQLException {
			resultSet.updateBlob(columnLabel, x);
		}

		public void updateClob(int columnIndex, Clob x) throws SQLException {
			resultSet.updateClob(columnIndex, x);
		}

		public void updateClob(String columnLabel, Clob x) throws SQLException {
			resultSet.updateClob(columnLabel, x);
		}

		public void updateArray(int columnIndex, Array x) throws SQLException {
			resultSet.updateArray(columnIndex, x);
		}

		public void updateArray(String columnLabel, Array x)
				throws SQLException {
			resultSet.updateArray(columnLabel, x);
		}

		public RowId getRowId(int columnIndex) throws SQLException {
			return resultSet.getRowId(columnIndex);
		}

		public RowId getRowId(String columnLabel) throws SQLException {
			return resultSet.getRowId(columnLabel);
		}

		public void updateRowId(int columnIndex, RowId x) throws SQLException {
			resultSet.updateRowId(columnIndex, x);
		}

		public void updateRowId(String columnLabel, RowId x)
				throws SQLException {
			resultSet.updateRowId(columnLabel, x);
		}

		public int getHoldability() throws SQLException {
			return resultSet.getHoldability();
		}

		public boolean isClosed() throws SQLException {
			return resultSet.isClosed();
		}

		public void updateNString(int columnIndex, String nString)
				throws SQLException {
			resultSet.updateNString(columnIndex, nString);
		}

		public void updateNString(String columnLabel, String nString)
				throws SQLException {
			resultSet.updateNString(columnLabel, nString);
		}

		public void updateNClob(int columnIndex, NClob nClob)
				throws SQLException {
			resultSet.updateNClob(columnIndex, nClob);
		}

		public void updateNClob(String columnLabel, NClob nClob)
				throws SQLException {
			resultSet.updateNClob(columnLabel, nClob);
		}

		public NClob getNClob(int columnIndex) throws SQLException {
			return resultSet.getNClob(columnIndex);
		}

		public NClob getNClob(String columnLabel) throws SQLException {
			return resultSet.getNClob(columnLabel);
		}

		public SQLXML getSQLXML(int columnIndex) throws SQLException {
			return resultSet.getSQLXML(columnIndex);
		}

		public SQLXML getSQLXML(String columnLabel) throws SQLException {
			return resultSet.getSQLXML(columnLabel);
		}

		public void updateSQLXML(int columnIndex, SQLXML xmlObject)
				throws SQLException {
			resultSet.updateSQLXML(columnIndex, xmlObject);
		}

		public void updateSQLXML(String columnLabel, SQLXML xmlObject)
				throws SQLException {
			resultSet.updateSQLXML(columnLabel, xmlObject);
		}

		public String getNString(int columnIndex) throws SQLException {
			return resultSet.getNString(columnIndex);
		}

		public String getNString(String columnLabel) throws SQLException {
			return resultSet.getNString(columnLabel);
		}

		public Reader getNCharacterStream(int columnIndex) throws SQLException {
			return resultSet.getNCharacterStream(columnIndex);
		}

		public Reader getNCharacterStream(String columnLabel)
				throws SQLException {
			return resultSet.getNCharacterStream(columnLabel);
		}

		public void updateNCharacterStream(int columnIndex, Reader x,
				long length) throws SQLException {
			resultSet.updateNCharacterStream(columnIndex, x, length);
		}

		public void updateNCharacterStream(String columnLabel, Reader reader,
				long length) throws SQLException {
			resultSet.updateNCharacterStream(columnLabel, reader, length);
		}

		public void updateAsciiStream(int columnIndex, InputStream x,
				long length) throws SQLException {
			resultSet.updateAsciiStream(columnIndex, x, length);
		}

		public void updateBinaryStream(int columnIndex, InputStream x,
				long length) throws SQLException {
			resultSet.updateBinaryStream(columnIndex, x, length);
		}

		public void updateCharacterStream(int columnIndex, Reader x, long length)
				throws SQLException {
			resultSet.updateCharacterStream(columnIndex, x, length);
		}

		public void updateAsciiStream(String columnLabel, InputStream x,
				long length) throws SQLException {
			resultSet.updateAsciiStream(columnLabel, x, length);
		}

		public void updateBinaryStream(String columnLabel, InputStream x,
				long length) throws SQLException {
			resultSet.updateBinaryStream(columnLabel, x, length);
		}

		public void updateCharacterStream(String columnLabel, Reader reader,
				long length) throws SQLException {
			resultSet.updateCharacterStream(columnLabel, reader, length);
		}

		public void updateBlob(int columnIndex, InputStream inputStream,
				long length) throws SQLException {
			resultSet.updateBlob(columnIndex, inputStream, length);
		}

		public void updateBlob(String columnLabel, InputStream inputStream,
				long length) throws SQLException {
			resultSet.updateBlob(columnLabel, inputStream, length);
		}

		public void updateClob(int columnIndex, Reader reader, long length)
				throws SQLException {
			resultSet.updateClob(columnIndex, reader, length);
		}

		public void updateClob(String columnLabel, Reader reader, long length)
				throws SQLException {
			resultSet.updateClob(columnLabel, reader, length);
		}

		public void updateNClob(int columnIndex, Reader reader, long length)
				throws SQLException {
			resultSet.updateNClob(columnIndex, reader, length);
		}

		public void updateNClob(String columnLabel, Reader reader, long length)
				throws SQLException {
			resultSet.updateNClob(columnLabel, reader, length);
		}

		public void updateNCharacterStream(int columnIndex, Reader x)
				throws SQLException {
			resultSet.updateNCharacterStream(columnIndex, x);
		}

		public void updateNCharacterStream(String columnLabel, Reader reader)
				throws SQLException {
			resultSet.updateNCharacterStream(columnLabel, reader);
		}

		public void updateAsciiStream(int columnIndex, InputStream x)
				throws SQLException {
			resultSet.updateAsciiStream(columnIndex, x);
		}

		public void updateBinaryStream(int columnIndex, InputStream x)
				throws SQLException {
			resultSet.updateBinaryStream(columnIndex, x);
		}

		public void updateCharacterStream(int columnIndex, Reader x)
				throws SQLException {
			resultSet.updateCharacterStream(columnIndex, x);
		}

		public void updateAsciiStream(String columnLabel, InputStream x)
				throws SQLException {
			resultSet.updateAsciiStream(columnLabel, x);
		}

		public void updateBinaryStream(String columnLabel, InputStream x)
				throws SQLException {
			resultSet.updateBinaryStream(columnLabel, x);
		}

		public void updateCharacterStream(String columnLabel, Reader reader)
				throws SQLException {
			resultSet.updateCharacterStream(columnLabel, reader);
		}

		public void updateBlob(int columnIndex, InputStream inputStream)
				throws SQLException {
			resultSet.updateBlob(columnIndex, inputStream);
		}

		public void updateBlob(String columnLabel, InputStream inputStream)
				throws SQLException {
			resultSet.updateBlob(columnLabel, inputStream);
		}

		public void updateClob(int columnIndex, Reader reader)
				throws SQLException {
			resultSet.updateClob(columnIndex, reader);
		}

		public void updateClob(String columnLabel, Reader reader)
				throws SQLException {
			resultSet.updateClob(columnLabel, reader);
		}

		public void updateNClob(int columnIndex, Reader reader)
				throws SQLException {
			resultSet.updateNClob(columnIndex, reader);
		}

		public void updateNClob(String columnLabel, Reader reader)
				throws SQLException {
			resultSet.updateNClob(columnLabel, reader);
		}

		public <T> T getObject(int columnIndex, Class<T> type)
				throws SQLException {
			return resultSet.getObject(columnIndex, type);
		}

		public <T> T getObject(String columnLabel, Class<T> type)
				throws SQLException {
			return resultSet.getObject(columnLabel, type);
		}
	}

	class CallableStatementProxy extends
			SQLConnectionProxy.PreparedStatementProxy implements
			CallableStatement {
		CallableStatement innerCallableStatement;

		public CallableStatementProxy(CallableStatement callableStatement) {
			super(callableStatement);
			innerCallableStatement = callableStatement;
		}

		public <T> T unwrap(Class<T> iface) throws SQLException {
			return innerCallableStatement.unwrap(iface);
		}

		public ResultSet executeQuery(String sql) throws SQLException {
			return new SQLConnectionProxy.ResultSetProxy(
					innerCallableStatement.executeQuery(sql));
		}

		public ResultSet executeQuery() throws SQLException {
			return new SQLConnectionProxy.ResultSetProxy(
					innerCallableStatement.executeQuery());
		}

		public void registerOutParameter(int parameterIndex, int sqlType)
				throws SQLException {
			innerCallableStatement
					.registerOutParameter(parameterIndex, sqlType);
		}

		public boolean isWrapperFor(Class<?> iface) throws SQLException {
			return innerCallableStatement.isWrapperFor(iface);
		}

		public int executeUpdate(String sql) throws SQLException {
			return innerCallableStatement.executeUpdate(sql);
		}

		public int executeUpdate() throws SQLException {
			return innerCallableStatement.executeUpdate();
		}

		public void setNull(int parameterIndex, int sqlType)
				throws SQLException {
			innerCallableStatement.setNull(parameterIndex, sqlType);
		}

		public void close() throws SQLException {
			innerCallableStatement.close();
		}

		public void registerOutParameter(int parameterIndex, int sqlType,
				int scale) throws SQLException {
			innerCallableStatement.registerOutParameter(parameterIndex,
					sqlType, scale);
		}

		public int getMaxFieldSize() throws SQLException {
			return innerCallableStatement.getMaxFieldSize();
		}

		public void setBoolean(int parameterIndex, boolean x)
				throws SQLException {
			innerCallableStatement.setBoolean(parameterIndex, x);
		}

		public void setByte(int parameterIndex, byte x) throws SQLException {
			innerCallableStatement.setByte(parameterIndex, x);
		}

		public void setMaxFieldSize(int max) throws SQLException {
			innerCallableStatement.setMaxFieldSize(max);
		}

		public boolean wasNull() throws SQLException {
			return innerCallableStatement.wasNull();
		}

		public void setShort(int parameterIndex, short x) throws SQLException {
			innerCallableStatement.setShort(parameterIndex, x);
		}

		public String getString(int parameterIndex) throws SQLException {
			return innerCallableStatement.getString(parameterIndex);
		}

		public int getMaxRows() throws SQLException {
			return innerCallableStatement.getMaxRows();
		}

		public void setInt(int parameterIndex, int x) throws SQLException {
			innerCallableStatement.setInt(parameterIndex, x);
		}

		public void setMaxRows(int max) throws SQLException {
			innerCallableStatement.setMaxRows(max);
		}

		public void setLong(int parameterIndex, long x) throws SQLException {
			innerCallableStatement.setLong(parameterIndex, x);
		}

		public boolean getBoolean(int parameterIndex) throws SQLException {
			return innerCallableStatement.getBoolean(parameterIndex);
		}

		public void setEscapeProcessing(boolean enable) throws SQLException {
			innerCallableStatement.setEscapeProcessing(enable);
		}

		public void setFloat(int parameterIndex, float x) throws SQLException {
			innerCallableStatement.setFloat(parameterIndex, x);
		}

		public byte getByte(int parameterIndex) throws SQLException {
			return innerCallableStatement.getByte(parameterIndex);
		}

		public void setDouble(int parameterIndex, double x) throws SQLException {
			innerCallableStatement.setDouble(parameterIndex, x);
		}

		public int getQueryTimeout() throws SQLException {
			return innerCallableStatement.getQueryTimeout();
		}

		public short getShort(int parameterIndex) throws SQLException {
			return innerCallableStatement.getShort(parameterIndex);
		}

		public void setQueryTimeout(int seconds) throws SQLException {
			innerCallableStatement.setQueryTimeout(seconds);
		}

		public void setBigDecimal(int parameterIndex, BigDecimal x)
				throws SQLException {
			innerCallableStatement.setBigDecimal(parameterIndex, x);
		}

		public int getInt(int parameterIndex) throws SQLException {
			return innerCallableStatement.getInt(parameterIndex);
		}

		public void setString(int parameterIndex, String x) throws SQLException {
			innerCallableStatement.setString(parameterIndex, x);
		}

		public long getLong(int parameterIndex) throws SQLException {
			return innerCallableStatement.getLong(parameterIndex);
		}

		public void setBytes(int parameterIndex, byte[] x) throws SQLException {
			innerCallableStatement.setBytes(parameterIndex, x);
		}

		public float getFloat(int parameterIndex) throws SQLException {
			return innerCallableStatement.getFloat(parameterIndex);
		}

		public void cancel() throws SQLException {
			innerCallableStatement.cancel();
		}

		public SQLWarning getWarnings() throws SQLException {
			return innerCallableStatement.getWarnings();
		}

		public double getDouble(int parameterIndex) throws SQLException {
			return innerCallableStatement.getDouble(parameterIndex);
		}

		public void setDate(int parameterIndex, Date x) throws SQLException {
			innerCallableStatement.setDate(parameterIndex, x);
		}

		/** @deprecated */
		public BigDecimal getBigDecimal(int parameterIndex, int scale)
				throws SQLException {
			return innerCallableStatement.getBigDecimal(parameterIndex, scale);
		}

		public void setTime(int parameterIndex, Time x) throws SQLException {
			innerCallableStatement.setTime(parameterIndex, x);
		}

		public void clearWarnings() throws SQLException {
			innerCallableStatement.clearWarnings();
		}

		public void setCursorName(String name) throws SQLException {
			innerCallableStatement.setCursorName(name);
		}

		public void setTimestamp(int parameterIndex, Timestamp x)
				throws SQLException {
			innerCallableStatement.setTimestamp(parameterIndex, x);
		}

		public byte[] getBytes(int parameterIndex) throws SQLException {
			return innerCallableStatement.getBytes(parameterIndex);
		}

		public void setAsciiStream(int parameterIndex, InputStream x, int length)
				throws SQLException {
			innerCallableStatement.setAsciiStream(parameterIndex, x, length);
		}

		public Date getDate(int parameterIndex) throws SQLException {
			return innerCallableStatement.getDate(parameterIndex);
		}

		public boolean execute(String sql) throws SQLException {
			return innerCallableStatement.execute(sql);
		}

		public Time getTime(int parameterIndex) throws SQLException {
			return innerCallableStatement.getTime(parameterIndex);
		}

		/** @deprecated */
		public void setUnicodeStream(int parameterIndex, InputStream x,
				int length) throws SQLException {
			innerCallableStatement.setUnicodeStream(parameterIndex, x, length);
		}

		public Timestamp getTimestamp(int parameterIndex) throws SQLException {
			return innerCallableStatement.getTimestamp(parameterIndex);
		}

		public Object getObject(int parameterIndex) throws SQLException {
			return innerCallableStatement.getObject(parameterIndex);
		}

		public ResultSet getResultSet() throws SQLException {
			return innerCallableStatement.getResultSet();
		}

		public void setBinaryStream(int parameterIndex, InputStream x,
				int length) throws SQLException {
			innerCallableStatement.setBinaryStream(parameterIndex, x, length);
		}

		public int getUpdateCount() throws SQLException {
			return innerCallableStatement.getUpdateCount();
		}

		public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
			return innerCallableStatement.getBigDecimal(parameterIndex);
		}

		public boolean getMoreResults() throws SQLException {
			return innerCallableStatement.getMoreResults();
		}

		public void clearParameters() throws SQLException {
			innerCallableStatement.clearParameters();
		}

		public Object getObject(int parameterIndex, Map<String, Class<?>> map)
				throws SQLException {
			return innerCallableStatement.getObject(parameterIndex, map);
		}

		public void setObject(int parameterIndex, Object x, int targetSqlType)
				throws SQLException {
			innerCallableStatement.setObject(parameterIndex, x, targetSqlType);
		}

		public void setFetchDirection(int direction) throws SQLException {
			innerCallableStatement.setFetchDirection(direction);
		}

		public Ref getRef(int parameterIndex) throws SQLException {
			return innerCallableStatement.getRef(parameterIndex);
		}

		public int getFetchDirection() throws SQLException {
			return innerCallableStatement.getFetchDirection();
		}

		public void setObject(int parameterIndex, Object x) throws SQLException {
			innerCallableStatement.setObject(parameterIndex, x);
		}

		public Blob getBlob(int parameterIndex) throws SQLException {
			return innerCallableStatement.getBlob(parameterIndex);
		}

		public void setFetchSize(int rows) throws SQLException {
			innerCallableStatement.setFetchSize(rows);
		}

		public Clob getClob(int parameterIndex) throws SQLException {
			return innerCallableStatement.getClob(parameterIndex);
		}

		public int getFetchSize() throws SQLException {
			return innerCallableStatement.getFetchSize();
		}

		public int getResultSetConcurrency() throws SQLException {
			return innerCallableStatement.getResultSetConcurrency();
		}

		public Array getArray(int parameterIndex) throws SQLException {
			return innerCallableStatement.getArray(parameterIndex);
		}

		public boolean execute() throws SQLException {
			return innerCallableStatement.execute();
		}

		public int getResultSetType() throws SQLException {
			return innerCallableStatement.getResultSetType();
		}

		public Date getDate(int parameterIndex, Calendar cal)
				throws SQLException {
			return innerCallableStatement.getDate(parameterIndex, cal);
		}

		public void addBatch(String sql) throws SQLException {
			innerCallableStatement.addBatch(sql);
		}

		public void clearBatch() throws SQLException {
			innerCallableStatement.clearBatch();
		}

		public void addBatch() throws SQLException {
			innerCallableStatement.addBatch();
		}

		public Time getTime(int parameterIndex, Calendar cal)
				throws SQLException {
			return innerCallableStatement.getTime(parameterIndex, cal);
		}

		public int[] executeBatch() throws SQLException {
			return innerCallableStatement.executeBatch();
		}

		public void setCharacterStream(int parameterIndex, Reader reader,
				int length) throws SQLException {
			innerCallableStatement.setCharacterStream(parameterIndex, reader,
					length);
		}

		public Timestamp getTimestamp(int parameterIndex, Calendar cal)
				throws SQLException {
			return innerCallableStatement.getTimestamp(parameterIndex, cal);
		}

		public void setRef(int parameterIndex, Ref x) throws SQLException {
			innerCallableStatement.setRef(parameterIndex, x);
		}

		public void registerOutParameter(int parameterIndex, int sqlType,
				String typeName) throws SQLException {
			innerCallableStatement.registerOutParameter(parameterIndex,
					sqlType, typeName);
		}

		public void setBlob(int parameterIndex, Blob x) throws SQLException {
			innerCallableStatement.setBlob(parameterIndex, x);
		}

		public void setClob(int parameterIndex, Clob x) throws SQLException {
			innerCallableStatement.setClob(parameterIndex, x);
		}

		public Connection getConnection() throws SQLException {
			return innerCallableStatement.getConnection();
		}

		public void setArray(int parameterIndex, Array x) throws SQLException {
			innerCallableStatement.setArray(parameterIndex, x);
		}

		public void registerOutParameter(String parameterName, int sqlType)
				throws SQLException {
			innerCallableStatement.registerOutParameter(parameterName, sqlType);
		}

		public ResultSetMetaData getMetaData() throws SQLException {
			return innerCallableStatement.getMetaData();
		}

		public boolean getMoreResults(int current) throws SQLException {
			return innerCallableStatement.getMoreResults(current);
		}

		public void setDate(int parameterIndex, Date x, Calendar cal)
				throws SQLException {
			innerCallableStatement.setDate(parameterIndex, x, cal);
		}

		public void registerOutParameter(String parameterName, int sqlType,
				int scale) throws SQLException {
			innerCallableStatement.registerOutParameter(parameterName, sqlType,
					scale);
		}

		public ResultSet getGeneratedKeys() throws SQLException {
			return new SQLConnectionProxy.ResultSetProxy(
					innerCallableStatement.getGeneratedKeys());
		}

		public void setTime(int parameterIndex, Time x, Calendar cal)
				throws SQLException {
			innerCallableStatement.setTime(parameterIndex, x, cal);
		}

		public int executeUpdate(String sql, int autoGeneratedKeys)
				throws SQLException {
			return innerCallableStatement.executeUpdate(sql, autoGeneratedKeys);
		}

		public void registerOutParameter(String parameterName, int sqlType,
				String typeName) throws SQLException {
			innerCallableStatement.registerOutParameter(parameterName, sqlType,
					typeName);
		}

		public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
				throws SQLException {
			innerCallableStatement.setTimestamp(parameterIndex, x, cal);
		}

		public void setNull(int parameterIndex, int sqlType, String typeName)
				throws SQLException {
			innerCallableStatement.setNull(parameterIndex, sqlType, typeName);
		}

		public int executeUpdate(String sql, int[] columnIndexes)
				throws SQLException {
			return innerCallableStatement.executeUpdate(sql, columnIndexes);
		}

		public URL getURL(int parameterIndex) throws SQLException {
			return innerCallableStatement.getURL(parameterIndex);
		}

		public void setURL(String parameterName, URL val) throws SQLException {
			innerCallableStatement.setURL(parameterName, val);
		}

		public void setURL(int parameterIndex, URL x) throws SQLException {
			innerCallableStatement.setURL(parameterIndex, x);
		}

		public void setNull(String parameterName, int sqlType)
				throws SQLException {
			innerCallableStatement.setNull(parameterName, sqlType);
		}

		public int executeUpdate(String sql, String[] columnNames)
				throws SQLException {
			return innerCallableStatement.executeUpdate(sql, columnNames);
		}

		public ParameterMetaData getParameterMetaData() throws SQLException {
			return innerCallableStatement.getParameterMetaData();
		}

		public void setBoolean(String parameterName, boolean x)
				throws SQLException {
			innerCallableStatement.setBoolean(parameterName, x);
		}

		public void setRowId(int parameterIndex, RowId x) throws SQLException {
			innerCallableStatement.setRowId(parameterIndex, x);
		}

		public void setByte(String parameterName, byte x) throws SQLException {
			innerCallableStatement.setByte(parameterName, x);
		}

		public void setNString(int parameterIndex, String value)
				throws SQLException {
			innerCallableStatement.setNString(parameterIndex, value);
		}

		public void setShort(String parameterName, short x) throws SQLException {
			innerCallableStatement.setShort(parameterName, x);
		}

		public boolean execute(String sql, int autoGeneratedKeys)
				throws SQLException {
			return innerCallableStatement.execute(sql, autoGeneratedKeys);
		}

		public void setNCharacterStream(int parameterIndex, Reader value,
				long length) throws SQLException {
			innerCallableStatement.setNCharacterStream(parameterIndex, value,
					length);
		}

		public void setInt(String parameterName, int x) throws SQLException {
			innerCallableStatement.setInt(parameterName, x);
		}

		public void setLong(String parameterName, long x) throws SQLException {
			innerCallableStatement.setLong(parameterName, x);
		}

		public void setNClob(int parameterIndex, NClob value)
				throws SQLException {
			innerCallableStatement.setNClob(parameterIndex, value);
		}

		public void setFloat(String parameterName, float x) throws SQLException {
			innerCallableStatement.setFloat(parameterName, x);
		}

		public void setClob(int parameterIndex, Reader reader, long length)
				throws SQLException {
			innerCallableStatement.setClob(parameterIndex, reader, length);
		}

		public void setDouble(String parameterName, double x)
				throws SQLException {
			innerCallableStatement.setDouble(parameterName, x);
		}

		public boolean execute(String sql, int[] columnIndexes)
				throws SQLException {
			return innerCallableStatement.execute(sql, columnIndexes);
		}

		public void setBigDecimal(String parameterName, BigDecimal x)
				throws SQLException {
			innerCallableStatement.setBigDecimal(parameterName, x);
		}

		public void setBlob(int parameterIndex, InputStream inputStream,
				long length) throws SQLException {
			innerCallableStatement.setBlob(parameterIndex, inputStream, length);
		}

		public void setString(String parameterName, String x)
				throws SQLException {
			innerCallableStatement.setString(parameterName, x);
		}

		public void setBytes(String parameterName, byte[] x)
				throws SQLException {
			innerCallableStatement.setBytes(parameterName, x);
		}

		public void setNClob(int parameterIndex, Reader reader, long length)
				throws SQLException {
			innerCallableStatement.setNClob(parameterIndex, reader, length);
		}

		public boolean execute(String sql, String[] columnNames)
				throws SQLException {
			return innerCallableStatement.execute(sql, columnNames);
		}

		public void setDate(String parameterName, Date x) throws SQLException {
			innerCallableStatement.setDate(parameterName, x);
		}

		public void setTime(String parameterName, Time x) throws SQLException {
			innerCallableStatement.setTime(parameterName, x);
		}

		public void setSQLXML(int parameterIndex, SQLXML xmlObject)
				throws SQLException {
			innerCallableStatement.setSQLXML(parameterIndex, xmlObject);
		}

		public void setTimestamp(String parameterName, Timestamp x)
				throws SQLException {
			innerCallableStatement.setTimestamp(parameterName, x);
		}

		public void setObject(int parameterIndex, Object x, int targetSqlType,
				int scaleOrLength) throws SQLException {
			innerCallableStatement.setObject(parameterIndex, x, targetSqlType,
					scaleOrLength);
		}

		public int getResultSetHoldability() throws SQLException {
			return innerCallableStatement.getResultSetHoldability();
		}

		public void setAsciiStream(String parameterName, InputStream x,
				int length) throws SQLException {
			innerCallableStatement.setAsciiStream(parameterName, x, length);
		}

		public boolean isClosed() throws SQLException {
			return innerCallableStatement.isClosed();
		}

		public void setPoolable(boolean poolable) throws SQLException {
			innerCallableStatement.setPoolable(poolable);
		}

		public void setBinaryStream(String parameterName, InputStream x,
				int length) throws SQLException {
			innerCallableStatement.setBinaryStream(parameterName, x, length);
		}

		public boolean isPoolable() throws SQLException {
			return innerCallableStatement.isPoolable();
		}

		public void setObject(String parameterName, Object x,
				int targetSqlType, int scale) throws SQLException {
			innerCallableStatement.setObject(parameterName, x, targetSqlType,
					scale);
		}

		public void closeOnCompletion() throws SQLException {
			innerCallableStatement.closeOnCompletion();
		}

		public void setAsciiStream(int parameterIndex, InputStream x,
				long length) throws SQLException {
			innerCallableStatement.setAsciiStream(parameterIndex, x, length);
		}

		public boolean isCloseOnCompletion() throws SQLException {
			return innerCallableStatement.isCloseOnCompletion();
		}

		public void setBinaryStream(int parameterIndex, InputStream x,
				long length) throws SQLException {
			innerCallableStatement.setBinaryStream(parameterIndex, x, length);
		}

		public void setObject(String parameterName, Object x, int targetSqlType)
				throws SQLException {
			innerCallableStatement.setObject(parameterName, x, targetSqlType);
		}

		public void setCharacterStream(int parameterIndex, Reader reader,
				long length) throws SQLException {
			innerCallableStatement.setCharacterStream(parameterIndex, reader,
					length);
		}

		public void setObject(String parameterName, Object x)
				throws SQLException {
			innerCallableStatement.setObject(parameterName, x);
		}

		public void setAsciiStream(int parameterIndex, InputStream x)
				throws SQLException {
			innerCallableStatement.setAsciiStream(parameterIndex, x);
		}

		public void setBinaryStream(int parameterIndex, InputStream x)
				throws SQLException {
			innerCallableStatement.setBinaryStream(parameterIndex, x);
		}

		public void setCharacterStream(String parameterName, Reader reader,
				int length) throws SQLException {
			innerCallableStatement.setCharacterStream(parameterName, reader,
					length);
		}

		public void setCharacterStream(int parameterIndex, Reader reader)
				throws SQLException {
			innerCallableStatement.setCharacterStream(parameterIndex, reader);
		}

		public void setDate(String parameterName, Date x, Calendar cal)
				throws SQLException {
			innerCallableStatement.setDate(parameterName, x, cal);
		}

		public void setNCharacterStream(int parameterIndex, Reader value)
				throws SQLException {
			innerCallableStatement.setNCharacterStream(parameterIndex, value);
		}

		public void setTime(String parameterName, Time x, Calendar cal)
				throws SQLException {
			innerCallableStatement.setTime(parameterName, x, cal);
		}

		public void setClob(int parameterIndex, Reader reader)
				throws SQLException {
			innerCallableStatement.setClob(parameterIndex, reader);
		}

		public void setTimestamp(String parameterName, Timestamp x, Calendar cal)
				throws SQLException {
			innerCallableStatement.setTimestamp(parameterName, x, cal);
		}

		public void setNull(String parameterName, int sqlType, String typeName)
				throws SQLException {
			innerCallableStatement.setNull(parameterName, sqlType, typeName);
		}

		public void setBlob(int parameterIndex, InputStream inputStream)
				throws SQLException {
			innerCallableStatement.setBlob(parameterIndex, inputStream);
		}

		public void setNClob(int parameterIndex, Reader reader)
				throws SQLException {
			innerCallableStatement.setNClob(parameterIndex, reader);
		}

		public String getString(String parameterName) throws SQLException {
			return innerCallableStatement.getString(parameterName);
		}

		public boolean getBoolean(String parameterName) throws SQLException {
			return innerCallableStatement.getBoolean(parameterName);
		}

		public byte getByte(String parameterName) throws SQLException {
			return innerCallableStatement.getByte(parameterName);
		}

		public short getShort(String parameterName) throws SQLException {
			return innerCallableStatement.getShort(parameterName);
		}

		public int getInt(String parameterName) throws SQLException {
			return innerCallableStatement.getInt(parameterName);
		}

		public long getLong(String parameterName) throws SQLException {
			return innerCallableStatement.getLong(parameterName);
		}

		public float getFloat(String parameterName) throws SQLException {
			return innerCallableStatement.getFloat(parameterName);
		}

		public double getDouble(String parameterName) throws SQLException {
			return innerCallableStatement.getDouble(parameterName);
		}

		public byte[] getBytes(String parameterName) throws SQLException {
			return innerCallableStatement.getBytes(parameterName);
		}

		public Date getDate(String parameterName) throws SQLException {
			return innerCallableStatement.getDate(parameterName);
		}

		public Time getTime(String parameterName) throws SQLException {
			return innerCallableStatement.getTime(parameterName);
		}

		public Timestamp getTimestamp(String parameterName) throws SQLException {
			return innerCallableStatement.getTimestamp(parameterName);
		}

		public Object getObject(String parameterName) throws SQLException {
			return innerCallableStatement.getObject(parameterName);
		}

		public BigDecimal getBigDecimal(String parameterName)
				throws SQLException {
			return innerCallableStatement.getBigDecimal(parameterName);
		}

		public Object getObject(String parameterName, Map<String, Class<?>> map)
				throws SQLException {
			return innerCallableStatement.getObject(parameterName, map);
		}

		public Ref getRef(String parameterName) throws SQLException {
			return innerCallableStatement.getRef(parameterName);
		}

		public Blob getBlob(String parameterName) throws SQLException {
			return innerCallableStatement.getBlob(parameterName);
		}

		public Clob getClob(String parameterName) throws SQLException {
			return innerCallableStatement.getClob(parameterName);
		}

		public Array getArray(String parameterName) throws SQLException {
			return innerCallableStatement.getArray(parameterName);
		}

		public Date getDate(String parameterName, Calendar cal)
				throws SQLException {
			return innerCallableStatement.getDate(parameterName, cal);
		}

		public Time getTime(String parameterName, Calendar cal)
				throws SQLException {
			return innerCallableStatement.getTime(parameterName, cal);
		}

		public Timestamp getTimestamp(String parameterName, Calendar cal)
				throws SQLException {
			return innerCallableStatement.getTimestamp(parameterName, cal);
		}

		public URL getURL(String parameterName) throws SQLException {
			return innerCallableStatement.getURL(parameterName);
		}

		public RowId getRowId(int parameterIndex) throws SQLException {
			return innerCallableStatement.getRowId(parameterIndex);
		}

		public RowId getRowId(String parameterName) throws SQLException {
			return innerCallableStatement.getRowId(parameterName);
		}

		public void setRowId(String parameterName, RowId x) throws SQLException {
			innerCallableStatement.setRowId(parameterName, x);
		}

		public void setNString(String parameterName, String value)
				throws SQLException {
			innerCallableStatement.setNString(parameterName, value);
		}

		public void setNCharacterStream(String parameterName, Reader value,
				long length) throws SQLException {
			innerCallableStatement.setNCharacterStream(parameterName, value,
					length);
		}

		public void setNClob(String parameterName, NClob value)
				throws SQLException {
			innerCallableStatement.setNClob(parameterName, value);
		}

		public void setClob(String parameterName, Reader reader, long length)
				throws SQLException {
			innerCallableStatement.setClob(parameterName, reader, length);
		}

		public void setBlob(String parameterName, InputStream inputStream,
				long length) throws SQLException {
			innerCallableStatement.setBlob(parameterName, inputStream, length);
		}

		public void setNClob(String parameterName, Reader reader, long length)
				throws SQLException {
			innerCallableStatement.setNClob(parameterName, reader, length);
		}

		public NClob getNClob(int parameterIndex) throws SQLException {
			return innerCallableStatement.getNClob(parameterIndex);
		}

		public NClob getNClob(String parameterName) throws SQLException {
			return innerCallableStatement.getNClob(parameterName);
		}

		public void setSQLXML(String parameterName, SQLXML xmlObject)
				throws SQLException {
			innerCallableStatement.setSQLXML(parameterName, xmlObject);
		}

		public SQLXML getSQLXML(int parameterIndex) throws SQLException {
			return innerCallableStatement.getSQLXML(parameterIndex);
		}

		public SQLXML getSQLXML(String parameterName) throws SQLException {
			return innerCallableStatement.getSQLXML(parameterName);
		}

		public String getNString(int parameterIndex) throws SQLException {
			return innerCallableStatement.getNString(parameterIndex);
		}

		public String getNString(String parameterName) throws SQLException {
			return innerCallableStatement.getNString(parameterName);
		}

		public Reader getNCharacterStream(int parameterIndex)
				throws SQLException {
			return innerCallableStatement.getNCharacterStream(parameterIndex);
		}

		public Reader getNCharacterStream(String parameterName)
				throws SQLException {
			return innerCallableStatement.getNCharacterStream(parameterName);
		}

		public Reader getCharacterStream(int parameterIndex)
				throws SQLException {
			return innerCallableStatement.getCharacterStream(parameterIndex);
		}

		public Reader getCharacterStream(String parameterName)
				throws SQLException {
			return innerCallableStatement.getCharacterStream(parameterName);
		}

		public void setBlob(String parameterName, Blob x) throws SQLException {
			innerCallableStatement.setBlob(parameterName, x);
		}

		public void setClob(String parameterName, Clob x) throws SQLException {
			innerCallableStatement.setClob(parameterName, x);
		}

		public void setAsciiStream(String parameterName, InputStream x,
				long length) throws SQLException {
			innerCallableStatement.setAsciiStream(parameterName, x, length);
		}

		public void setBinaryStream(String parameterName, InputStream x,
				long length) throws SQLException {
			innerCallableStatement.setBinaryStream(parameterName, x, length);
		}

		public void setCharacterStream(String parameterName, Reader reader,
				long length) throws SQLException {
			innerCallableStatement.setCharacterStream(parameterName, reader,
					length);
		}

		public void setAsciiStream(String parameterName, InputStream x)
				throws SQLException {
			innerCallableStatement.setAsciiStream(parameterName, x);
		}

		public void setBinaryStream(String parameterName, InputStream x)
				throws SQLException {
			innerCallableStatement.setBinaryStream(parameterName, x);
		}

		public void setCharacterStream(String parameterName, Reader reader)
				throws SQLException {
			innerCallableStatement.setCharacterStream(parameterName, reader);
		}

		public void setNCharacterStream(String parameterName, Reader value)
				throws SQLException {
			innerCallableStatement.setNCharacterStream(parameterName, value);
		}

		public void setClob(String parameterName, Reader reader)
				throws SQLException {
			innerCallableStatement.setClob(parameterName, reader);
		}

		public void setBlob(String parameterName, InputStream inputStream)
				throws SQLException {
			innerCallableStatement.setBlob(parameterName, inputStream);
		}

		public void setNClob(String parameterName, Reader reader)
				throws SQLException {
			innerCallableStatement.setNClob(parameterName, reader);
		}

		public <T> T getObject(int parameterIndex, Class<T> type)
				throws SQLException {
			return innerCallableStatement.getObject(parameterIndex, type);
		}

		public <T> T getObject(String parameterName, Class<T> type)
				throws SQLException {
			return innerCallableStatement.getObject(parameterName, type);
		}
	}

	class PreparedStatementProxy extends SQLConnectionProxy.StatementProxy
			implements PreparedStatement {
		PreparedStatement innerPreparedStatement;

		public PreparedStatementProxy(PreparedStatement preparedStatement) {
			super(preparedStatement);
			innerPreparedStatement = preparedStatement;
		}

		public <T> T unwrap(Class<T> iface) throws SQLException {
			return innerPreparedStatement.unwrap(iface);
		}

		public ResultSet executeQuery(String sql) throws SQLException {
			return new SQLConnectionProxy.ResultSetProxy(
					innerPreparedStatement.executeQuery(sql));
		}

		public ResultSet executeQuery() throws SQLException {
			return new ResultSetProxy(innerPreparedStatement.executeQuery());
		}

		public boolean isWrapperFor(Class<?> iface) throws SQLException {
			return innerPreparedStatement.isWrapperFor(iface);
		}

		public int executeUpdate(String sql) throws SQLException {
			return innerPreparedStatement.executeUpdate(sql);
		}

		public int executeUpdate() throws SQLException {
			return innerPreparedStatement.executeUpdate();
		}

		public void setNull(int parameterIndex, int sqlType)
				throws SQLException {
			innerPreparedStatement.setNull(parameterIndex, sqlType);
		}

		public void close() throws SQLException {
			innerPreparedStatement.close();
		}

		public int getMaxFieldSize() throws SQLException {
			return innerPreparedStatement.getMaxFieldSize();
		}

		public void setBoolean(int parameterIndex, boolean x)
				throws SQLException {
			innerPreparedStatement.setBoolean(parameterIndex, x);
		}

		public void setByte(int parameterIndex, byte x) throws SQLException {
			innerPreparedStatement.setByte(parameterIndex, x);
		}

		public void setMaxFieldSize(int max) throws SQLException {
			innerPreparedStatement.setMaxFieldSize(max);
		}

		public void setShort(int parameterIndex, short x) throws SQLException {
			innerPreparedStatement.setShort(parameterIndex, x);
		}

		public int getMaxRows() throws SQLException {
			return innerPreparedStatement.getMaxRows();
		}

		public void setInt(int parameterIndex, int x) throws SQLException {
			innerPreparedStatement.setInt(parameterIndex, x);
		}

		public void setMaxRows(int max) throws SQLException {
			innerPreparedStatement.setMaxRows(max);
		}

		public void setLong(int parameterIndex, long x) throws SQLException {
			innerPreparedStatement.setLong(parameterIndex, x);
		}

		public void setEscapeProcessing(boolean enable) throws SQLException {
			innerPreparedStatement.setEscapeProcessing(enable);
		}

		public void setFloat(int parameterIndex, float x) throws SQLException {
			innerPreparedStatement.setFloat(parameterIndex, x);
		}

		public void setDouble(int parameterIndex, double x) throws SQLException {
			innerPreparedStatement.setDouble(parameterIndex, x);
		}

		public int getQueryTimeout() throws SQLException {
			return innerPreparedStatement.getQueryTimeout();
		}

		public void setQueryTimeout(int seconds) throws SQLException {
			innerPreparedStatement.setQueryTimeout(seconds);
		}

		public void setBigDecimal(int parameterIndex, BigDecimal x)
				throws SQLException {
			innerPreparedStatement.setBigDecimal(parameterIndex, x);
		}

		public void setString(int parameterIndex, String x) throws SQLException {
			innerPreparedStatement.setString(parameterIndex, x);
		}

		public void setBytes(int parameterIndex, byte[] x) throws SQLException {
			innerPreparedStatement.setBytes(parameterIndex, x);
		}

		public void cancel() throws SQLException {
			innerPreparedStatement.cancel();
		}

		public SQLWarning getWarnings() throws SQLException {
			return innerPreparedStatement.getWarnings();
		}

		public void setDate(int parameterIndex, Date x) throws SQLException {
			innerPreparedStatement.setDate(parameterIndex, x);
		}

		public void setTime(int parameterIndex, Time x) throws SQLException {
			innerPreparedStatement.setTime(parameterIndex, x);
		}

		public void clearWarnings() throws SQLException {
			innerPreparedStatement.clearWarnings();
		}

		public void setCursorName(String name) throws SQLException {
			innerPreparedStatement.setCursorName(name);
		}

		public void setTimestamp(int parameterIndex, Timestamp x)
				throws SQLException {
			innerPreparedStatement.setTimestamp(parameterIndex, x);
		}

		public void setAsciiStream(int parameterIndex, InputStream x, int length)
				throws SQLException {
			innerPreparedStatement.setAsciiStream(parameterIndex, x, length);
		}

		public boolean execute(String sql) throws SQLException {
			return innerPreparedStatement.execute(sql);
		}

		/** @deprecated */
		public void setUnicodeStream(int parameterIndex, InputStream x,
				int length) throws SQLException {
			innerPreparedStatement.setUnicodeStream(parameterIndex, x, length);
		}

		public ResultSet getResultSet() throws SQLException {
			return new SQLConnectionProxy.ResultSetProxy(
					innerPreparedStatement.getResultSet());
		}

		public void setBinaryStream(int parameterIndex, InputStream x,
				int length) throws SQLException {
			innerPreparedStatement.setBinaryStream(parameterIndex, x, length);
		}

		public int getUpdateCount() throws SQLException {
			return innerPreparedStatement.getUpdateCount();
		}

		public boolean getMoreResults() throws SQLException {
			return innerPreparedStatement.getMoreResults();
		}

		public void clearParameters() throws SQLException {
			innerPreparedStatement.clearParameters();
		}

		public void setObject(int parameterIndex, Object x, int targetSqlType)
				throws SQLException {
			innerPreparedStatement.setObject(parameterIndex, x, targetSqlType);
		}

		public void setFetchDirection(int direction) throws SQLException {
			innerPreparedStatement.setFetchDirection(direction);
		}

		public int getFetchDirection() throws SQLException {
			return innerPreparedStatement.getFetchDirection();
		}

		public void setObject(int parameterIndex, Object x) throws SQLException {
			innerPreparedStatement.setObject(parameterIndex, x);
		}

		public void setFetchSize(int rows) throws SQLException {
			innerPreparedStatement.setFetchSize(rows);
		}

		public int getFetchSize() throws SQLException {
			return innerPreparedStatement.getFetchSize();
		}

		public int getResultSetConcurrency() throws SQLException {
			return innerPreparedStatement.getResultSetConcurrency();
		}

		public boolean execute() throws SQLException {
			return innerPreparedStatement.execute();
		}

		public int getResultSetType() throws SQLException {
			return innerPreparedStatement.getResultSetType();
		}

		public void addBatch(String sql) throws SQLException {
			innerPreparedStatement.addBatch(sql);
		}

		public void clearBatch() throws SQLException {
			innerPreparedStatement.clearBatch();
		}

		public void addBatch() throws SQLException {
			innerPreparedStatement.addBatch();
		}

		public int[] executeBatch() throws SQLException {
			return innerPreparedStatement.executeBatch();
		}

		public void setCharacterStream(int parameterIndex, Reader reader,
				int length) throws SQLException {
			innerPreparedStatement.setCharacterStream(parameterIndex, reader,
					length);
		}

		public void setRef(int parameterIndex, Ref x) throws SQLException {
			innerPreparedStatement.setRef(parameterIndex, x);
		}

		public void setBlob(int parameterIndex, Blob x) throws SQLException {
			innerPreparedStatement.setBlob(parameterIndex, x);
		}

		public void setClob(int parameterIndex, Clob x) throws SQLException {
			innerPreparedStatement.setClob(parameterIndex, x);
		}

		public Connection getConnection() throws SQLException {
			return innerPreparedStatement.getConnection();
		}

		public void setArray(int parameterIndex, Array x) throws SQLException {
			innerPreparedStatement.setArray(parameterIndex, x);
		}

		public ResultSetMetaData getMetaData() throws SQLException {
			return innerPreparedStatement.getMetaData();
		}

		public boolean getMoreResults(int current) throws SQLException {
			return innerPreparedStatement.getMoreResults(current);
		}

		public void setDate(int parameterIndex, Date x, Calendar cal)
				throws SQLException {
			innerPreparedStatement.setDate(parameterIndex, x, cal);
		}

		public ResultSet getGeneratedKeys() throws SQLException {
			return new SQLConnectionProxy.ResultSetProxy(
					innerPreparedStatement.getGeneratedKeys());
		}

		public void setTime(int parameterIndex, Time x, Calendar cal)
				throws SQLException {
			innerPreparedStatement.setTime(parameterIndex, x, cal);
		}

		public int executeUpdate(String sql, int autoGeneratedKeys)
				throws SQLException {
			return innerPreparedStatement.executeUpdate(sql, autoGeneratedKeys);
		}

		public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
				throws SQLException {
			innerPreparedStatement.setTimestamp(parameterIndex, x, cal);
		}

		public void setNull(int parameterIndex, int sqlType, String typeName)
				throws SQLException {
			innerPreparedStatement.setNull(parameterIndex, sqlType, typeName);
		}

		public int executeUpdate(String sql, int[] columnIndexes)
				throws SQLException {
			return innerPreparedStatement.executeUpdate(sql, columnIndexes);
		}

		public void setURL(int parameterIndex, URL x) throws SQLException {
			innerPreparedStatement.setURL(parameterIndex, x);
		}

		public int executeUpdate(String sql, String[] columnNames)
				throws SQLException {
			return innerPreparedStatement.executeUpdate(sql, columnNames);
		}

		public ParameterMetaData getParameterMetaData() throws SQLException {
			return innerPreparedStatement.getParameterMetaData();
		}

		public void setRowId(int parameterIndex, RowId x) throws SQLException {
			innerPreparedStatement.setRowId(parameterIndex, x);
		}

		public void setNString(int parameterIndex, String value)
				throws SQLException {
			innerPreparedStatement.setNString(parameterIndex, value);
		}

		public boolean execute(String sql, int autoGeneratedKeys)
				throws SQLException {
			return innerPreparedStatement.execute(sql, autoGeneratedKeys);
		}

		public void setNCharacterStream(int parameterIndex, Reader value,
				long length) throws SQLException {
			innerPreparedStatement.setNCharacterStream(parameterIndex, value,
					length);
		}

		public void setNClob(int parameterIndex, NClob value)
				throws SQLException {
			innerPreparedStatement.setNClob(parameterIndex, value);
		}

		public void setClob(int parameterIndex, Reader reader, long length)
				throws SQLException {
			innerPreparedStatement.setClob(parameterIndex, reader, length);
		}

		public boolean execute(String sql, int[] columnIndexes)
				throws SQLException {
			return innerPreparedStatement.execute(sql, columnIndexes);
		}

		public void setBlob(int parameterIndex, InputStream inputStream,
				long length) throws SQLException {
			innerPreparedStatement.setBlob(parameterIndex, inputStream, length);
		}

		public void setNClob(int parameterIndex, Reader reader, long length)
				throws SQLException {
			innerPreparedStatement.setNClob(parameterIndex, reader, length);
		}

		public boolean execute(String sql, String[] columnNames)
				throws SQLException {
			return innerPreparedStatement.execute(sql, columnNames);
		}

		public void setSQLXML(int parameterIndex, SQLXML xmlObject)
				throws SQLException {
			innerPreparedStatement.setSQLXML(parameterIndex, xmlObject);
		}

		public void setObject(int parameterIndex, Object x, int targetSqlType,
				int scaleOrLength) throws SQLException {
			innerPreparedStatement.setObject(parameterIndex, x, targetSqlType,
					scaleOrLength);
		}

		public int getResultSetHoldability() throws SQLException {
			return innerPreparedStatement.getResultSetHoldability();
		}

		public boolean isClosed() throws SQLException {
			return innerPreparedStatement.isClosed();
		}

		public void setPoolable(boolean poolable) throws SQLException {
			innerPreparedStatement.setPoolable(poolable);
		}

		public boolean isPoolable() throws SQLException {
			return innerPreparedStatement.isPoolable();
		}

		public void closeOnCompletion() throws SQLException {
			innerPreparedStatement.closeOnCompletion();
		}

		public void setAsciiStream(int parameterIndex, InputStream x,
				long length) throws SQLException {
			innerPreparedStatement.setAsciiStream(parameterIndex, x, length);
		}

		public boolean isCloseOnCompletion() throws SQLException {
			return innerPreparedStatement.isCloseOnCompletion();
		}

		public void setBinaryStream(int parameterIndex, InputStream x,
				long length) throws SQLException {
			innerPreparedStatement.setBinaryStream(parameterIndex, x, length);
		}

		public void setCharacterStream(int parameterIndex, Reader reader,
				long length) throws SQLException {
			innerPreparedStatement.setCharacterStream(parameterIndex, reader,
					length);
		}

		public void setAsciiStream(int parameterIndex, InputStream x)
				throws SQLException {
			innerPreparedStatement.setAsciiStream(parameterIndex, x);
		}

		public void setBinaryStream(int parameterIndex, InputStream x)
				throws SQLException {
			innerPreparedStatement.setBinaryStream(parameterIndex, x);
		}

		public void setCharacterStream(int parameterIndex, Reader reader)
				throws SQLException {
			innerPreparedStatement.setCharacterStream(parameterIndex, reader);
		}

		public void setNCharacterStream(int parameterIndex, Reader value)
				throws SQLException {
			innerPreparedStatement.setNCharacterStream(parameterIndex, value);
		}

		public void setClob(int parameterIndex, Reader reader)
				throws SQLException {
			innerPreparedStatement.setClob(parameterIndex, reader);
		}

		public void setBlob(int parameterIndex, InputStream inputStream)
				throws SQLException {
			innerPreparedStatement.setBlob(parameterIndex, inputStream);
		}

		public void setNClob(int parameterIndex, Reader reader)
				throws SQLException {
			innerPreparedStatement.setNClob(parameterIndex, reader);
		}
	}

	class StatementProxy implements Statement {
		Statement statement;

		public StatementProxy(Statement statement) {
			this.statement = statement;
		}

		public <T> T unwrap(Class<T> iface) throws SQLException {
			return statement.unwrap(iface);
		}

		public ResultSet executeQuery(String sql) throws SQLException {
			return new SQLConnectionProxy.ResultSetProxy(
					statement.executeQuery(sql));
		}

		public boolean isWrapperFor(Class<?> iface) throws SQLException {
			return statement.isWrapperFor(iface);
		}

		public int executeUpdate(String sql) throws SQLException {
			return statement.executeUpdate(sql);
		}

		public void close() throws SQLException {
			statement.close();
		}

		public int getMaxFieldSize() throws SQLException {
			return statement.getMaxFieldSize();
		}

		public void setMaxFieldSize(int max) throws SQLException {
			statement.setMaxFieldSize(max);
		}

		public int getMaxRows() throws SQLException {
			return statement.getMaxRows();
		}

		public void setMaxRows(int max) throws SQLException {
			statement.setMaxRows(max);
		}

		public void setEscapeProcessing(boolean enable) throws SQLException {
			statement.setEscapeProcessing(enable);
		}

		public int getQueryTimeout() throws SQLException {
			return statement.getQueryTimeout();
		}

		public void setQueryTimeout(int seconds) throws SQLException {
			statement.setQueryTimeout(seconds);
		}

		public void cancel() throws SQLException {
			statement.cancel();
		}

		public SQLWarning getWarnings() throws SQLException {
			return statement.getWarnings();
		}

		public void clearWarnings() throws SQLException {
			statement.clearWarnings();
		}

		public void setCursorName(String name) throws SQLException {
			statement.setCursorName(name);
		}

		public boolean execute(String sql) throws SQLException {
			return statement.execute(sql);
		}

		public ResultSet getResultSet() throws SQLException {
			return new SQLConnectionProxy.ResultSetProxy(
					statement.getResultSet());
		}

		public int getUpdateCount() throws SQLException {
			return statement.getUpdateCount();
		}

		public boolean getMoreResults() throws SQLException {
			return statement.getMoreResults();
		}

		public void setFetchDirection(int direction) throws SQLException {
			statement.setFetchDirection(direction);
		}

		public int getFetchDirection() throws SQLException {
			return statement.getFetchDirection();
		}

		public void setFetchSize(int rows) throws SQLException {
			statement.setFetchSize(rows);
		}

		public int getFetchSize() throws SQLException {
			return statement.getFetchSize();
		}

		public int getResultSetConcurrency() throws SQLException {
			return statement.getResultSetConcurrency();
		}

		public int getResultSetType() throws SQLException {
			return statement.getResultSetType();
		}

		public void addBatch(String sql) throws SQLException {
			statement.addBatch(sql);
		}

		public void clearBatch() throws SQLException {
			statement.clearBatch();
		}

		public int[] executeBatch() throws SQLException {
			return statement.executeBatch();
		}

		public Connection getConnection() throws SQLException {
			return SQLConnectionProxy.this;
		}

		public boolean getMoreResults(int current) throws SQLException {
			return statement.getMoreResults(current);
		}

		public ResultSet getGeneratedKeys() throws SQLException {
			return new SQLConnectionProxy.ResultSetProxy(
					statement.getGeneratedKeys());
		}

		public int executeUpdate(String sql, int autoGeneratedKeys)
				throws SQLException {
			return statement.executeUpdate(sql, autoGeneratedKeys);
		}

		public int executeUpdate(String sql, int[] columnIndexes)
				throws SQLException {
			return statement.executeUpdate(sql, columnIndexes);
		}

		public int executeUpdate(String sql, String[] columnNames)
				throws SQLException {
			return statement.executeUpdate(sql, columnNames);
		}

		public boolean execute(String sql, int autoGeneratedKeys)
				throws SQLException {
			return statement.execute(sql, autoGeneratedKeys);
		}

		public boolean execute(String sql, int[] columnIndexes)
				throws SQLException {
			return statement.execute(sql, columnIndexes);
		}

		public boolean execute(String sql, String[] columnNames)
				throws SQLException {
			return statement.execute(sql, columnNames);
		}

		public int getResultSetHoldability() throws SQLException {
			return statement.getResultSetHoldability();
		}

		public boolean isClosed() throws SQLException {
			return statement.isClosed();
		}

		public void setPoolable(boolean poolable) throws SQLException {
			statement.setPoolable(poolable);
		}

		public boolean isPoolable() throws SQLException {
			return statement.isPoolable();
		}

		public void closeOnCompletion() throws SQLException {
			statement.closeOnCompletion();
		}

		public boolean isCloseOnCompletion() throws SQLException {
			return statement.isCloseOnCompletion();
		}
	}
}