package com.quqian.framework.message.sms.entity;

import java.io.Serializable;

public class SmsTask
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  public long id;
  public int type;
  public String content;
  public String[] receivers;
  public int jlid;
}