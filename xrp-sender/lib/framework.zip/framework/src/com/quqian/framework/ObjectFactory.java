package com.quqian.framework;

public abstract interface ObjectFactory<T>
{
  public abstract T newInstance();

  public abstract T[] newArray(int paramInt);
}