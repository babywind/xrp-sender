package com.quqian.framework.resource;

import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.config.entity.ModuleBean;
import com.quqian.framework.data.DataConnectionProvider;
import com.quqian.framework.http.entity.RightBean;
import com.quqian.framework.log.Logger;

public abstract interface ResourceProvider extends Logger, InitParameterProvider
{
  public abstract <C extends DataConnectionProvider> C getDataConnectionProvider(Class<C> paramClass, String paramString)
    throws ResourceNotFoundException;

  public abstract <R extends Resource> R getResource(Class<R> paramClass)
    throws ResourceNotFoundException;

  public abstract <R extends NamedResource> R getNamedResource(Class<R> paramClass, String paramString)
    throws ResourceNotFoundException;

  public abstract void close();

  public abstract ModuleBean[] getModuleBeans();

  public abstract ModuleBean getModuleBean(String paramString);

  public abstract RightBean getRightBean(String paramString);

  public abstract String getHome();

  public abstract ResourceRetention getResourceRetention();

  public abstract String getContextPath();

  public abstract String getCharset();

  public abstract SystemDefine getSystemDefine();
}