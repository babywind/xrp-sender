package com.quqian.framework.http.achieve.session.cookie.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.data.sql.SQLConnectionProvider;
import com.quqian.framework.http.achieve.session.cookie.AbstractCookieSessionManager;
import com.quqian.framework.http.session.Session;
import com.quqian.framework.http.session.SessionManager;
import com.quqian.framework.http.session.VerifyCode;
import com.quqian.framework.http.session.VerifyCodeGenerator;
import com.quqian.framework.http.session.authentication.AuthenticationException;
import com.quqian.framework.http.session.authentication.VerifyCodeAuthentication;
import com.quqian.framework.resource.ResourceAnnotation;
import com.quqian.framework.resource.ResourceNotFoundException;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.util.StringHelper;

@ResourceAnnotation
public class SQLStoreSessionManager extends AbstractCookieSessionManager {
	public SQLStoreSessionManager(ResourceProvider resourceProvider) {
		super(resourceProvider);
	}

	/**
	 * 没有时间限制session
	 */
	protected Session newSession(Cookie cookie, HttpServletRequest request, HttpServletResponse response) {
		return new SQLStoreSession(cookie, request, response);
	}

	protected Session newSession(Cookie cookie, HttpServletRequest request, HttpServletResponse response,
			long maxIdleTime) {
		return new SQLStoreSession(cookie, request, response, maxIdleTime);
	}

	protected Connection getConnection() throws SQLException, ResourceNotFoundException {
		SystemDefine systemDefine = resourceProvider.getSystemDefine();
		return ((SQLConnectionProvider) resourceProvider.getDataConnectionProvider(SQLConnectionProvider.class,
				systemDefine.getDataProvider(SessionManager.class)))
						.getConnection(systemDefine.getSchemaName(SessionManager.class));
	}

	public void initilize(Connection connection) throws Throwable {
		super.initilize(connection);
		Statement stmt = connection.createStatement();
		Throwable localThrowable2 = null;
		try {
			stmt.addBatch(
					"CREATE TABLE IF NOT EXISTS _1030 (F01 int(10) unsigned NOT NULL AUTO_INCREMENT,F02 char(45) NOT NULL,F03 datetime NOT NULL,F04 int(10) unsigned DEFAULT NULL,F05 datetime NOT NULL,F06 varchar(40) NOT NULL,F07 varchar(40) NOT NULL, PRIMARY KEY (F01),UNIQUE KEY F02 (F02) USING HASH, KEY F06 (F06) USING BTREE, KEY F07 (F07) USING BTREE) ENGINE=MEMORY ;");

			stmt.addBatch(
					"CREATE TABLE IF NOT EXISTS _1031 (F01 int(10) unsigned NOT NULL,F02 varchar(20) NOT NULL,F03 varchar(20) NOT NULL,F04 varchar(20) NOT NULL,F05 datetime NOT NULL, PRIMARY KEY (F01,F02)) ENGINE=MEMORY ;");

			stmt.addBatch(
					"CREATE TABLE IF NOT EXISTS _1032 (F01 int(10) unsigned NOT NULL,F02 varchar(60) NOT NULL,F03 varchar(200) DEFAULT NULL,PRIMARY KEY (F01,F02)) ENGINE=MEMORY ;");

			stmt.addBatch(
					"CREATE TABLE IF NOT EXISTS _1033 (F01 int(10) unsigned NOT NULL,F02 text NOT NULL,PRIMARY KEY (F01)) ;");
			stmt.addBatch("CREATE TABLE IF NOT EXISTS _1034 (F01 int(10) unsigned NOT NULL,PRIMARY KEY (F01)) ;");
			stmt.addBatch(
					"CREATE TABLE IF NOT EXISTS _1035 (F01 date NOT NULL,F02 int(10) unsigned NOT NULL DEFAULT '0', PRIMARY KEY (F01)) ;");
			stmt.addBatch(
					"CREATE TABLE IF NOT EXISTS _1036 (F01 date NOT NULL,F02 int(10) unsigned NOT NULL, F03 int(10) unsigned NOT NULL DEFAULT '0', PRIMARY KEY (F01,F02)) ;");

			stmt.addBatch(
					"CREATE TABLE IF NOT EXISTS _1037 (F01 varchar(40) NOT NULL,F02 varchar(40) NOT NULL, F03 int(10) unsigned NOT NULL DEFAULT '0', PRIMARY KEY (F01,F02)) ;");

			stmt.addBatch("DROP PROCEDURE IF EXISTS SP_1030");
			stmt.addBatch(
					"CREATE PROCEDURE SP_1030() BEGIN DECLARE _current_date DATETIME DEFAULT CURRENT_TIMESTAMP();DELETE _1033 FROM _1033,_1030 WHERE _1033.F01 = _1030.F01 AND _1030.F05 <= _current_date;DELETE _1032 FROM _1032,_1030 WHERE _1032.F01 = _1030.F01 AND _1030.F05 <= _current_date;DELETE _1031 FROM _1031,_1030 WHERE _1031.F01 = _1030.F01 AND _1030.F05 <= _current_date; DELETE FROM _1030 WHERE _1030.F05 <= _current_date;END;");
			stmt.addBatch("DROP PROCEDURE IF EXISTS SP_1034");
			stmt.addBatch(
					"CREATE PROCEDURE SP_1034() BEGIN DECLARE _count INT UNSIGNED DEFAULT 0; SELECT COUNT(*) INTO _count FROM _1034;INSERT INTO _1035 SET F01 = CURRENT_DATE(), F02 = _count ON DUPLICATE KEY UPDATE F02 = VALUES(F02);DELETE FROM _1034;END;");
			stmt.addBatch("DROP PROCEDURE IF EXISTS SP_1036");
			stmt.addBatch(
					"CREATE PROCEDURE SP_1036() BEGIN DECLARE _count INT UNSIGNED DEFAULT 0; DECLARE _current_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP();SELECT COUNT(*) INTO _count FROM _1030 WHERE F04 IS NOT NULL AND F05 > _current_time;INSERT INTO _1036 SET F01 = DATE(_current_time), F02 = HOUR(_current_time), F03 = _count ON DUPLICATE KEY UPDATE F03 = VALUES(F03);END;");

			stmt.addBatch(
					"CREATE EVENT IF NOT EXISTS `EVT_1030` ON SCHEDULE EVERY 1 HOUR STARTS '2014-01-01 00:00:00' ON COMPLETION PRESERVE ENABLE DO CALL SP_1030()");
			stmt.addBatch(
					"CREATE EVENT IF NOT EXISTS `EVT_1034_5` ON SCHEDULE EVERY 1 DAY STARTS '2014-01-01 00:00:00' ON COMPLETION PRESERVE ENABLE DO CALL SP_1034()");
			stmt.addBatch(
					"CREATE EVENT IF NOT EXISTS `EVT_1036` ON SCHEDULE EVERY 1 HOUR STARTS '2014-01-01 00:00:00' ON COMPLETION PRESERVE ENABLE DO CALL SP_1036()");
			stmt.addBatch(
					"CREATE EVENT IF NOT EXISTS `EVT_1037` ON SCHEDULE EVERY 1 DAY STARTS '2014-01-01 00:00:00' ON COMPLETION PRESERVE ENABLE DO DELETE FROM _1037");
			stmt.executeBatch();
		} catch (Throwable localThrowable1) {
			localThrowable2 = localThrowable1;
			throw localThrowable1;
		} finally {
			if (stmt != null)
				if (localThrowable2 != null)
					try {
						stmt.close();
					} catch (Throwable x2) {
						localThrowable2.addSuppressed(x2);
					}
				else
					stmt.close();
		}
	}

	/**
	 * 没有时间显示session
	 * 
	 * @author Administrator
	 *
	 */
	protected class SQLStoreSession extends AbstractCookieSessionManager.AbstractCookieSession {
		private long id = 0L;
		private long expires;

		public SQLStoreSession(Cookie cookie, HttpServletRequest request, HttpServletResponse response) {
			super(cookie, request, response);
			try {
				try (Connection connection = getConnection()) {
					if ("Shockwave Flash".equals(userAgent)) {
						try (PreparedStatement pstmt = connection
								.prepareStatement("SELECT F01, F04, F05, F06, F07 FROM _1030 WHERE F02 = ?")) {
							pstmt.setString(1, cookie.getValue());
							try (ResultSet resultSet = pstmt.executeQuery()) {
								if (resultSet.next()) {
									id = resultSet.getLong(1);
									accountId = resultSet.getInt(2);
									expires = resultSet.getTimestamp(3).getTime();
								}
							}
						}

					} else {
						try (PreparedStatement pstmt = connection.prepareStatement(
								"SELECT F01, F04, F05, F06, F07 FROM _1030 WHERE F02 = ? AND F07 = ?")) {
							pstmt.setString(1, cookie.getValue());
							pstmt.setString(2, userAgentDigest);
							try (ResultSet resultSet = pstmt.executeQuery()) {
								if (resultSet.next()) {
									id = resultSet.getLong(1);
									accountId = resultSet.getInt(2);
									expires = resultSet.getTimestamp(3).getTime();
								}
							}
						}

					}

					if(id>0L){
						if (isAuthenticated()) {
							if ((expires - (getMaxIdleTime() / 2)) < System.currentTimeMillis()) {
								try (PreparedStatement pstmt = connection
										.prepareStatement("UPDATE _1030 SET F05 = ? WHERE F01 = ?")) {
									pstmt.setTimestamp(1, new Timestamp(creationTime + getMaxIdleTime()));
	
									pstmt.setLong(2, id);
									pstmt.executeUpdate();
								}
							}
						}
					} else if (id <= 0L) {
						{
//							try (PreparedStatement preparedStatement = connection.prepareStatement(
//									"INSERT INTO _1030 SET F02 = ?, F03 = ?, F04 = ?, F05 = ?, F06 = ?, F07 = ? ON DUPLICATE KEY UPDATE F03 = VALUES(F03), F04 = VALUES(F04), F05 = VALUES(F05), F06 = VALUES(F06), F07 = VALUES(F07)",
//									1)) {
							try (PreparedStatement preparedStatement = connection.prepareStatement(
									"INSERT INTO _1030 SET F02 = ?, F03 = ?, F04 = ?, F05 = ?, F06 = ?, F07 = ? ON DUPLICATE KEY UPDATE F04 = ? ",
									1)) {
								preparedStatement.setString(1, cookie.getValue());
								preparedStatement.setTimestamp(2, new Timestamp(creationTime));

								preparedStatement.setNull(3, 4);
								preparedStatement.setTimestamp(4, new Timestamp(creationTime + getMaxIdleTime()));

								preparedStatement.setString(5, ip);
								preparedStatement.setString(6, userAgentDigest);
								preparedStatement.setNull(7, 4);
								preparedStatement.execute();
								try (ResultSet resultSet = preparedStatement.getGeneratedKeys()) {
									if (resultSet.next())
										id = resultSet.getLong(1);
								}
							}
						}

						if (id > 0L) {
							try (PreparedStatement preparedStatement = connection.prepareStatement(
									"INSERT INTO _1033 SET F01 = ?, F02 = ? ON DUPLICATE KEY UPDATE F02 = VALUES(F02)")) {
								preparedStatement.setLong(1, id);
								preparedStatement.setString(2, userAgent);
								preparedStatement.execute();
							}
						}
					}
				}
			} catch (Throwable throwable) {
				resourceProvider.log(throwable);
			}
		}

		public SQLStoreSession(Cookie cookie, HttpServletRequest request, HttpServletResponse response,
				long maxIdleTime) {
			super(cookie, request, response);
			try {
				try (Connection connection = getConnection()) {
					if ("Shockwave Flash".equals(userAgent)) {
						try (PreparedStatement pstmt = connection
								.prepareStatement("SELECT F01, F04, F05, F06, F07 FROM _1030 WHERE F02 = ?")) {
							pstmt.setString(1, cookie.getValue());
							try (ResultSet resultSet = pstmt.executeQuery()) {
								if (resultSet.next()) {
									id = resultSet.getLong(1);
									accountId = resultSet.getInt(2);
									expires = resultSet.getTimestamp(3).getTime();
								}
							}
						}

					} else {
						try (PreparedStatement pstmt = connection.prepareStatement(
								"SELECT F01, F04, F05, F06, F07 FROM _1030 WHERE F02 = ? AND F07 = ?")) {
							pstmt.setString(1, cookie.getValue());
							pstmt.setString(2, userAgentDigest);
							try (ResultSet resultSet = pstmt.executeQuery()) {
								if (resultSet.next()) {
									id = resultSet.getLong(1);
									accountId = resultSet.getInt(2);
									expires = resultSet.getTimestamp(3).getTime();
								}
							}
						}

					}

					if (isAuthenticated()) {
						if ((expires - (getMaxIdleTime() / 2)) < System.currentTimeMillis()) {
							try (PreparedStatement pstmt = connection
									.prepareStatement("UPDATE _1030 SET F05 = ? WHERE F01 = ?")) {
								pstmt.setTimestamp(1, new Timestamp(creationTime + maxIdleTime));

								pstmt.setLong(2, id);
								pstmt.executeUpdate();
							}
						}
					} else if (id <= 0L) {
						{
							try (PreparedStatement preparedStatement = connection.prepareStatement(
									"INSERT INTO _1030 SET F02 = ?, F03 = ?, F04 = ?, F05 = ?, F06 = ?, F07 = ? ON DUPLICATE KEY UPDATE F03 = VALUES(F03), F04 = VALUES(F04), F05 = VALUES(F05), F06 = VALUES(F06), F07 = VALUES(F07)",
									1)) {
								preparedStatement.setString(1, cookie.getValue());
								preparedStatement.setTimestamp(2, new Timestamp(creationTime));

								preparedStatement.setNull(3, 4);
								preparedStatement.setTimestamp(4, new Timestamp(creationTime + maxIdleTime));

								preparedStatement.setString(5, ip);
								preparedStatement.setString(6, userAgentDigest);
								preparedStatement.execute();
								try (ResultSet resultSet = preparedStatement.getGeneratedKeys()) {
									if (resultSet.next())
										id = resultSet.getLong(1);
								}
							}
						}

						if (id > 0L) {
							try (PreparedStatement preparedStatement = connection.prepareStatement(
									"INSERT INTO _1033 SET F01 = ?, F02 = ? ON DUPLICATE KEY UPDATE F02 = VALUES(F02)")) {
								preparedStatement.setLong(1, id);
								preparedStatement.setString(2, userAgent);
								preparedStatement.execute();
							}
						}
					}
				}
			} catch (Throwable throwable) {
				resourceProvider.log(throwable);
			}
		}

		protected void register(int accountId) {
			try {
				try (Connection connection = getConnection()) {
					try (PreparedStatement preparedStatement = connection
							.prepareStatement("UPDATE _1030 SET F04 = ?, F05 = ? WHERE F01 = ?")) {
						preparedStatement.setInt(1, accountId);
						preparedStatement.setTimestamp(2, new Timestamp(System.currentTimeMillis() + getMaxIdleTime()));

						preparedStatement.setLong(3, id);
						preparedStatement.execute();
					}

					try (PreparedStatement preparedStatement = connection
							.prepareStatement("INSERT IGNORE INTO _1034 SET F01 = ?")) {
						preparedStatement.setInt(1, accountId);
						preparedStatement.execute();
					}
				}
				super.register(accountId);

			} catch (SQLException e) {
				throw new AuthenticationException("注册会话信息失败.", e);
			}

		}

		public boolean isAuthenticated() {
			return (accountId > 0) && (expires > System.currentTimeMillis());
		}

		public void invalidate(HttpServletRequest request, HttpServletResponse response) {
			super.invalidate(request, response);
			try {
				Connection connection = getConnection();
				Throwable localThrowable3 = null;
				try {
					PreparedStatement preparedStatement = connection
							.prepareStatement("UPDATE _1030 SET F04 = NULL WHERE F01 = ?");
					Throwable localThrowable4 = null;
					try {
						preparedStatement.setLong(1, id);
						preparedStatement.executeUpdate();
					} catch (Throwable localThrowable1) {
						localThrowable4 = localThrowable1;
						throw localThrowable1;
					} finally {
					}
				} catch (Throwable localThrowable2) {
					localThrowable3 = localThrowable2;
					throw localThrowable2;
				} finally {
					if (connection != null)
						if (localThrowable3 != null)
							try {
								connection.close();
							} catch (Throwable x2) {
								localThrowable3.addSuppressed(x2);
							}
						else
							connection.close();
				}
			} catch (Throwable throwable) {
				resourceProvider.log(throwable);
			}

		}

		public String getAttribute(String name) {
			if (!StringHelper.isEmpty(name))
				try {
					Connection connection = getConnection();
					Throwable localThrowable4 = null;
					try {
						PreparedStatement preparedStatement = connection
								.prepareStatement("SELECT F03 FROM _1032 WHERE F01 = ? AND F02 = ?");

						Throwable localThrowable5 = null;
						try {
							preparedStatement.setLong(1, id);
							preparedStatement.setString(2, name);
							ResultSet resultSet = preparedStatement.executeQuery();
							Throwable localThrowable6 = null;
							try {
								if (resultSet.next())
									return resultSet.getString(1);
							} catch (Throwable localThrowable7) {
								localThrowable6 = localThrowable7;
								throw localThrowable7;
							} finally {
							}
						} catch (Throwable localThrowable2) {
							localThrowable5 = localThrowable2;
							throw localThrowable2;
						} finally {
						}
					} catch (Throwable localThrowable3) {
						localThrowable4 = localThrowable3;
					} finally {
						if (connection != null)
							if (localThrowable4 != null)
								try {
									connection.close();
								} catch (Throwable x2) {
									localThrowable4.addSuppressed(x2);
								}
							else
								connection.close();
					}
				} catch (SQLException e) {
					resourceProvider.log(e);
				}

			return null;
		}

		public void setAttribute(String name, String value) {
			if (StringHelper.isEmpty(name))
				return;
			try {
				Connection connection = getConnection();
				Throwable localThrowable3 = null;
				try {
					PreparedStatement preparedStatement = connection.prepareStatement(
							"INSERT INTO _1032 SET F01 = ?, F02 = ?, F03  =? ON DUPLICATE KEY UPDATE F03 = VALUES(F03)");

					Throwable localThrowable4 = null;
					try {
						preparedStatement.setLong(1, id);
						preparedStatement.setString(2, name);
						if (StringHelper.isEmpty(value))
							preparedStatement.setNull(3, 12);
						else {
							preparedStatement.setString(3, value);
						}
						preparedStatement.executeUpdate();
					} catch (Throwable localThrowable1) {
						localThrowable4 = localThrowable1;
						throw localThrowable1;
					} finally {
					}
				} catch (Throwable localThrowable2) {
					localThrowable3 = localThrowable2;
				} finally {
					if (connection != null)
						if (localThrowable3 != null)
							try {
								connection.close();
							} catch (Throwable x2) {
								localThrowable3.addSuppressed(x2);
							}
						else
							connection.close();
				}
			} catch (SQLException e) {
				resourceProvider.log(e);
			}

		}

		public String removeAttribute(String name) {
			if (StringHelper.isEmpty(name)) {
				return null;
			}
			String value = null;
			try {
				Connection connection = getConnection();
				Throwable localThrowable5 = null;
				try {
					Throwable localThrowable6 = null;
					{
						PreparedStatement preparedStatement = connection
								.prepareStatement("SELECT F03 FROM _1032 WHERE F01 = ? AND F02 = ?");
						try {
							preparedStatement.setLong(1, id);
							preparedStatement.setString(2, name);
							ResultSet resultSet = preparedStatement.executeQuery();
							Throwable localThrowable7 = null;
							try {
								if (resultSet.next())
									value = resultSet.getString(1);
							} catch (Throwable localThrowable1) {
								localThrowable7 = localThrowable1;
								throw localThrowable1;
							} finally {
							}
						} catch (Throwable localThrowable2) {
							localThrowable6 = localThrowable2;
							throw localThrowable2;
						} finally {
						}
					}
					if (value != null) {
						PreparedStatement preparedStatement = connection
								.prepareStatement("DELETE FROM _1032 WHERE F01 = ? AND F02 = ?");
						localThrowable6 = null;
						try {
							preparedStatement.setLong(1, id);
							preparedStatement.setString(2, name);
							preparedStatement.executeUpdate();
						} catch (Throwable localThrowable3) {
							localThrowable6 = localThrowable3;
							throw localThrowable3;
						} finally {
						}
					}
				} catch (Throwable localThrowable4) {
					localThrowable5 = localThrowable4;
				} finally {
					if (connection != null)
						if (localThrowable5 != null)
							try {
								connection.close();
							} catch (Throwable x2) {
								localThrowable5.addSuppressed(x2);
							}
						else
							connection.close();
				}
			} catch (SQLException e) {
				resourceProvider.log(e);
			}

			return value;
		}

		public String getVerifyCode(String type, VerifyCodeGenerator generator) {
			if (StringHelper.isEmpty(type)) {
				return null;
			}
			String verifyCode = null;
			try {
				Connection connection = getConnection();
				Throwable localThrowable5 = null;
				try {
					Throwable localThrowable6 = null;
					{
						PreparedStatement preparedStatement = connection
								.prepareStatement("SELECT F03, F05 FROM _1031 WHERE F01 = ? AND F02 = ?");
						try {
							preparedStatement.setLong(1, id);
							preparedStatement.setString(2, type);
							ResultSet resultSet = preparedStatement.executeQuery();
							Throwable localThrowable7 = null;
							try {
								if (resultSet.next()) {
									String code = resultSet.getString(1);
									Timestamp expires = resultSet.getTimestamp(2);
									if (expires.getTime() > System.currentTimeMillis())
										verifyCode = code;
								}
							} catch (Throwable localThrowable1) {
								localThrowable7 = localThrowable1;
								throw localThrowable1;
							} finally {
							}
						} catch (Throwable localThrowable2) {
							localThrowable6 = localThrowable2;
							throw localThrowable2;
						} finally {
						}
					}
					if (verifyCode == null) {
						if (generator == null) {
							generator = SQLStoreSessionManager.DEFAULT_VERIFY_CODE_GENERATOR;
						}
						VerifyCode newCode = generator.newVerifyCode();
						PreparedStatement preparedStatement = connection.prepareStatement(
								"INSERT INTO _1031 SET F01 = ?, F02 = ?, F03 = ?, F04 = ?, F05 = ? ON DUPLICATE KEY UPDATE F03 = VALUES(F03), F04 = VALUES(F04), F05 = VALUES(F05)");
						try {
							preparedStatement.setLong(1, id);
							preparedStatement.setString(2, type);
							preparedStatement.setString(3, newCode.getDisplayValue());

							preparedStatement.setString(4, newCode.getMatchValue());
							preparedStatement.setTimestamp(5,
									new Timestamp(System.currentTimeMillis() + generator.getTTL()));

							preparedStatement.executeUpdate();
						} catch (Throwable localThrowable8) {
							localThrowable6 = localThrowable8;
							throw localThrowable8;
						} finally {
						}

						verifyCode = newCode.getDisplayValue();
					}
				} catch (Throwable localThrowable4) {
					localThrowable5 = localThrowable4;
				} finally {
					if (connection != null)
						if (localThrowable5 != null)
							try {
								connection.close();
							} catch (Throwable x2) {
								localThrowable5.addSuppressed(x2);
							}
						else
							connection.close();
				}
			} catch (SQLException e) {
				resourceProvider.log(e);
			}

			return verifyCode;
		}

		public void invalidVerifyCode(String type) {
			if (StringHelper.isEmpty(type))
				return;
			try {
				Connection connection = getConnection();
				Throwable localThrowable3 = null;
				try {
					PreparedStatement preparedStatement = connection
							.prepareStatement("DELETE FROM _1031 WHERE F01 = ? AND F02 = ?");
					Throwable localThrowable4 = null;
					try {
						preparedStatement.setLong(1, id);
						preparedStatement.setString(2, type);
						preparedStatement.executeUpdate();
					} catch (Throwable localThrowable1) {
						localThrowable4 = localThrowable1;
						throw localThrowable1;
					} finally {
					}
				} catch (Throwable localThrowable2) {
					localThrowable3 = localThrowable2;
				} finally {
					if (connection != null)
						if (localThrowable3 != null)
							try {
								connection.close();
							} catch (Throwable x2) {
								localThrowable3.addSuppressed(x2);
							}
						else
							connection.close();
				}
			} catch (SQLException e) {
				resourceProvider.log(e);
			}

		}

		public void authenticateVerifyCode(VerifyCodeAuthentication authentication) throws AuthenticationException {
			if (authentication == null) {
				return;
			}
			String verifyCode = authentication.getVerifyCode();
			if ((verifyCode == null) || (verifyCode.isEmpty())) {
				throw new AuthenticationException("必须提供校验码。");
			}
			String type = authentication.getVerifyCodeType();
			if (StringHelper.isEmpty(type))
				throw new AuthenticationException("未指定验证码类型。");
			try (Connection connection = getConnection()) {
				try (PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT F04, F05 FROM _1031 WHERE F01 = ? AND F02 = ?")) {
					preparedStatement.setLong(1, id);
					preparedStatement.setString(2, type);
					try (ResultSet resultSet = preparedStatement.executeQuery()) {
						if (resultSet.next()) {
							String code = resultSet.getString(1);
							Timestamp expires = resultSet.getTimestamp(2);
							if (expires.getTime() <= System.currentTimeMillis()) {
								throw new AuthenticationException("验证码错误或失效。");
							}

							if (verifyCode.equalsIgnoreCase(code)) {

								try (PreparedStatement pstmt = connection
										.prepareStatement("DELETE FROM _1031 WHERE F01 = ? AND F02 = ?")) {
									pstmt.setLong(1, id);
									pstmt.setString(2, type);
									pstmt.executeUpdate();
								}
							} else {
								throw new AuthenticationException("验证码错误或失效。");
							}
						} else {
							throw new AuthenticationException("验证码错误或失效。");
						}
					}

				}
			} catch (SQLException e) {
				throw new AuthenticationException("验证码校验失败。", e);
			}

		}
		public void authenticateVerifyCodeNoDelete(VerifyCodeAuthentication authentication) throws AuthenticationException {
			if (authentication == null) {
				return;
			}
			String verifyCode = authentication.getVerifyCode();
			if ((verifyCode == null) || (verifyCode.isEmpty())) {
				throw new AuthenticationException("必须提供校验码。");
			}
			String type = authentication.getVerifyCodeType();
			if (StringHelper.isEmpty(type))
				throw new AuthenticationException("未指定验证码类型。");
			try (Connection connection = getConnection()) {
				try (PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT F04, F05 FROM _1031 WHERE F01 = ? AND F02 = ?")) {
					preparedStatement.setLong(1, id);
					preparedStatement.setString(2, type);
					try (ResultSet resultSet = preparedStatement.executeQuery()) {
						if (resultSet.next()) {
							String code = resultSet.getString(1);
							Timestamp expires = resultSet.getTimestamp(2);
							if (expires.getTime() <= System.currentTimeMillis()) {
								throw new AuthenticationException("验证码错误或失效。");
							}
							if (verifyCode.equalsIgnoreCase(code)) {

							} else {
								throw new AuthenticationException("验证码错误或失效。");
							}
						} else {
							throw new AuthenticationException("验证码错误或失效。");
						}
					}
					
				}
			} catch (SQLException e) {
				throw new AuthenticationException("验证码校验失败。", e);
			}
			
		}
		protected void checkUserFundsError(String accountName){
			try {
				Connection connection = getConnection();
				Throwable localThrowable4 = null;
				try {
					PreparedStatement pstmt = connection
							.prepareStatement("SELECT F06,F08 FROM zch_s60.T6010 WHERE F02 = ?");
					Throwable localThrowable5 = null;
					try {
						pstmt.setString(1, accountName);
						ResultSet resultSet = pstmt.executeQuery();
						Throwable localThrowable6 = null;
						try {
							if ((resultSet.next()) && (resultSet.getString(1)!=null)){
								if(resultSet.getString(1).equals("S") && resultSet.getString(2).contains("funds_abnormal")){
									throw new AuthenticationException("此账号资金异常，已被锁定");
								}
								if(resultSet.getString(1).equals("S") && resultSet.getString(2).contains("admin_lock")){
									throw new AuthenticationException("此账号被锁定");
								}
							}
						} catch (Throwable localThrowable1) {
							localThrowable6 = localThrowable1;
							throw localThrowable1;
						} finally {
						}
					} catch (Throwable localThrowable2) {
						localThrowable5 = localThrowable2;
						throw localThrowable2;
					} finally {
					}
				} catch (Throwable localThrowable3) {
					localThrowable4 = localThrowable3;
					throw localThrowable3;
				} finally {
					if (connection != null)
						if (localThrowable4 != null)
							try {
								connection.close();
							} catch (Throwable x2) {
								localThrowable4.addSuppressed(x2);
							}
						else
							connection.close();
				}
			} catch (ResourceNotFoundException | SQLException e) {
				resourceProvider.log(e);
			}
		}
		protected void checkMaxErrorTimes(String accountName) throws AuthenticationException {
			int maxErrorTimes = resourceProvider.getSystemDefine().getMaxErrorTimes();

			if (maxErrorTimes <= 0)
				return;
			try {
				Connection connection = getConnection();
				Throwable localThrowable4 = null;
				try {
					PreparedStatement pstmt = connection
							.prepareStatement("SELECT F03 FROM _1037 WHERE F01 = ? AND F02 = ?");
					Throwable localThrowable5 = null;
					try {
						pstmt.setString(1, accountName);
						pstmt.setString(2, ip);
						ResultSet resultSet = pstmt.executeQuery();
						Throwable localThrowable6 = null;
						try {
							if ((resultSet.next()) && (resultSet.getInt(1) >= maxErrorTimes))
								throw new AuthenticationException("密码错误次数已达上限，请明天再试");//您的账户被锁定,请明天再尝试
						} catch (Throwable localThrowable1) {
							localThrowable6 = localThrowable1;
							throw localThrowable1;
						} finally {
						}
					} catch (Throwable localThrowable2) {
						localThrowable5 = localThrowable2;
						throw localThrowable2;
					} finally {
					}
				} catch (Throwable localThrowable3) {
					localThrowable4 = localThrowable3;
					throw localThrowable3;
				} finally {
					if (connection != null)
						if (localThrowable4 != null)
							try {
								connection.close();
							} catch (Throwable x2) {
								localThrowable4.addSuppressed(x2);
							}
						else
							connection.close();
				}
			} catch (ResourceNotFoundException | SQLException e) {
				resourceProvider.log(e);
			}
		}

		protected void markError(String accountName) {
			try {
				Connection connection = getConnection();
				Throwable localThrowable3 = null;
				try {
					PreparedStatement pstmt = connection.prepareStatement(
							"INSERT INTO _1037 SET F01 = ?, F02 = ?, F03 = 1 ON DUPLICATE KEY UPDATE F03 = F03+1");
					Throwable localThrowable4 = null;
					try {
						pstmt.setString(1, accountName);
						pstmt.setString(2, ip);
						pstmt.execute();
					} catch (Throwable localThrowable1) {
						localThrowable4 = localThrowable1;
						throw localThrowable1;
					} finally {
					}
				} catch (Throwable localThrowable2) {
					localThrowable3 = localThrowable2;
					throw localThrowable2;
				} finally {
					if (connection != null)
						if (localThrowable3 != null)
							try {
								connection.close();
							} catch (Throwable x2) {
								localThrowable3.addSuppressed(x2);
							}
						else
							connection.close();
				}
			} catch (ResourceNotFoundException | SQLException e) {
				resourceProvider.log(e);
			}

		}
	}
}