package com.quqian.framework.config.achieve;

import com.quqian.framework.config.ConfigureProvider;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.framework.resource.cycle.Startup;

public class VariablesPreLoader
  implements Startup
{
  public void onStartup(ResourceProvider resourceProvider)
  {
    ConfigureProvider configureProvider = (ConfigureProvider)resourceProvider.getResource(ConfigureProvider.class);

    if ((configureProvider instanceof DefaultConfigureProvider)) {
      DefaultConfigureProvider provider = (DefaultConfigureProvider)configureProvider;
      provider.preload();
    }
  }
}