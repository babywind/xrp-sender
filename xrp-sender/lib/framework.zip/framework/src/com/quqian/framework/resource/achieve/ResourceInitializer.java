package com.quqian.framework.resource.achieve;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.ServletContainerInitializer;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.HandlesTypes;
import javax.servlet.http.HttpServlet;

import com.quqian.framework.config.ConfigureProvider;
import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.config.entity.ModuleBean;
import com.quqian.framework.data.DataConnectionProvider;
import com.quqian.framework.http.entity.RightBean;
import com.quqian.framework.http.servlet.Controller;
import com.quqian.framework.http.servlet.Rewriter;
import com.quqian.framework.http.servlet.annotation.Module;
import com.quqian.framework.http.servlet.annotation.Right;
import com.quqian.framework.http.session.SessionManager;
import com.quqian.framework.log.Logger;
import com.quqian.framework.resource.InitParameterProvider;
import com.quqian.framework.resource.NamedResource;
import com.quqian.framework.resource.Resource;
import com.quqian.framework.resource.ResourceAnnotation;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.framework.resource.ResourceRegister;
import com.quqian.framework.resource.ResourceRetention;
import com.quqian.framework.resource.cycle.Shutdown;
import com.quqian.framework.resource.cycle.Startup;
import com.quqian.framework.service.ServiceFactory;
import com.quqian.framework.service.ServiceProvider;
import com.quqian.util.StringHelper;

@HandlesTypes({ ServiceFactory.class, Right.class, Module.class,
		SystemDefine.class, DataConnectionProvider.class,
		ConfigureProvider.class, SessionManager.class, ServiceProvider.class,
		Resource.class, NamedResource.class, Startup.class, Shutdown.class,
		HttpServlet.class })
public class ResourceInitializer extends ResourceRegister implements
		ServletContainerInitializer {
	protected static boolean isDenied(ResourceRetention retention,
			ResourceRetention[] acceptRetentions) {
		boolean denied = true;
		for (ResourceRetention acceptRetention : acceptRetentions) {
			if (retention == acceptRetention) {
				denied = false;
				break;
			}
		}
		return denied;
	}

	public ResourceProvider initialize(Set<Class<?>> classes, String[] arguments) {
		return initialize(classes, System.getProperty("user.dir"),
				new Logger() {
					public void log(String message) {
						System.out.println(message);
					}

					public void log(Throwable throwable) {
						throwable.printStackTrace();
					}
				}, null, new ArgumentInitParameterProvider(arguments));
	}

	public ResourceProvider initialize(Set<Class<?>> classes, Logger logger,
			String[] arguments) {
		return initialize(classes, System.getProperty("user.dir"), logger,
				null, new ArgumentInitParameterProvider(arguments));
	}

	private ResourceProvider initialize(Set<Class<?>> classes, String home,
			Logger logger, String contextURI,
			InitParameterProvider initParameterProvider) {
		if (classes == null) {
			logger.log("没有任何可用的资源存在.");
			return null;
		}
		Set systemDefines = new LinkedHashSet(1);

		Set configureProviders = new LinkedHashSet(1);

		Set connectionProviders = new LinkedHashSet(1);

		Set sessionManagers = new LinkedHashSet(1);

		Set serviceProviders = new LinkedHashSet(1);

		Set otherResources = new LinkedHashSet(1);
		Set serviceFactories = new HashSet();
		Set startups = new LinkedHashSet();
		final Set<Class<?>> shutdowns = new LinkedHashSet();

		for (Class clazz : classes) {
			int modifier = clazz.getModifiers();
			if ((!Modifier.isAbstract(modifier))
					&& (!Modifier.isInterface(modifier))) {
				if (Startup.class.isAssignableFrom(clazz)) {
					startups.add(clazz);
				}
				if (Shutdown.class.isAssignableFrom(clazz)) {
					shutdowns.add(clazz);
				}
				if (ServiceFactory.class.isAssignableFrom(clazz)) {
					serviceFactories.add(clazz);
				}

				if (SystemDefine.class.isAssignableFrom(clazz))
					systemDefines.add(clazz);
				else if (ConfigureProvider.class.isAssignableFrom(clazz)) {
					configureProviders.add(clazz);
				} else if (DataConnectionProvider.class.isAssignableFrom(clazz)) {
					connectionProviders.add(clazz);
				} else if (SessionManager.class.isAssignableFrom(clazz)) {
					sessionManagers.add(clazz);
				} else if (ServiceProvider.class.isAssignableFrom(clazz)) {
					serviceProviders.add(clazz);
				} else if (Resource.class.isAssignableFrom(clazz)) {
					otherResources.add(clazz);
				}
			}
		}
		SystemDefine systemDefine = null;
		try {
			if (systemDefines.size() == 0) {
				systemDefine = null;
			} else {
				Iterator i$ = systemDefines.iterator();
				if (i$.hasNext()) {
					Class s = (Class) i$.next();
					systemDefine = (SystemDefine) s.newInstance();
				}
			}
		} catch (Throwable t) {
			logger.log(t);
		}
		if (systemDefine == null) {
			logger.log("找不到系统配置信息.");
			return null;
		}
		MappedResourceProvider resourceProvider = new MappedResourceProvider(
				home, logger, contextURI, initParameterProvider, systemDefine) {
			public synchronized void close() {
				if ((shutdowns != null) && (shutdowns.size() > 0)) {
					for (Class shutdown : shutdowns)
						if ((shutdown != null)
								&& (!shutdown.isInterface())
								&& (!Modifier.isAbstract(shutdown
										.getModifiers()))) {
							try {
								((Shutdown) shutdown.newInstance())
										.onShutdown(this);
							} catch (Throwable throwable) {
								log(throwable);
							}
						}
				}
				super.close();
			}
		};
		loadRights(classes, resourceProvider);
		ResourceRetention retention = resourceProvider.getResourceRetention();
		if (retention == null) {
			retention = ResourceRetention.DEVELOMENT;
		}

		loadCongifureProvider(configureProviders, resourceProvider);

		loadDataConnectionProviders(connectionProviders, resourceProvider,
				retention);

		loadSessionManager(sessionManagers, resourceProvider, retention);

		loadServiceProvider(serviceProviders, resourceProvider, retention,
				serviceFactories);

		loadOtherResources(otherResources, resourceProvider, retention);

		doStartup(resourceProvider, startups);
		return resourceProvider;
	}

	public void onStartup(Set<Class<?>> classes,
			final ServletContext servletContext) throws ServletException {
		ResourceProvider resourceProvider = initialize(classes,
				servletContext.getRealPath("/"), new Logger() {
					public void log(String message) {
						servletContext.log(message);
					}

					public void log(Throwable throwable) {
						servletContext.log(throwable.getMessage(), throwable);
					}
				}, servletContext.getContextPath(),
				new ServletInitParameterProvider(servletContext));

		if (resourceProvider == null) {
			return;
		}

		ResourceRegister.initialize(servletContext, resourceProvider);
		Rewriter rewriter = resourceProvider.getSystemDefine().getRewriter();
		Set servlets = new HashSet();
		if (classes != null) {
			for (Class clazz : classes) {
				if ((clazz != null)
						&& (HttpServlet.class.isAssignableFrom(clazz))
						&& (!clazz.isInterface())
						&& (!Modifier.isAbstract(clazz.getModifiers()))) {
					Class servlet = clazz;
					if (rewriter.isAccepted(servlet))
						servlets.add(servlet);
				}
			}
		}
		((Controller) resourceProvider.getResource(Controller.class))
				.initialize(servletContext, rewriter, servlets);
	}

	protected void loadRights(Set<Class<?>> classes,
			MappedResourceProvider resourceProvider) {
		Map modules = new TreeMap();
		ModuleBeanImpl nillModuleBean = new ModuleBeanImpl(null);
		Map moduleCache = new HashMap();
		for (Class type : classes) {
			Right right = (Right) type.getAnnotation(Right.class);
			if (right != null) {
				Module module = null;

				String name = type.getPackage().getName();
				int lastIndex = name.length();
				while (lastIndex != -1) {
					module = (Module) moduleCache.get(name);
					if (module != null) {
						break;
					}
					Package pkg = Package.getPackage(name);
					if (pkg != null) {
						module = (Module) pkg.getAnnotation(Module.class);
						if (module != null) {
							moduleCache.put(name, module);
							break;
						}
					}
					lastIndex = name.lastIndexOf('.');
					if (lastIndex == -1) {
						break;
					}
					name = name.substring(0, lastIndex);
				}
				ModuleBeanImpl moduleBean;
				if ((module == null) || (StringHelper.isEmpty(module.id()))) {
					moduleBean = nillModuleBean;
				} else {
					moduleBean = (ModuleBeanImpl) modules.get(module.id());
					if (moduleBean == null) {
						moduleBean = new ModuleBeanImpl(module);
						modules.put(moduleBean.getId(), moduleBean);
					}
				}
				moduleBean.addRight(right,
						type.getAnnotation(Deprecated.class) != null);
			}
		}
		resourceProvider.setModuleBeans((ModuleBean[]) modules.values()
				.toArray(new ModuleBean[modules.size()]));
	}

	protected ConfigureProvider loadCongifureProvider(
			Set<Class<? extends ConfigureProvider>> classes,
			MappedResourceProvider resourceProvider) {
		if ((classes == null) || (classes.size() == 0)) {
			return null;
		}
		for (Class clazz : classes) {
			try {
				Constructor constructor = clazz
						.getConstructor(new Class[] { ResourceProvider.class });

				ConfigureProvider resource = (ConfigureProvider) constructor
						.newInstance(new Object[] { resourceProvider });

				resourceProvider.registerResource(resource);
				return resource;
			} catch (Throwable e) {
				resourceProvider.log(e);
			}
		}
		return null;
	}

	protected void loadDataConnectionProviders(
			Set<Class<? extends DataConnectionProvider>> classes,
			MappedResourceProvider resourceProvider, ResourceRetention retention) {
		if ((classes == null) || (classes.size() == 0)) {
			return;
		}
		for (Class clazz : classes) {
			ResourceAnnotation annotation = (ResourceAnnotation) clazz
					.getAnnotation(ResourceAnnotation.class);

			if ((annotation != null)
					&& (!isDenied(retention, annotation.value()))) {
				try {
					DataConnectionProvider provider = (DataConnectionProvider) clazz
							.getConstructor(
									new Class[] { InitParameterProvider.class,
											Logger.class }).newInstance(
									new Object[] { resourceProvider,
											resourceProvider });

					resourceProvider.registerConnectionProvider(provider);
				} catch (Throwable e) {
					resourceProvider.log(e);
				}
			}
		}
	}

	protected void loadSessionManager(
			Set<Class<? extends SessionManager>> classes,
			MappedResourceProvider resourceProvider, ResourceRetention retention) {
		if ((classes == null) || (classes.size() == 0)) {
			return;
		}
		for (Class clazz : classes) {
			ResourceAnnotation annotation = (ResourceAnnotation) clazz
					.getAnnotation(ResourceAnnotation.class);

			if ((annotation != null)
					&& (!isDenied(retention, annotation.value()))) {
				try {
					Constructor constructor = clazz
							.getConstructor(new Class[] { ResourceProvider.class });

					SessionManager resource = (SessionManager) constructor
							.newInstance(new Object[] { resourceProvider });

					resourceProvider.registerResource(resource);
				} catch (Throwable e) {
					resourceProvider.log(e);
				}
			}
		}
	}

	protected void loadServiceProvider(
			Set<Class<? extends ServiceProvider>> classes,
			MappedResourceProvider resourceProvider,
			ResourceRetention retention,
			Set<Class<? extends ServiceFactory<?>>> serviceFactories) {
		ServiceProvider serviceProvider = null;
		for (Class clazz : classes) {
			ResourceAnnotation annotation = (ResourceAnnotation) clazz
					.getAnnotation(ResourceAnnotation.class);

			if ((annotation != null)
					&& (!isDenied(retention, annotation.value()))) {
				try {
					Constructor constructor = clazz
							.getConstructor(new Class[] { ResourceProvider.class });

					serviceProvider = (ServiceProvider) constructor
							.newInstance(new Object[] { resourceProvider });
					resourceProvider.registerResource(serviceProvider);
				} catch (Throwable e) {
					resourceProvider.log(e);
				}
			}
		}
		if (serviceFactories != null)
			serviceProvider.registerServiceFactories(serviceFactories);
	}

	protected void loadOtherResources(Set<Class<? extends Resource>> classes,
			MappedResourceProvider resourceProvider, ResourceRetention retention) {
		if ((classes == null) || (classes.size() == 0)) {
			return;
		}
		for (Class clazz : classes) {
			ResourceAnnotation annotation = (ResourceAnnotation) clazz
					.getAnnotation(ResourceAnnotation.class);

			if ((annotation != null)
					&& (!isDenied(retention, annotation.value()))) {
				try {
					Constructor constructor = clazz
							.getConstructor(new Class[] { ResourceProvider.class });

					Resource resource = (Resource) constructor
							.newInstance(new Object[] { resourceProvider });

					resourceProvider.registerResource(resource);
				} catch (Throwable e) {
					resourceProvider.log(e);
				}
			}
		}
	}

	protected void doStartup(MappedResourceProvider resourceProvider,
			Set<Class<? extends Startup>> startups) {
		if ((startups == null) || (startups.size() == 0)) {
			return;
		}
		for (Class startup : startups)
			if ((!startup.isInterface())
					&& (!Modifier.isAbstract(startup.getModifiers()))) {
				try {
					((Startup) startup.newInstance())
							.onStartup(resourceProvider);
				} catch (InstantiationException | IllegalAccessException throwable) {
					resourceProvider.log(throwable);
				}
			}
	}

	private class ModuleBeanImpl implements ModuleBean {
		private static final long serialVersionUID = 1L;
		final Map<String, RightBeanImpl> rights = new LinkedHashMap();
		protected Module module;

		public ModuleBeanImpl(Module module) {
			this.module = module;
		}

		private void addRight(Right right, boolean deprecated) {
			RightBeanImpl rightBean = (RightBeanImpl) rights.get(right.id());
			if (rightBean != null) {
				return;
			}
			rights.put(right.id(), new RightBeanImpl(right, deprecated));
		}

		public String getId() {
			return module == null ? "" : module.id();
		}

		public String getName() {
			return module == null ? "" : module.name();
		}

		public String getDescription() {
			return module == null ? "" : module.description();
		}

		public RightBean[] getRightBeans() {
			return (RightBean[]) rights.values().toArray(
					new RightBean[rights.size()]);
		}

		private class RightBeanImpl implements RightBean {
			private static final long serialVersionUID = 1L;
			boolean deprecated;
			Right right;

			public RightBeanImpl(Right right, boolean deprecated) {
				this.right = right;
				this.deprecated = deprecated;
			}

			public String getId() {
				return right.id();
			}

			public String getName() {
				return right.name();
			}

			public String getDescription() {
				return right.description();
			}

			public String getModuleId() {
				return ResourceInitializer.ModuleBeanImpl.this.getId();
			}

			public boolean isDeprecated() {
				return deprecated;
			}

			public boolean isMenu() {
				return right.isMenu();
			}
		}
	}
}