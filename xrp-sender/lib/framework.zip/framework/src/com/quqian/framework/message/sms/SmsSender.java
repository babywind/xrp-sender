package com.quqian.framework.message.sms;

import com.quqian.framework.service.Service;

public abstract interface SmsSender extends Service {
	
	public abstract void send(String channel,int tempId,String msg, String params,
			String... receivers) throws Throwable;
}