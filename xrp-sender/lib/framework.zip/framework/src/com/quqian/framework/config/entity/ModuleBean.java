package com.quqian.framework.config.entity;

import com.quqian.framework.http.entity.RightBean;

import java.io.Serializable;

public abstract interface ModuleBean extends Serializable
{
  public abstract String getId();

  public abstract String getName();

  public abstract String getDescription();

  public abstract RightBean[] getRightBeans();
}