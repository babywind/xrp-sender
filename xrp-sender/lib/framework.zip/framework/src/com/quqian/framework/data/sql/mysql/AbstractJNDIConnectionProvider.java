package com.quqian.framework.data.sql.mysql;

import com.quqian.framework.data.sql.SQLConnection;
import com.quqian.framework.log.Logger;
import com.quqian.framework.resource.InitParameterProvider;

import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public abstract class AbstractJNDIConnectionProvider extends AbstractMySQLConnectionProvider
{
  protected abstract String getResource();

  public AbstractJNDIConnectionProvider(InitParameterProvider parameterProvider, Logger logger)
  {
    super(parameterProvider, logger);
  }

  public SQLConnection getConnection() throws SQLException
  {
    try {
      Context context = (Context)new InitialContext().lookup("java:/comp/env");

      String resource = getResource();
      Object object = context.lookup(resource);
      if ((object == null) || (!(object instanceof DataSource))) {
        throw new NamingException(resource);
      }
      return new ConnectionWrapper(((DataSource)object).getConnection());
    } catch (Throwable e) {
      throw new SQLException(e);
    }
  }

  public void close()
  {
  }
}