package com.quqian.framework.http.achieve.servlet.view;

import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.http.servlet.Controller;
import com.quqian.framework.http.servlet.Rewriter;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.framework.resource.ResourceRegister;
import com.quqian.util.StringHelper;

import java.io.IOException;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PrdViewController extends DefaultViewController
{
  private static final long serialVersionUID = 1L;

  public void init(ServletConfig config)
    throws ServletException
  {
    super.init(config);
  }

  protected void service(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    ServletContext servletContext = getServletContext();
    ResourceProvider resourceProvider = ResourceRegister.getResourceProvider(servletContext);

    Controller controller = (Controller)resourceProvider.getResource(Controller.class);
    String path = controller.getViewFile(request);
    if (path == null) {
      String viewURI = request.getRequestURI();
      path = (String)dynamicPathes.get(viewURI);
      if (path == null) {
        Rewriter rewriter = resourceProvider.getSystemDefine().getRewriter();

        String viewSuffix = rewriter.getViewSuffix();
        String contextPath = request.getContextPath();
        if (viewURI.endsWith(viewSuffix)) {
          StringBuilder builder = new StringBuilder(rewriter.getViewRoot());

          if ((StringHelper.isEmpty(contextPath)) || ("/".equals(contextPath)))
          {
            builder.append(viewURI, 0, viewURI.length() - viewSuffix.length());
          }
          else {
            builder.append(viewURI, contextPath.length(), viewURI.length() - viewSuffix.length());
          }

          builder.append(rewriter.getViewFileSuffix());
          path = builder.toString();
        } else {
          if ((welcomeFileList == null) || (welcomeFileList.length == 0)) {
            response.sendError(404, viewURI);

            return;
          }
          StringBuilder builder = new StringBuilder(rewriter.getViewRoot());

          if ((StringHelper.isEmpty(contextPath)) || ("/".equals(contextPath)))
          {
            builder.append(viewURI);
          }
          else builder.append(viewURI, contextPath.length(), viewURI.length());

          if (viewURI.charAt(viewURI.length() - 1) != '/') {
            builder.append('/');
          }
          int length = builder.length();

          for (String welcomeFile : welcomeFileList) {
            builder.append(welcomeFile);
            String tmpPath = builder.toString();
            builder.setLength(length);
            if (servletContext.getResource(tmpPath) != null) {
              path = tmpPath;
              break;
            }
          }
          if (path == null) {
            response.sendError(404, viewURI);

            return;
          }
        }
        dynamicPathes.put(viewURI, path);
      }
    }
    RequestDispatcher dispatcher = servletContext.getRequestDispatcher(path);

    dispatcher.forward(request, response);
  }
}