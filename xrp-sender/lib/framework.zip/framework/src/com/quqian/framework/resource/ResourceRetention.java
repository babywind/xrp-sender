package com.quqian.framework.resource;

public enum ResourceRetention
{
  DEVELOMENT, 

  PRE_PRODUCTION, 

  PRODUCTION;
}