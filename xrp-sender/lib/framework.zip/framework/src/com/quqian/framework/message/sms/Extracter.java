package com.quqian.framework.message.sms;

import com.quqian.framework.message.sms.entity.SmsTask;
import com.quqian.framework.service.Service;

public abstract interface Extracter extends Service
{
  public abstract SmsTask[] extract(int paramInt1, int paramInt2)
    throws Throwable;

  public abstract void mark(long paramLong, boolean paramBoolean, String paramString)
    throws Throwable;
}