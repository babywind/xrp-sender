package com.quqian.framework.data.sql.mysql;

import com.quqian.framework.data.sql.SQLConnectionProvider;
import com.quqian.framework.log.Logger;
import com.quqian.framework.resource.InitParameterProvider;

public abstract class AbstractMySQLConnectionProvider extends SQLConnectionProvider
{
  public AbstractMySQLConnectionProvider(InitParameterProvider parameterProvider, Logger logger)
  {
    super(parameterProvider, logger);
  }

  public String allMatch(String value)
  {
    StringBuilder builder = new StringBuilder(value.length() + 2);
    builder.append('%').append(value).append('%');
    return builder.toString();
  }

  public String prefixMatch(String value)
  {
    return '%' + value;
  }

  public String subfixMatch(String value)
  {
    return value + '%';
  }
}