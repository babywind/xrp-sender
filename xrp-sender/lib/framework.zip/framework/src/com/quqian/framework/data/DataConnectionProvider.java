package com.quqian.framework.data;

import com.quqian.framework.log.Logger;
import com.quqian.framework.resource.InitParameterProvider;

public abstract class DataConnectionProvider
  implements AutoCloseable
{
  protected final InitParameterProvider parameterProvider;
  protected final Logger logger;

  public DataConnectionProvider(InitParameterProvider parameterProvider, Logger logger)
  {
    this.parameterProvider = parameterProvider;
    this.logger = logger;
  }

  public abstract String getName();

  public abstract Class<? extends DataConnectionProvider> getIdentifiedType();

  public abstract DataConnection getConnection()
    throws Throwable;

  public abstract DataConnection getConnection(String paramString)
    throws Throwable;

  public abstract void close();
}