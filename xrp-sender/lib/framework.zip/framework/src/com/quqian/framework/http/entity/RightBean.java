package com.quqian.framework.http.entity;

import java.io.Serializable;

public abstract interface RightBean extends Serializable
{
  public abstract String getId();

  public abstract String getName();

  public abstract String getDescription();

  public abstract String getModuleId();

  public abstract boolean isDeprecated();

  public abstract boolean isMenu();
}