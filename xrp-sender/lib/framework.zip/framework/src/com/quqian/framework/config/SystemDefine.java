package com.quqian.framework.config;

import com.quqian.framework.config.entity.VariableType;
import com.quqian.framework.http.servlet.Rewriter;
import com.quqian.framework.http.session.authentication.AuthenticationException;
import com.quqian.framework.http.session.authentication.PasswordAuthentication;
import com.quqian.framework.resource.Resource;
import com.quqian.framework.service.ServiceSession;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract class SystemDefine
{
  public boolean isStrictMVC()
  {
    return false;
  }

  public abstract String getGUID();

  public abstract String getSystemName();

  public abstract String getSystemDescription();

  public abstract int getMajorVersion();

  public abstract int getMinorVersion();

  public abstract int getBuildVersion();

  public abstract Rewriter getRewriter();

  public abstract VariableType[] getVariableTypes();

  public abstract int readAccountId(ServiceSession paramServiceSession, String paramString1, String paramString2)
    throws AuthenticationException, SQLException;

  public abstract void writeLog(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, ServiceSession paramServiceSession, PasswordAuthentication paramPasswordAuthentication, int paramInt);

  public abstract String getDataProvider(Class<? extends Resource> paramClass);

  public abstract String getSchemaName(Class<? extends Resource> paramClass);

  public abstract String getSiteDomainKey();

  public abstract String getSiteIndexKey();
  
  public abstract String getWapDomainKey();

  public abstract String getWapIndexKey();

  public int getMaxErrorTimes()
  {
    return 5;
  }
}