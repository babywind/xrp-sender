package com.quqian.framework.resource;

public enum PromptLevel {
	INFO,

	WARRING,

	ERROR;
	
	public String parameterKey() {
		return name();
	}
}