package com.quqian.framework.http.servlet;

import com.quqian.util.StringHelper;

import javax.servlet.http.HttpServlet;

public class PackageRewriter
  implements Rewriter
{
  protected final String rootPackage;

  public PackageRewriter(Package rootPackage)
  {
    this.rootPackage = rootPackage.getName();
  }

  public PackageRewriter(String rootPackageName) {
    rootPackage = rootPackageName;
  }

  protected String doGet(String contextPath, Class<? extends HttpServlet> servletClass, String subfix)
    throws ServletNotFoundException
  {
    String name = servletClass.getCanonicalName();
    if (name.startsWith(rootPackage)) {
      StringBuilder builder = new StringBuilder();
      if ((!StringHelper.isEmpty(contextPath)) && (!"/".equals(contextPath)))
      {
        builder.append(contextPath);
      }

      int lastIndex = name.lastIndexOf('.') + 1;
      for (int index = rootPackage.length(); index < name.length(); index++) {
        char ch = name.charAt(index);
        switch (ch) {
        case '.':
          builder.append('/');
          break;
        default:
          if (lastIndex == index)
            builder.append(Character.toLowerCase(ch));
          else {
            builder.append(ch);
          }
          break;
        }
      }

      builder.append(subfix);
      return builder.toString();
    }
    throw new ServletNotFoundException(String.format("重写规则不支持该Servlet:%s", new Object[] { name }));
  }

  public String getURI(String contextPath, Class<? extends HttpServlet> servletClass)
    throws ServletNotFoundException
  {
    return doGet(contextPath, servletClass, getSuffix());
  }

  public String getViewURI(String contextPath, Class<? extends HttpServlet> servletClass)
    throws ServletNotFoundException
  {
    return doGet(contextPath, servletClass, getViewSuffix());
  }

  public String getSuffix()
  {
    return ".htm";
  }

  public String getViewSuffix()
  {
    return ".html";
  }

  public String getViewRoot() {
    return "/WEB-INF/pages";
  }

  public String getViewFileSuffix() {
    return ".jsp";
  }

  public boolean isAccepted(Class<? extends HttpServlet> servletClass)
  {
    return servletClass == null ? false : servletClass.getCanonicalName().startsWith(rootPackage);
  }

  public String getPathURI(String contextPath, Class<? extends HttpServlet> servletClass)
    throws ServletNotFoundException
  {
    return doGet(contextPath, servletClass, "/");
  }

  public String getViewFilePath(Class<? extends HttpServlet> servletClass)
    throws ServletNotFoundException
  {
    return doGet(getViewRoot(), servletClass, getViewFileSuffix());
  }
}