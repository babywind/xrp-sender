package com.quqian.framework.http.upload;

import java.io.IOException;
import java.io.InputStream;

public abstract interface UploadFile
{
  public abstract String getSuffix();

  public abstract InputStream getInputStream()
    throws IOException;
}