package com.quqian.framework.message;

import com.quqian.framework.resource.Resource;
import com.quqian.framework.resource.ResourceProvider;

public abstract class MessageProvider extends Resource
{
  public MessageProvider(ResourceProvider resourceProvider)
  {
    super(resourceProvider);
  }

  public final Class<? extends Resource> getIdentifiedType()
  {
    return MessageProvider.class;
  }
}