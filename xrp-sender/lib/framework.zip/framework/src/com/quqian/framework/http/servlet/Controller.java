package com.quqian.framework.http.servlet;

import com.quqian.framework.resource.PromptLevel;
import com.quqian.framework.resource.Prompter;
import com.quqian.framework.resource.Resource;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.util.StringHelper;
import com.quqian.util.parser.IntegerParser;

import java.io.IOException;
import java.util.Set;

import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract class Controller extends Resource {
	protected static String REMOTE_AGENT_HEADER = "x-agent";
	protected static String REMOTE_ADDRESS_HEADER = "x-for";
	protected static String SCHEME_HEADER = "x-scheme";
	protected static String SERVER_HEADER = "x-server";
	protected static String PORT_HEADER = "x-port";

	public Controller(ResourceProvider resourceProvider) {
		super(resourceProvider);
	}

	public Class<? extends Resource> getIdentifiedType() {
		return Controller.class;
	}

	protected void writeHostName(HttpServletRequest request, int defaultPort,
			StringBuilder builder) {
		String serverName = request.getHeader(SERVER_HEADER);
		if (StringHelper.isEmpty(serverName)) {
			serverName = request.getServerName();
		}
		int port = IntegerParser.parse(request.getHeader(PORT_HEADER), 0);
		if (port == 0) {
			port = request.getServerPort();
		}
		if (port == defaultPort) {
			builder.append(serverName);
		} else {
			builder.append(serverName);
			builder.append(':').append(Integer.toString(port));
		}
	}

	public String getHostName(HttpServletRequest request) {
		StringBuilder builder = new StringBuilder();
		writeHostName(request, isSecure(request) ? 443 : 80, builder);
		return builder.toString();
	}

	public String getRemoteAgent(HttpServletRequest request) {
		String remoteAgent = request.getHeader(REMOTE_AGENT_HEADER);
		if (StringHelper.isEmpty(remoteAgent)) {
			remoteAgent = request.getHeader("User-Agent");
		}
		return remoteAgent;
	}

	public String getRemoteAddr(HttpServletRequest request) {
		String remoteAddr = request.getHeader(REMOTE_ADDRESS_HEADER);
		if (StringHelper.isEmpty(remoteAddr)) {
			remoteAddr = request.getRemoteAddr();
		}
		return remoteAddr;
	}

	public boolean isSecure(HttpServletRequest request) {
		return (request.isSecure())
				|| ("1".equals(request.getHeader(SCHEME_HEADER)));
	}

	public abstract String getStaticPath(
			HttpServletRequest paramHttpServletRequest,
			String... paramArrayOfString);

	public abstract String getRedirect(
			HttpServletRequest paramHttpServletRequest, String paramString);

	public abstract String getURI(HttpServletRequest paramHttpServletRequest,
			Class<? extends Servlet> paramClass)
			throws ServletNotFoundException;

	public abstract String getViewURI(
			HttpServletRequest paramHttpServletRequest,
			Class<? extends Servlet> paramClass)
			throws ServletNotFoundException;

	public abstract String getPagingURI(
			HttpServletRequest paramHttpServletRequest,
			Class<? extends Servlet> paramClass)
			throws ServletNotFoundException;

	public abstract String getPagingItemURI(
			HttpServletRequest paramHttpServletRequest,
			Class<? extends Servlet> paramClass, long paramLong)
			throws ServletNotFoundException;

	public abstract String getPagingItemURI(
			HttpServletRequest paramHttpServletRequest,
			Class<? extends Servlet> paramClass, int paramInt)
			throws ServletNotFoundException;

	public abstract String getPagingItemURI(
			HttpServletRequest paramHttpServletRequest,
			Class<? extends Servlet> paramClass, String paramString)
			throws ServletNotFoundException;

	public abstract String getForwardURI(
			HttpServletRequest paramHttpServletRequest,
			Class<? extends Servlet> paramClass)
			throws ServletNotFoundException;

	public abstract String getViewForwardURI(
			HttpServletRequest paramHttpServletRequest,
			Class<? extends Servlet> paramClass)
			throws ServletNotFoundException;

	public abstract void sendRedirect(
			HttpServletRequest paramHttpServletRequest,
			HttpServletResponse paramHttpServletResponse, String paramString)
			throws ServletException, IOException;

	public abstract void forward(HttpServletRequest paramHttpServletRequest,
			HttpServletResponse paramHttpServletResponse, String paramString)
			throws ServletException, IOException;

	public abstract void forwardController(
			HttpServletRequest paramHttpServletRequest,
			HttpServletResponse paramHttpServletResponse,
			Class<? extends HttpServlet> paramClass) throws ServletException,
			IOException;

	public abstract void forwardView(
			HttpServletRequest paramHttpServletRequest,
			HttpServletResponse paramHttpServletResponse,
			Class<? extends HttpServlet> paramClass) throws ServletException,
			IOException;

	public abstract Prompter getPrompter(
			HttpServletRequest paramHttpServletRequest);

	public abstract boolean hasPrompts(
			HttpServletRequest paramHttpServletRequest,
			HttpServletResponse paramHttpServletResponse,
			PromptLevel paramPromptLevel);

	public abstract String getPrompt(
			HttpServletRequest paramHttpServletRequest,
			HttpServletResponse paramHttpServletResponse,
			PromptLevel paramPromptLevel);

	public abstract void prompt(HttpServletRequest paramHttpServletRequest,
			HttpServletResponse paramHttpServletResponse,
			PromptLevel paramPromptLevel, String paramString);

	public abstract void clearPrompts(
			HttpServletRequest paramHttpServletRequest,
			HttpServletResponse paramHttpServletResponse,
			PromptLevel paramPromptLevel);

	public abstract void clearAll(HttpServletRequest paramHttpServletRequest,
			HttpServletResponse paramHttpServletResponse);

	public abstract void initialize(ServletContext paramServletContext,
			Rewriter paramRewriter, Set<Class<? extends HttpServlet>> paramSet);

	public abstract String getViewFile(
			HttpServletRequest paramHttpServletRequest)
			throws ServletNotFoundException;

	public abstract void redirectLogin(
			HttpServletRequest paramHttpServletRequest,
			HttpServletResponse paramHttpServletResponse, String paramString)
			throws ServletException, IOException;

	public abstract String formatLogin(HttpServletRequest request,
			String loginURI) throws ServletException, IOException;
}