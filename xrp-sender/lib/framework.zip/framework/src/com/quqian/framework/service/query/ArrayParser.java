package com.quqian.framework.service.query;

import java.sql.ResultSet;
import java.sql.SQLException;

public abstract interface ArrayParser<T>
{
  public abstract T[] parse(ResultSet paramResultSet)
    throws SQLException;
}