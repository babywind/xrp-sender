package com.quqian.framework.http.session.authentication;

public class PasswordAuthentication extends VerifyCodeAuthentication
{
  private static final long serialVersionUID = 4450809801080671635L;
  protected String accountName;
  protected String password;

  public String getAccountName()
  {
    return accountName;
  }

  public void setAccountName(String accountName) {
    this.accountName = accountName;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }
}