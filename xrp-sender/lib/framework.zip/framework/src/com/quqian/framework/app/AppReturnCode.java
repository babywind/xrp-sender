package com.quqian.framework.app;

public class AppReturnCode {
	public static int SUCCESS = 0; // 成功
	public static int AUTHENTICATION = 1; // 没有权限
	public static int SERVICE = 2; // 服务器内部错误
	public static int PARAMETER = 3; // 缺少参数或参数值错误
}
