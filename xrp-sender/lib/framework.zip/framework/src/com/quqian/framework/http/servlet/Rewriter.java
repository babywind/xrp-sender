package com.quqian.framework.http.servlet;

import javax.servlet.http.HttpServlet;

public abstract interface Rewriter
{
  public abstract String getSuffix();

  public abstract String getViewSuffix();

  public abstract String getPathURI(String paramString, Class<? extends HttpServlet> paramClass)
    throws ServletNotFoundException;

  public abstract String getURI(String paramString, Class<? extends HttpServlet> paramClass)
    throws ServletNotFoundException;

  public abstract String getViewURI(String paramString, Class<? extends HttpServlet> paramClass)
    throws ServletNotFoundException;

  public abstract String getViewRoot();

  public abstract String getViewFileSuffix();

  public abstract boolean isAccepted(Class<? extends HttpServlet> paramClass);

  public abstract String getViewFilePath(Class<? extends HttpServlet> paramClass)
    throws ServletNotFoundException;
}