package com.quqian.framework.http.service;

import com.quqian.framework.http.entity.RightBean;
import com.quqian.framework.service.Service;

public abstract interface RightManage extends Service
{
  public abstract boolean hasRight(int paramInt, String paramString)
    throws Throwable;

  public abstract void setUserRights(int paramInt, String[] paramArrayOfString)
    throws Throwable;

  public abstract void setRoleRights(int paramInt, String[] paramArrayOfString)
    throws Throwable;

  public abstract RightBean[] getUserRights(int paramInt)
    throws Throwable;

  public abstract RightBean[] getRoleRights(int paramInt)
    throws Throwable;
}