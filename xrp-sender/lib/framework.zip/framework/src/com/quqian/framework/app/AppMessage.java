package com.quqian.framework.app;

public class AppMessage {
	public String cookieValue = "";// cookie值
	public boolean isAuthenticated = false; // 是否已注册的用户
	public int code = 0;// 结果代码
	public String msg = "成功";// 结果信息
	public Object rvalue = null;// 返回值
	public int totalpage = 0;
	public String isLogin="1";
	public String timestamp = "";//时间戳
	public String code_type= "";

	public AppMessage() {
	}
	
	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getCookieValue() {
		return cookieValue;
	}

	public void setCookieValue(String cookieValue) {
		this.cookieValue = cookieValue;
	}

	public AppMessage(boolean isAuthenticated, int code, String msg,String cookieValue) {
		this.cookieValue = cookieValue;
		this.isAuthenticated = isAuthenticated;
		this.code = code;
		this.msg = msg;
	}

	public boolean isAuthenticated() {
		return isAuthenticated;
	}

	public void setAuthenticated(boolean isAuthenticated) {
		this.isAuthenticated = isAuthenticated;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Object getRvalue() {
		return rvalue;
	}

	public void setRvalue(Object rvalue) {
		this.rvalue = rvalue;
	}

	public int getTotalpage() {
		return totalpage;
	}

	public void setTotalpage(int totalpage) {
		this.totalpage = totalpage;
	}

	public String getCode_type() {
		return code_type;
	}

	public void setCode_type(String code_type) {
		this.code_type = code_type;
	}

	public String getIsLogin() {
		return isLogin;
	}

	public void setIsLogin(String isLogin) {
		this.isLogin = isLogin;
	}
	
	

}
