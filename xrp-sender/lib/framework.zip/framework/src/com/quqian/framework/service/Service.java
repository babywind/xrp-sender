package com.quqian.framework.service;

public abstract interface Service
{
}