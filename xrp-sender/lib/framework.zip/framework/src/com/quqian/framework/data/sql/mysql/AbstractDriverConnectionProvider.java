package com.quqian.framework.data.sql.mysql;

import com.quqian.framework.data.sql.SQLConnection;
import com.quqian.framework.log.Logger;
import com.quqian.framework.resource.InitParameterProvider;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public abstract class AbstractDriverConnectionProvider extends AbstractMySQLConnectionProvider
{
  protected String driver;
  protected String url;
  protected Properties properties;

  public AbstractDriverConnectionProvider(InitParameterProvider parameterProvider, Logger logger)
  {
    super(parameterProvider, logger);
    properties = new Properties();
  }

  public SQLConnection getConnection() throws SQLException
  {
    try {
      Class.forName(driver);
    } catch (ClassNotFoundException e) {
      throw new SQLException(e);
    }
    return new ConnectionWrapper(properties == null ? DriverManager.getConnection(url) : DriverManager.getConnection(url, properties));
  }

  public void close()
  {
  }
}