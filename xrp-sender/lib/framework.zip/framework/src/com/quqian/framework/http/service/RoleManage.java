package com.quqian.framework.http.service;

import com.quqian.framework.http.entity.RoleBean;
import com.quqian.framework.service.Service;
import com.quqian.framework.service.query.Paging;
import com.quqian.framework.service.query.PagingResult;

import java.sql.Timestamp;

public abstract interface RoleManage extends Service {
	public abstract int add(String paramString1, String paramString2)
			throws Throwable;

	public abstract void delete(int paramInt) throws Throwable;

	public abstract void active(int paramInt) throws Throwable;

	public abstract void inActive(int paramInt) throws Throwable;

	public abstract RoleBean[] getRoles(int paramInt) throws Throwable;

	public abstract void setRoles(int paramInt, int... paramArrayOfInt)
			throws Throwable;

	public abstract RoleBean getRole(int paramInt) throws Throwable;

	public abstract PagingResult<RoleBean> search(RoleQuery paramRoleQuery,
			Paging paramPaging) throws Throwable;

	public static abstract interface RoleQuery {
		public abstract int getRoleId();

		public abstract String getName();

		public abstract String getDescription();

		public abstract int getCreaterId();

		public abstract Timestamp getCreateTimeStart();

		public abstract Timestamp getCreateTimeEnd();

		public abstract String getStatus();
	}
}