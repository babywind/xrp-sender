package com.quqian.framework.http.achieve.session;

import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.http.service.RightManage;
import com.quqian.framework.http.servlet.annotation.Right;
import com.quqian.framework.http.session.Session;
import com.quqian.framework.http.session.SessionManager;
import com.quqian.framework.http.session.VerifyCode;
import com.quqian.framework.http.session.VerifyCodeGenerator;
import com.quqian.framework.http.session.authentication.AccesssDeniedException;
import com.quqian.framework.http.session.authentication.AuthenticationException;
import com.quqian.framework.http.session.authentication.PasswordAuthentication;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.framework.service.ServiceProvider;
import com.quqian.framework.service.ServiceSession;

import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract class AbstractSessionManager extends SessionManager {
	protected static final VerifyCodeGenerator DEFAULT_VERIFY_CODE_GENERATOR = new VerifyCodeGenerator() {
		private final SecureRandom random = new SecureRandom();

		public VerifyCode newVerifyCode() {
			char[] value = new char[4];

			for (int i = 0; i < 4; i++) {
				value[i] = ((char) (random.nextInt(10) + 48));
			}

			final String displayValue = new String(value);

			return new VerifyCode() {
				public String getMatchValue() {
					return displayValue;
				}

				public String getDisplayValue() {
					return displayValue;
				}

				public String toString() {
					return displayValue;
				}
			};
		}

		public long getTTL() {
			return 600000L;
		}
	};

	public AbstractSessionManager(ResourceProvider resourceProvider) {
		super(resourceProvider);
	}

	/**
	 * 没有时间限制session
	 */
	public Session getSession(HttpServletRequest request, HttpServletResponse response) {
		return getSession(request, response, true);
	}

	public Session getSessionApp(HttpServletRequest request, HttpServletResponse response) {
		return getSessionApp(request, response, true);
	}

	public void initilize(Connection connection) throws Throwable {
		Statement stmt = connection.createStatement();
		Throwable localThrowable2 = null;
		try {
			stmt.addBatch(
					"CREATE TABLE IF NOT EXISTS _1020 (F01 int(10) unsigned NOT NULL AUTO_INCREMENT,F02 varchar(45) NOT NULL,F03 varchar(200) DEFAULT NULL,F04 datetime NOT NULL,F05 int(10) unsigned NOT NULL,F06 enum('QY','TY') NOT NULL,PRIMARY KEY (F01), UNIQUE KEY F02 (F02), KEY F06 (F06)) DEFAULT CHARSET=utf8");

			stmt.addBatch(
					"CREATE TABLE IF NOT EXISTS _1021 (F01 int(10) unsigned NOT NULL,F02 varchar(45) NOT NULL,PRIMARY KEY (F01,F02)) DEFAULT CHARSET=utf8");

			stmt.addBatch(
					"CREATE TABLE IF NOT EXISTS _1022 (F01 int(10) unsigned NOT NULL,F02 int(10) unsigned NOT NULL,PRIMARY KEY (F01,F02)) DEFAULT CHARSET=utf8");

			stmt.addBatch(
					"CREATE TABLE IF NOT EXISTS _1023 (F01 int(10) unsigned NOT NULL,F02 varchar(45) NOT NULL,PRIMARY KEY (F01,F02)) DEFAULT CHARSET=utf8");
			stmt.executeBatch();
		} catch (Throwable localThrowable1) {
			localThrowable2 = localThrowable1;
			throw localThrowable1;
		} finally {
			if (stmt != null)
				if (localThrowable2 != null)
					try {
						stmt.close();
					} catch (Throwable x2) {
						localThrowable2.addSuppressed(x2);
					}
				else
					stmt.close();
		}
	}

	protected abstract class AbstractSession implements Session {
		protected int accountId;

		protected AbstractSession() {
		}
		
		protected abstract void checkUserFundsError(String paramString) throws AuthenticationException;
			
		protected abstract void checkMaxErrorTimes(String paramString) throws AuthenticationException;

		protected abstract void markError(String paramString);

		public String getVerifyCode(String type) {
			return getVerifyCode(type, AbstractSessionManager.DEFAULT_VERIFY_CODE_GENERATOR);
		}

		public void tryAccessResource(String resourceId) throws AccesssDeniedException {
			if (isAccessableResource(resourceId)) {
				return;
			}
			throw new AccesssDeniedException(String.format("拒绝访问:%s.", new Object[] { resourceId }));
		}

		public boolean isAccessableResource(Class<?> resource) throws AccesssDeniedException {
			if (resource == null) {
				return true;
			}
			Right right = (Right) resource.getAnnotation(Right.class);
			if (right == null) {
				return true;
			}
			return isAccessableResource(right.id());
		}

		public boolean isAccessableResource(Right right) throws AccesssDeniedException {
			return right == null ? true : isAccessableResource(right.id());
		}

		public int authenticatePassword(PasswordAuthentication authentication) throws AuthenticationException {
			if (authentication == null) {
				throw new AuthenticationException("用户名或密码错误.");
			}
			authenticateVerifyCode(authentication);
			String accountName = authentication.getAccountName();
			String password = authentication.getPassword();
			if ((accountName == null) || (accountName.isEmpty()) || (password == null) || (password.isEmpty())) {
				throw new AuthenticationException("用户名或密码错误.");
			}
			checkMaxErrorTimes(accountName);
			try {
				ServiceSession serviceSession = ((ServiceProvider) resourceProvider.getResource(ServiceProvider.class))
						.createServiceSession(this);
				Throwable localThrowable2 = null;
				try {
					int accountId = resourceProvider.getSystemDefine().readAccountId(serviceSession, accountName,
							password);

					if (accountId <= 0) {
						markError(accountName);
					}
					return accountId;
				} catch (Throwable localThrowable1) {
					localThrowable2 = localThrowable1;
					throw localThrowable1;
				} finally {
					if (serviceSession != null)
						if (localThrowable2 != null)
							try {
								serviceSession.close();
							} catch (Throwable x2) {
								localThrowable2.addSuppressed(x2);
							}
						else
							serviceSession.close();
				}
			} catch (AuthenticationException e) {
				markError(accountName);
				throw e;
			} catch (Throwable e) {
				throw new AuthenticationException("鉴权服务器连接失败.", e);
			}
		}

		public int checkIn(HttpServletRequest request, HttpServletResponse response,
				PasswordAuthentication authentication) throws AuthenticationException {
			if (authentication == null) {
				throw new AuthenticationException("账号或密码错误");
			}
			authenticateVerifyCode(authentication);
			String accountName = authentication.getAccountName();
			String password = authentication.getPassword();
			if ((accountName == null) || (accountName.isEmpty()) || (password == null) || (password.isEmpty())) {
				throw new AuthenticationException("账号或密码错误");
			}
			//资金异常被锁定
			checkUserFundsError(accountName);
			//最大错误次数校验
			checkMaxErrorTimes(accountName);
			try {
				ServiceSession serviceSession = ((ServiceProvider) resourceProvider.getResource(ServiceProvider.class))
						.createServiceSession(this);
				Throwable localThrowable2 = null;
				try {
					SystemDefine systemDefine = resourceProvider.getSystemDefine();
					int accountId = systemDefine.readAccountId(serviceSession, accountName, password);

					if (accountId > 0)
						register(accountId);
					else {
						markError(accountName);
					}
					systemDefine.writeLog(request, response, serviceSession, authentication, accountId);

					return accountId;
				} catch (Throwable localThrowable1) {
					localThrowable2 = localThrowable1;
					throw localThrowable1;
				} finally {
					if (serviceSession != null)
						if (localThrowable2 != null)
							try {
								serviceSession.close();
							} catch (Throwable x2) {
								localThrowable2.addSuppressed(x2);
							}
						else
							serviceSession.close();
				}
			} catch (AuthenticationException e) {
				markError(accountName);
				throw e;
			} catch (Throwable e) {
				throw new AuthenticationException("鉴权失败", e);
			}
		}

		public int checkInApp(HttpServletRequest request, HttpServletResponse response,
				PasswordAuthentication authentication) throws AuthenticationException {
			if (authentication == null) {
				throw new AuthenticationException("账号或密码错误");
			}
			// authenticateVerifyCode(authentication);
			String accountName = authentication.getAccountName();
			String password = authentication.getPassword();
			if ((accountName == null) || (accountName.isEmpty()) || (password == null) || (password.isEmpty())) {
				throw new AuthenticationException("账号或密码错误.");
			}
			checkMaxErrorTimes(accountName);
			try {
				ServiceSession serviceSession = ((ServiceProvider) resourceProvider.getResource(ServiceProvider.class))
						.createServiceSession(this);
				Throwable localThrowable2 = null;
				try {
					SystemDefine systemDefine = resourceProvider.getSystemDefine();
					int accountId = systemDefine.readAccountId(serviceSession, accountName, password);

					if (accountId > 0)
						register(accountId);
					else {
						markError(accountName);
					}
					systemDefine.writeLog(request, response, serviceSession, authentication, accountId);

					return accountId;
				} catch (Throwable localThrowable1) {
					localThrowable2 = localThrowable1;
					throw localThrowable1;
				} finally {
					if (serviceSession != null)
						if (localThrowable2 != null)
							try {
								serviceSession.close();
							} catch (Throwable x2) {
								localThrowable2.addSuppressed(x2);
							}
						else
							serviceSession.close();
				}
			} catch (AuthenticationException e) {
				markError(accountName);
				throw e;
			} catch (Throwable e) {
				throw new AuthenticationException("鉴权失败", e);
			}
		}
		
		public int checkInPY(HttpServletRequest request, HttpServletResponse response,
				PasswordAuthentication authentication) throws AuthenticationException {
			if (authentication == null) {
				throw new AuthenticationException("账号不存在");
			}
//			这个值换做token
			String accountName = authentication.getAccountName();
			if ((accountName == null) || (accountName.isEmpty())) {
				throw new AuthenticationException("账号不存在");
			}
			try {
				ServiceSession serviceSession = ((ServiceProvider) resourceProvider.getResource(ServiceProvider.class))
						.createServiceSession(this);
				Throwable localThrowable2 = null;
				try {
					SystemDefine systemDefine = resourceProvider.getSystemDefine();
					int accountId =Integer.parseInt(authentication.getPassword());

					if (accountId > 0)
						register(accountId);
					systemDefine.writeLog(request, response, serviceSession, authentication, accountId);
					return accountId;
				} catch (Throwable localThrowable1) {
					localThrowable2 = localThrowable1;
					throw localThrowable1;
				} finally {
					if (serviceSession != null)
						if (localThrowable2 != null)
							try {
								serviceSession.close();
							} catch (Throwable x2) {
								localThrowable2.addSuppressed(x2);
							}
						else
							serviceSession.close();
				}
			} catch (AuthenticationException e) {
				throw new AuthenticationException("鉴权失败", e);
			} catch (Throwable e) {
				throw new AuthenticationException("鉴权失败", e);
			}
		}

		protected void register(int accountId) {
			this.accountId = accountId;
		}

		public boolean isAccessableResource(String resourceId) {
			if (accountId <= 0)
				return false;
			try {
				ServiceProvider serviceProvider = (ServiceProvider) resourceProvider.getResource(ServiceProvider.class);

				ServiceSession serviceSession = serviceProvider.createServiceSession(this);
				Throwable localThrowable2 = null;
				try {
					RightManage rightManage = (RightManage) serviceSession.getService(RightManage.class);

					return rightManage.hasRight(accountId, resourceId);
				} catch (Throwable localThrowable1) {
					localThrowable2 = localThrowable1;
					throw localThrowable1;
				} finally {
					if (serviceSession != null)
						if (localThrowable2 != null)
							try {
								serviceSession.close();
							} catch (Throwable x2) {
								localThrowable2.addSuppressed(x2);
							}
						else
							serviceSession.close();
				}
			} catch (Throwable throwable) {
				resourceProvider.log(throwable);
			}

			return false;
		}

		public int getAccountId() throws AuthenticationException {
			if (accountId <= 0) {
				throw new AuthenticationException();
			}
			return accountId;
		}

		public boolean isAuthenticated() {
			return accountId > 0;
		}
	}
}