package com.quqian.framework.http.achieve.session.cookie;

import java.util.Map;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.quqian.framework.http.achieve.session.AbstractSessionManager;
import com.quqian.framework.http.servlet.Controller;
import com.quqian.framework.http.session.Session;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.util.StringHelper;
import com.quqian.util.collection.LRUMap;

public abstract class AbstractCookieSessionManager extends
		AbstractSessionManager {
	private static final Map<String, String> USER_AGENT_DIGEST = new LRUMap<String, String>(
			100000);

	public AbstractCookieSessionManager(ResourceProvider resourceProvider) {
		super(resourceProvider);
	}

	protected String getTokenName() {
		return resourceProvider.getSystemDefine().getGUID();
	}
	
	public Session getSessionApp(HttpServletRequest request,
			HttpServletResponse response, boolean create) {
		String cookieValue = request.getParameter("cookieValue");
		String tokenName = getTokenName();
		Cookie token = null;
		Cookie[] cookies = request.getCookies();
		if ((cookies != null) && (cookies.length > 0)) {
			for (Cookie cookie : cookies) {
				if (tokenName.equals(cookie.getName())) {
					token = cookie;
					break;
				}
			}
		}
		
		if (token == null) {
			if (!create) {
				return null;
			}
			
			if(StringHelper.isEmpty(cookieValue)){
				cookieValue = newToken();
			}
			token = new Cookie(tokenName, cookieValue);
			token.setHttpOnly(true);
			token.setSecure(request.isSecure());
			token.setMaxAge(-1);
			token.setPath("/");
			response.addCookie(token);
		}else{
			if(!StringHelper.isEmpty(cookieValue)){
				token.setValue(cookieValue);
			}
		}

		Session session = newSession(token, request, response,getMaxIdleTimeApp());
		return session;
	}

	/**
	 * 无时间限制session
	 */
	public Session getSession(HttpServletRequest request,
			HttpServletResponse response, boolean create) {
		String tokenName = getTokenName();
		Cookie token = null;
		Cookie[] cookies = request.getCookies();
		if ((cookies != null) && (cookies.length > 0)) {
			for (Cookie cookie : cookies) {
				if (tokenName.equals(cookie.getName())) {
					token = cookie;
					break;
				}
			}
		}
		if (token == null) {
			if (!create) {
				return null;
			}
			token = new Cookie(tokenName, newToken());
			token.setHttpOnly(true);
			token.setSecure(request.isSecure());
			token.setMaxAge(-1);
			token.setPath("/");
			response.addCookie(token);
		}

		Session session = newSession(token, request, response);
		return session;
	}

	protected String newToken() {
		return UUID.randomUUID().toString();
	}

	protected long getMaxIdleTime() {
		return 7200000L;
	}
	
	protected long getMaxIdleTimeApp() {
		return 24*3600000L;
	}

	protected abstract Session newSession(Cookie paramCookie,
			HttpServletRequest paramHttpServletRequest,
			HttpServletResponse paramHttpServletResponse);
	
	protected abstract Session newSession(Cookie paramCookie,
			HttpServletRequest paramHttpServletRequest,
			HttpServletResponse paramHttpServletResponse,
			long maxIdleTime);

	public void close() {
	}

	protected abstract class AbstractCookieSession extends
			AbstractSessionManager.AbstractSession implements Session {
		protected final long creationTime;
		protected final Cookie cookie;
		protected String userAgent;
		protected String ip;
		protected String userAgentDigest;

		public AbstractCookieSession(Cookie cookie, HttpServletRequest request,
				HttpServletResponse response) {
			super();
			this.cookie = cookie;
			creationTime = System.currentTimeMillis();
			try {
				Controller controller = (Controller) resourceProvider
						.getResource(Controller.class);

				userAgent = controller.getRemoteAgent(request);
				ip = controller.getRemoteAddr(request);
				userAgentDigest = ((String) AbstractCookieSessionManager.USER_AGENT_DIGEST
						.get(this.cookie.getValue()));
				if (userAgentDigest == null) {
					if(StringHelper.isEmpty(userAgent)){
						userAgent = "quqianApp";
					}
					userAgentDigest = StringHelper.digest(this.cookie.getValue()+userAgent);
					AbstractCookieSessionManager.USER_AGENT_DIGEST.put(
							this.cookie.getValue(), userAgentDigest);
				}
				
			} catch (Throwable throwable) {
				resourceProvider.log(throwable);
			}
		}

		public String getToken() {
			return cookie.getValue();
		}

		public void invalidate(HttpServletRequest request,
				HttpServletResponse response) {
			cookie.setMaxAge(0);
			response.addCookie(cookie);
		}
	}
}