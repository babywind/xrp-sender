package com.quqian.framework.config;

import com.quqian.framework.config.entity.VariableBean;
import com.quqian.framework.resource.Resource;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.util.StringHelper;

import java.io.IOException;
import java.util.Map;

public abstract class ConfigureProvider extends Resource implements Envionment {
	public ConfigureProvider(ResourceProvider resourceProvider) {
		super(resourceProvider);
	}

	public final Class<? extends Resource> getIdentifiedType() {
		return ConfigureProvider.class;
	}

	public abstract void invalidProperty(String paramString);

	public String getProperty(VariableBean variableBean) {
		if (variableBean == null) {
			return null;
		}
		String value = getProperty(variableBean.getKey());
		if (StringHelper.isEmpty(value)) {
			value = variableBean.getValue();
		}
		return value;
	}

	public abstract String getProperty(String paramString);

	public abstract void setProperty(String paramString1, String paramString2);

	public abstract Envionment createEnvionment();

	public abstract Envionment createEnvionment(Envionment paramEnvionment);

	public abstract Envionment createEnvionment(Map<String, String> paramMap);

	public String get(String key) {
		return getProperty(key);
	}

	public void set(String key, String value) {
		setProperty(key, value);
	}

	public void format(Appendable out, VariableBean variable)
			throws IOException {
		if ((out == null) || (variable == null)) {
			return;
		}
		StringHelper.format(out, getProperty(variable.getKey()), this);
	}

	public void format(Appendable out, VariableBean variable,
			Envionment envionment) throws IOException {
		if ((out == null) || (variable == null)) {
			return;
		}
		StringHelper.format(out, getProperty(variable.getKey()), envionment);
	}

	public void format(Appendable out, String key) throws IOException {
		if ((out == null) || (StringHelper.isEmpty(key))) {
			return;
		}
		StringHelper.format(out, getProperty(key), this);
	}

	public void format(Appendable out, String key, Envionment envionment)
			throws IOException {
		if ((out == null) || (envionment == null)
				|| (StringHelper.isEmpty(key))) {
			return;
		}
		StringHelper.format(out, getProperty(key), envionment);
	}

	public String format(VariableBean variable) throws IOException {
		if (variable == null) {
			return null;
		}
		return StringHelper.format(getProperty(variable.getKey()), this);
	}

	public String format(VariableBean variable, Envionment envionment)
			throws IOException {
		if (variable == null) {
			return null;
		}
		return StringHelper.format(getProperty(variable.getKey()), envionment);
	}

	public String format(String key) throws IOException {
		if (StringHelper.isEmpty(key)) {
			return null;
		}
		return StringHelper.format(getProperty(key), this);
	}

	public String format(String key, Envionment envionment) throws IOException {
		if (StringHelper.isEmpty(key)) {
			return null;
		}
		return StringHelper.format(getProperty(key), envionment);
	}

	public void setArray(String key, Object value) {
	}

	public Object getArray(String key) {
		return null;
	}
}