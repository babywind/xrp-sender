package com.quqian.framework.http.session;

public abstract interface VerifyCodeGenerator
{
  public abstract long getTTL();

  public abstract VerifyCode newVerifyCode();
}