package com.quqian.framework.message.achieve.sms;

import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.data.sql.SQLConnectionProvider;
import com.quqian.framework.message.MessageProvider;
import com.quqian.framework.resource.ResourceNotFoundException;
import com.quqian.framework.service.AbstractService;
import com.quqian.framework.service.ServiceResource;

import java.sql.Connection;
import java.sql.SQLException;

public abstract class AbstractSmsService extends AbstractService
{
  public AbstractSmsService(ServiceResource serviceResource)
  {
    super(serviceResource);
  }

  protected SQLConnectionProvider getConnectionProvider() {
    SystemDefine systemDefine = serviceResource.getSystemDefine();
    return (SQLConnectionProvider)serviceResource.getDataConnectionProvider(SQLConnectionProvider.class, systemDefine.getDataProvider(MessageProvider.class));
  }

  protected Connection getConnection()
    throws ResourceNotFoundException, SQLException
  {
    SystemDefine systemDefine = serviceResource.getSystemDefine();
    return ((SQLConnectionProvider)serviceResource.getDataConnectionProvider(SQLConnectionProvider.class, systemDefine.getDataProvider(MessageProvider.class))).getConnection(systemDefine.getSchemaName(MessageProvider.class));
  }
}