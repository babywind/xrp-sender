package com.quqian.framework.log;

public abstract interface Logger
{
  public abstract void log(Throwable paramThrowable);

  public abstract void log(String paramString);
}