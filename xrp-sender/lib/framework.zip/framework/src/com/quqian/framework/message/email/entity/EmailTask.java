package com.quqian.framework.message.email.entity;

public class EmailTask
{
  public long id;
  public int type;
  public String subject;
  public String content;
  public String[] addresses;
}