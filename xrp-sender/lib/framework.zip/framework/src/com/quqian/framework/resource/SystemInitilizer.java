package com.quqian.framework.resource;

import java.sql.Connection;

public abstract interface SystemInitilizer
{
  public abstract void initialize(Connection paramConnection)
    throws Throwable;
}