package com.quqian.framework.config.entity;

public abstract interface VariableBean
{
  public abstract String getType();

  public abstract String getKey();

  public abstract String getValue();

  public abstract String getDescription();
}