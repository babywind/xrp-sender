package com.quqian.framework.service;

import com.quqian.framework.http.session.Session;
import com.quqian.framework.resource.Prompter;
import com.quqian.framework.resource.Resource;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.framework.service.exception.ServiceNotFoundException;

import java.util.Set;

public abstract class ServiceProvider extends Resource
  implements AutoCloseable
{
  public ServiceProvider(ResourceProvider resourceProvider)
  {
    super(resourceProvider);
  }

  public abstract ServiceSession createServiceSession(Session paramSession);

  public abstract ServiceSession createServiceSession(Session paramSession, Prompter paramPrompter);

  public abstract ServiceSession createServiceSession();

  public abstract void registerServiceFactory(ServiceFactory<? extends Service> paramServiceFactory);

  public abstract void registerServiceFactory(Class<? extends ServiceFactory<?>> paramClass);

  public abstract void registerServiceFactories(Set<Class<? extends ServiceFactory<?>>> paramSet);

  public abstract void unRegisterServiceFactory(ServiceFactory<? extends Service> paramServiceFactory);

  public abstract <S extends Service> ServiceFactory<S> getServiceFactory(Class<S> paramClass)
    throws ServiceNotFoundException;

  public final Class<? extends Resource> getIdentifiedType()
  {
    return ServiceProvider.class;
  }
}