package com.quqian.framework.resource.achieve;

import com.quqian.framework.resource.InitParameterProvider;
import com.quqian.util.StringHelper;

import java.util.Enumeration;
import java.util.Hashtable;

public class ArgumentInitParameterProvider
  implements InitParameterProvider
{
  protected Hashtable<String, String> parameters = new Hashtable();

  public ArgumentInitParameterProvider(String[] arguments) {
    if ((arguments == null) || (arguments.length == 0)) {
      return;
    }
    boolean readKey = true;
    String key = null;
    for (String argument : arguments)
      if (!StringHelper.isEmpty(argument))
      {
        argument = argument.trim();
        if (readKey) {
          if (argument.startsWith("--"))
            key = argument.substring(2);
          else if (argument.startsWith("-"))
            key = argument.substring(1);
          else {
            key = argument;
          }
          readKey = false;
        } else {
          parameters.put(key, argument);
          readKey = true;
        }
      }
  }

  public String getInitParameter(String name)
  {
    return (String)parameters.get(name);
  }

  public Enumeration<String> getInitParameterNames()
  {
    return parameters.keys();
  }
}