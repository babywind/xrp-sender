package com.quqian.framework.config.achieve.service;

import com.quqian.framework.config.ConfigureProvider;
import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.data.sql.SQLConnectionProvider;
import com.quqian.framework.resource.ResourceNotFoundException;
import com.quqian.framework.service.AbstractService;
import com.quqian.framework.service.ServiceResource;

import java.sql.Connection;
import java.sql.SQLException;

public abstract class AbstractConfigService extends AbstractService {
	public AbstractConfigService(ServiceResource serviceResource) {
		super(serviceResource);
	}

	protected SQLConnectionProvider getConnectionProvider() {
		SystemDefine systemDefine = serviceResource.getSystemDefine();
		return (SQLConnectionProvider) serviceResource
				.getDataConnectionProvider(SQLConnectionProvider.class,
						systemDefine.getDataProvider(ConfigureProvider.class));
	}

	protected Connection getConnection() throws ResourceNotFoundException,
			SQLException {
		SystemDefine systemDefine = serviceResource.getSystemDefine();
		return ((SQLConnectionProvider) serviceResource
				.getDataConnectionProvider(SQLConnectionProvider.class,
						systemDefine.getDataProvider(ConfigureProvider.class)))
				.getConnection(systemDefine
						.getSchemaName(ConfigureProvider.class));
	}
}