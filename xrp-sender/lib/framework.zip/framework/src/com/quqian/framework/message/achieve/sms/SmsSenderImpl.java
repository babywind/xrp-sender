package com.quqian.framework.message.achieve.sms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

import com.quqian.framework.message.sms.SmsSender;
import com.quqian.framework.service.ServiceFactory;
import com.quqian.framework.service.ServiceResource;
import com.quqian.util.StringHelper;

public class SmsSenderImpl extends AbstractSmsService implements SmsSender {
	public SmsSenderImpl(ServiceResource serviceResource) {
		super(serviceResource);
	}

	private void send1(int type, String message, String[] receivers)
			throws Throwable {

		if ((StringHelper.isEmpty(message)) || (receivers == null)
				|| (receivers.length <= 0)) {
			return;
		}
		try (Connection connection = getConnection()) {
			long msgId = 0L;
			try (PreparedStatement ps = connection.prepareStatement(
					"INSERT INTO _1040(F02,F03,F04,F05) values(?,?,?,?)", 1)) {

				ps.setInt(1, type);
				ps.setString(2, message);
				ps.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
				ps.setString(4, "W");
				ps.execute();
				try (ResultSet resultSet = ps.getGeneratedKeys()) {
					if (resultSet.next())
						msgId = resultSet.getLong(1);
				}
			}

			if (msgId > 0L) {
				try (PreparedStatement ps = connection
						.prepareStatement("INSERT INTO _1041(F01,F02) VALUES(?,?)")) {
					for (String receiver : receivers) {
						ps.setLong(1, msgId);
						ps.setString(2, receiver);
						ps.addBatch();
					}
					ps.executeBatch();
				}
			}
		}
	}

	public void send(String channel, int tempId, String msg, String params,
			String... receivers) throws Throwable {
		if ("1".equals(channel)) {// 通道1：移动梦网
			send1(0, msg, receivers);
		} else if ("2".equals(channel)) {// 通道2：云之讯
			send2(tempId, params, receivers);
		}
	}

	private void send2(int tempId, String params, String[] receivers)
			throws Throwable {
		if ((receivers == null) || (receivers.length <= 0)) {
			return;
		}

		String message = params;

		try (Connection connection = getConnection()) {
			long msgId = 0L;
			try (PreparedStatement ps = connection.prepareStatement(
					"INSERT INTO _1040(F02,F03,F04,F05) values(?,?,?,?)", 1)) {

				ps.setInt(1, tempId);
				ps.setString(2, message);
				ps.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
				ps.setString(4, "W");
				ps.execute();
				try (ResultSet resultSet = ps.getGeneratedKeys()) {
					if (resultSet.next())
						msgId = resultSet.getLong(1);
				}
			}

			if (msgId > 0L) {
				try (PreparedStatement ps = connection
						.prepareStatement("INSERT INTO _1041(F01,F02) VALUES(?,?)")) {
					for (String receiver : receivers) {
						ps.setLong(1, msgId);
						ps.setString(2, receiver);
						ps.addBatch();
					}
					ps.executeBatch();
				}
			}
		}
	}

	public static void main(String[] args) {

	}

	public static class SenderFactory implements ServiceFactory<SmsSender> {
		public SmsSender newInstance(ServiceResource serviceResource) {
			return new SmsSenderImpl(serviceResource);
		}
	}
}