package com.quqian.framework.data.sql.mysql;

import java.beans.PropertyVetoException;
import java.sql.SQLException;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.quqian.framework.data.sql.SQLConnection;
import com.quqian.framework.log.Logger;
import com.quqian.framework.resource.InitParameterProvider;
import com.quqian.util.StringHelper;
import com.quqian.util.parser.IntegerParser;

public abstract class AbstractPooledConnectionProvider extends
		AbstractMySQLConnectionProvider {
	private ComboPooledDataSource dataSource;

	public AbstractPooledConnectionProvider(
			InitParameterProvider parameterProvider, Logger logger) {
		super(parameterProvider, logger);
		dataSource = new ComboPooledDataSource();
		setUser();
		setPassword();
		setDriverClass();
		setJdbcUrl();
		setPreferredTestQuery();
		setAcquireIncrement();
		setMinPoolSize();
		setMaxPoolSize();
		setMaxIdleTime();
		setIdleConnectionTestPeriod();
		setNumHelperThreads();
		setMaxStatementsPerConnection();
	}

	private void setUser() {
		String user = parameterProvider.getInitParameter("user");
		if (!StringHelper.isEmpty(user))
			dataSource.setUser(user);
	}

	private void setPassword() {
		String password = parameterProvider.getInitParameter("password");
		if (!StringHelper.isEmpty(password))
			dataSource.setPassword(password);
	}

	private void setDriverClass() {
		String driverClassName = parameterProvider
				.getInitParameter("driverClassName");
		try {
			if (StringHelper.isEmpty(driverClassName))
				dataSource.setDriverClass("com.mysql.jdbc.Driver");
			else
				dataSource.setDriverClass(driverClassName);
		} catch (PropertyVetoException e) {
			logger.log(e);
		}
	}

	private void setJdbcUrl() {
		String jdbcUrl = parameterProvider.getInitParameter("jdbcUrl");
		if (!StringHelper.isEmpty(jdbcUrl))
			dataSource.setJdbcUrl(jdbcUrl);
	}

	private void setPreferredTestQuery() {
		String preferredTestQuery = parameterProvider
				.getInitParameter("preferredTestQuery");

		if (StringHelper.isEmpty(preferredTestQuery))
			dataSource.setPreferredTestQuery("SELECT 1 FROM DUAL");
		else
			dataSource.setPreferredTestQuery(preferredTestQuery);
	}

	private void setAcquireIncrement() {
		int acquireIncrement = IntegerParser.parse(parameterProvider
				.getInitParameter("acquireIncrement"));

		if (acquireIncrement > 0)
			dataSource.setAcquireIncrement(acquireIncrement);
	}

	private void setMinPoolSize() {
		int minPoolSize = IntegerParser.parse(parameterProvider
				.getInitParameter("minPoolSize"));

		if (minPoolSize > 0)
			dataSource.setMinPoolSize(minPoolSize);
	}

	private void setMaxPoolSize() {
		int maxPoolSize = IntegerParser.parse(parameterProvider
				.getInitParameter("maxPoolSize"));

		if (maxPoolSize > 0)
			dataSource.setMaxPoolSize(maxPoolSize);
	}

	private void setMaxIdleTime() {
		int maxIdleTime = IntegerParser.parse(parameterProvider
				.getInitParameter("maxIdleTime"));

		if (maxIdleTime > 0)
			dataSource.setMaxPoolSize(maxIdleTime);
	}

	private void setIdleConnectionTestPeriod() {
		int idleConnectionTestPeriod = IntegerParser.parse(parameterProvider
				.getInitParameter("idleConnectionTestPeriod"));

		if (idleConnectionTestPeriod > 0)
			dataSource.setIdleConnectionTestPeriod(idleConnectionTestPeriod);
	}

	private void setNumHelperThreads() {
		int numHelperThreads = IntegerParser.parse(parameterProvider
				.getInitParameter("numHelperThreads"));

		if (numHelperThreads > 0)
			dataSource.setNumHelperThreads(numHelperThreads);
	}

	private void setMaxStatementsPerConnection() {
		int maxStatementsPerConnection = IntegerParser.parse(parameterProvider
				.getInitParameter("maxStatementsPerConnection"));

		if (maxStatementsPerConnection > 0)
			dataSource
					.setMaxStatementsPerConnection(maxStatementsPerConnection);
	}

	public SQLConnection getConnection() throws SQLException {
		return new ConnectionWrapper(dataSource.getConnection());
	}

	public void close() {
		dataSource.close();
	}
}