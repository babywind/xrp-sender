package com.quqian.framework.http.upload;

import com.quqian.framework.config.ConfigureProvider;
import com.quqian.framework.config.Envionment;
import com.quqian.framework.resource.Resource;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.util.StringHelper;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract class FileStore extends Resource implements Envionment {
	private File home;
	private String uploadURI = null;

	public FileStore(ResourceProvider resourceProvider) {
		super(resourceProvider);
	}

	public final Class<? extends Resource> getIdentifiedType() {
		return FileStore.class;
	}

	public abstract String newCode(int paramInt, String paramString)
			throws Throwable;

	public abstract FileInformation getFileInformation(String paramString);

	public String get(String key) {
		if (StringHelper.isEmpty(key)) {
			return null;
		}
		FileInformation fileInformation = getFileInformation(key);
		if (fileInformation == null) {
			return ((ConfigureProvider) resourceProvider
					.getResource(ConfigureProvider.class)).getProperty(key);
		}

		return getURL(fileInformation);
	}

	public void set(String key, String value) {
	}

	public Object getArray(String key) {
		return null;
	}

	public void setArray(String key, Object value) {
	}

	public String getURL(String fileCode) {
		return getURL(getFileInformation(fileCode));
	}

	public abstract String getURL(FileInformation paramFileInformation);

	public abstract String[] upload(int paramInt,
			UploadFile... paramArrayOfUploadFile) throws Throwable;

	public abstract void write(FileInformation paramFileInformation,
			InputStream paramInputStream) throws IOException;

	public abstract void read(FileInformation paramFileInformation,
			OutputStream paramOutputStream) throws IOException;

	public abstract String encode(String paramString);

	public synchronized File getHome() {
		if (home == null) {
			String stringHome = resourceProvider
					.getInitParameter("fileStore.home");

			if (StringHelper.isEmpty(stringHome)) {
				home = new File(System.getProperty("user.home"), "fileStore");
			} else {
				File file = new File(stringHome);
				if (file.isAbsolute()) {
					home = file;
				} else {
					String contextHome = resourceProvider.getHome();
					home = new File(contextHome, stringHome);
				}
			}
			home.mkdirs();
		}
		return home;
	}

	public synchronized String getUploadURI() {
		if (uploadURI == null) {
			String value = resourceProvider
					.getInitParameter("fileStore.uploadURI");

			if (StringHelper.isEmpty(value))
				uploadURI = "/fileStore";
			else if (value.charAt(0) != '/')
				uploadURI = ('/' + value);
			else {
				uploadURI = value;
			}
		}
		return uploadURI;
	}
}