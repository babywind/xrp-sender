package com.quqian.framework.resource.cycle;

import com.quqian.framework.resource.ResourceProvider;

public abstract interface Shutdown
{
  public abstract void onShutdown(ResourceProvider paramResourceProvider);
}