package com.quqian.framework.resource;

import java.sql.Connection;

public abstract class Resource
  implements AutoCloseable
{
  protected final ResourceProvider resourceProvider;

  public Resource(ResourceProvider resourceProvider)
  {
    this.resourceProvider = resourceProvider;
  }

  public abstract Class<? extends Resource> getIdentifiedType();

  public abstract void initilize(Connection paramConnection)
    throws Throwable;

  public void close()
    throws Exception
  {
  }
}