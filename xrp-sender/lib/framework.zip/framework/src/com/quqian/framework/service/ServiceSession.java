package com.quqian.framework.service;

import com.quqian.framework.http.servlet.Controller;
import com.quqian.framework.http.session.Session;
import com.quqian.framework.resource.Prompter;
import com.quqian.framework.resource.ResourceInvalidatedException;
import com.quqian.framework.resource.ResourceNotFoundException;
import com.quqian.framework.service.exception.ServiceNotFoundException;

public abstract interface ServiceSession extends AutoCloseable, Prompter
{
  public abstract Session getSession();

  public abstract <S extends Service> S getService(Class<S> paramClass)
    throws ServiceNotFoundException, ResourceInvalidatedException;

  public abstract void openTransactions()
    throws Throwable;

  public abstract void openTransactions(int paramInt)
    throws Throwable;

  public abstract void commit()
    throws Throwable;

  public abstract void rollback()
    throws Throwable;

  public abstract boolean isTransactions()
    throws Throwable;

  public abstract void close();

  public abstract Controller getController()
    throws ResourceNotFoundException;
}