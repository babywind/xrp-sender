package com.quqian.framework.message.achieve.sms;

import com.quqian.framework.message.sms.Extracter;
import com.quqian.framework.message.sms.entity.SmsTask;
import com.quqian.framework.service.ServiceFactory;
import com.quqian.framework.service.ServiceResource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SmsExtracterImpl extends AbstractSmsService implements Extracter {
	public SmsExtracterImpl(ServiceResource serviceResource) {
		super(serviceResource);
	}

	public SmsTask[] extract(int maxCount, int expiresMinutes) throws Throwable {
		if (maxCount <= 0) {
			return null;
		}
		if (expiresMinutes <= 0) {
			expiresMinutes = 15;
		}
		List<SmsTask> sendTasks = null;
		try (Connection connection = getConnection()) {
			try (PreparedStatement ps = connection
					.prepareStatement("SELECT F01,F02,F03,F07 FROM _1040 WHERE F05=? ORDER BY F04 ASC LIMIT 0,?")) {
				ps.setString(1, "W");
				ps.setInt(2, maxCount);
				try (ResultSet resultSet = ps.executeQuery()) {
					while (resultSet.next()) {
						if (sendTasks == null) {
							sendTasks = new ArrayList<SmsTask>();
						}
						SmsTask sendTask = new SmsTask();
						sendTask.id = resultSet.getLong(1);
						sendTask.type = resultSet.getInt(2);
						sendTask.content = resultSet.getString(3);
						sendTask.jlid = resultSet.getInt(4);
						sendTasks.add(sendTask);
					}
				}
			}

			if (sendTasks == null) {
				return null;
			}
			try (PreparedStatement ps = connection
					.prepareStatement("UPDATE _1040 SET F05=?,F06=? WHERE F01=?")) {
				long l = System.currentTimeMillis();
				for (Iterator<SmsTask> i$ = sendTasks.iterator(); i$.hasNext();) {
					SmsTask sendTask = (SmsTask) i$.next();
					if (sendTask != null) {
						ps.setString(1, "Z");
						ps.setTimestamp(2, new Timestamp(l + expiresMinutes
								* 60 * 1000));
						ps.setLong(3, ((SmsTask) sendTask).id);
						ps.addBatch();
					}
				}
				ps.executeBatch();
			}

			for (SmsTask sendTask : sendTasks)
				if (sendTask != null) {
					try (PreparedStatement ps = connection
							.prepareStatement("SELECT F02 FROM _1041 WHERE F01=?")) {
						ps.setLong(1, sendTask.id);
						try (ResultSet resultSet = ps.executeQuery()) {
							List<String> recivers = null;
							while (resultSet.next()) {
								if (recivers == null) {
									recivers = new ArrayList<String>();
								}
								recivers.add(resultSet.getString(1));
							}
							sendTask.receivers = (recivers == null ? null
									: (String[]) recivers
											.toArray(new String[recivers.size()]));
						}
					}
				}
		}

		return sendTasks == null ? null : (SmsTask[]) sendTasks
				.toArray(new SmsTask[sendTasks.size()]);
	}

	public void mark(long id, boolean success, String extra) throws Throwable {
		if (id <= 0L) {
			return;
		}
		try (Connection connection = getConnection()) {
			try (PreparedStatement ps = connection
					.prepareStatement("INSERT INTO _1042(F01,F02,F03,F04,F05,F06) SELECT F01,F02,F03,F04,?,? FROM _1040 WHERE F01=?")) {
				if (success)
					ps.setString(1, "YES");
				else {
					ps.setString(1, "NO");
				}
				ps.setString(2, extra);
				ps.setLong(3, id);
				ps.execute();
			}
			try (PreparedStatement ps = connection
					.prepareStatement("DELETE FROM _1040 WHERE F01=?")) {
				ps.setLong(1, id);
				ps.execute();
			}
		}

	}

	public static class SmsExtracterFactory implements
			ServiceFactory<Extracter> {
		public Extracter newInstance(ServiceResource serviceResource) {
			return new SmsExtracterImpl(serviceResource);
		}
	}
}