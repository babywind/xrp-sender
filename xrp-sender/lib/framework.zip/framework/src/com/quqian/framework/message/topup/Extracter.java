package com.quqian.framework.message.topup;

import com.quqian.framework.message.topup.entity.TopupTask;
import com.quqian.framework.service.Service;

public abstract interface Extracter extends Service {
	public abstract TopupTask[] extract(int paramInt1, int paramInt2)
			throws Throwable;

	public abstract void mark(long paramLong, boolean paramBoolean,
			String paramString, String no) throws Throwable;

	public abstract String getNo(String agent_id) throws Throwable;
}
