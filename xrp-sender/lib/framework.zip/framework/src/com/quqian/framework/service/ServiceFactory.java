package com.quqian.framework.service;

public abstract interface ServiceFactory<S extends Service>
{
  public abstract S newInstance(ServiceResource paramServiceResource);
}