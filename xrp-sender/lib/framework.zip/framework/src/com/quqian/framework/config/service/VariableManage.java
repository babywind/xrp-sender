package com.quqian.framework.config.service;

import com.quqian.framework.config.entity.VariableBean;
import com.quqian.framework.service.Service;
import com.quqian.framework.service.query.Paging;
import com.quqian.framework.service.query.PagingResult;

public abstract interface VariableManage extends Service
{
  public abstract String getProperty(String paramString)
    throws Throwable;

  public abstract void setProperty(String paramString1, String paramString2)
    throws Throwable;

  public abstract PagingResult<VariableBean> search(VariableQuery paramVariableQuery, Paging paramPaging)
    throws Throwable;

  public abstract VariableBean get(String paramString)
    throws Throwable;

  public abstract void synchronize()
    throws Throwable;

  public abstract void reset()
    throws Throwable;

  public static abstract interface VariableQuery
  {
    public abstract String getKey();

    public abstract String getValue();

    public abstract String getType();

    public abstract String getDescription();
  }
}