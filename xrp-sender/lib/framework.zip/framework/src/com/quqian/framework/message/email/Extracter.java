package com.quqian.framework.message.email;

import com.quqian.framework.message.email.entity.EmailTask;
import com.quqian.framework.service.Service;

public abstract interface Extracter extends Service
{
  public abstract EmailTask[] extract(int paramInt1, int paramInt2)
    throws Throwable;

  public abstract void mark(long paramLong)
    throws Throwable;
}