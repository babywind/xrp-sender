package com.quqian.framework.config.achieve;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

import com.quqian.framework.config.ConfigureProvider;
import com.quqian.framework.config.Envionment;
import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.data.sql.SQLConnectionProvider;
import com.quqian.framework.resource.ResourceNotFoundException;
import com.quqian.framework.resource.ResourceProvider;
import com.quqian.util.StringHelper;

public class DefaultConfigureProvider extends ConfigureProvider {
	private final Map<String, String> CACHE = new WeakHashMap<String, String>();
	private InetSocketAddress groupAddress;
	private ConfigureMonitor monitor = null;
	private transient boolean notClose = true;

	public DefaultConfigureProvider(ResourceProvider resourceProvider) {
		super(resourceProvider);
		try {
			groupAddress = new InetSocketAddress(
					InetAddress.getByName("225.1.2.3"), 7788);
			monitor = new ConfigureMonitor();
			monitor.start();
		} catch (UnknownHostException e) {
			groupAddress = null;
		}
	}

	public void close() throws Exception {
		if (notClose) {
			notClose = false;
			monitor.interrupt();
			monitor = null;
		}
		super.close();
	}

	public void invalidProperty(String key) {
		if ((groupAddress == null) || (StringHelper.isEmpty(key)))
			return;
		try {
			byte[] buf = key.getBytes();
			DatagramPacket packet = new DatagramPacket(buf, buf.length,
					groupAddress);

			MulticastSocket socket = new MulticastSocket(groupAddress.getPort());
			Throwable localThrowable2 = null;
			try {
				socket.joinGroup(groupAddress.getAddress());
				socket.send(packet);
				socket.leaveGroup(groupAddress.getAddress());
			} catch (Throwable localThrowable1) {
				localThrowable2 = localThrowable1;
				throw localThrowable1;
			} finally {
				if (socket != null)
					if (localThrowable2 != null)
						try {
							socket.close();
						} catch (Throwable x2) {
							localThrowable2.addSuppressed(x2);
						}
					else
						socket.close();
			}
		} catch (Throwable throwable) {
			resourceProvider.log(throwable);
		}
	}

	private Connection getConnection() throws ResourceNotFoundException,
			SQLException {
		SystemDefine systemDefine = resourceProvider.getSystemDefine();
		return ((SQLConnectionProvider) resourceProvider
				.getDataConnectionProvider(SQLConnectionProvider.class,
						systemDefine.getDataProvider(ConfigureProvider.class)))
				.getConnection(systemDefine
						.getSchemaName(ConfigureProvider.class));
	}

	void preload() {
		try {
			Connection connection = getConnection();
			Throwable localThrowable4 = null;
			try {
				PreparedStatement pstmt = connection
						.prepareStatement("SELECT F01, F02 FROM _1010");

				Throwable localThrowable5 = null;
				try {
					ResultSet resultSet = pstmt.executeQuery();

					Throwable localThrowable6 = null;
					try {
						while (resultSet.next())
							CACHE.put(resultSet.getString(1),
									resultSet.getString(2));
					} catch (Throwable localThrowable1) {
						localThrowable6 = localThrowable1;
						throw localThrowable1;
					} finally {
					}
				} catch (Throwable localThrowable2) {
					localThrowable5 = localThrowable2;
					throw localThrowable2;
				} finally {
				}
			} catch (Throwable localThrowable3) {
				localThrowable4 = localThrowable3;
				throw localThrowable3;
			} finally {
				if (connection != null)
					if (localThrowable4 != null)
						try {
							connection.close();
						} catch (Throwable x2) {
							localThrowable4.addSuppressed(x2);
						}
					else
						connection.close();
			}
		} catch (Throwable e) {
			resourceProvider.log(e);
		}
	}

	public String getProperty(String key) {
		if (StringHelper.isEmpty(key)) {
			return null;
		}
		if (CACHE.containsKey(key)) {
			return (String) CACHE.get(key);
		}
		String value = null;
		try {
			Connection connection = getConnection();
			Throwable localThrowable4 = null;
			try {
				PreparedStatement pstmt = connection
						.prepareStatement("SELECT F02 FROM _1010 WHERE F01 = ?");

				Throwable localThrowable5 = null;
				try {
					pstmt.setString(1, key);
					ResultSet resultSet = pstmt.executeQuery();
					Throwable localThrowable6 = null;
					try {
						if (resultSet.next())
							value = resultSet.getString(1);
					} catch (Throwable localThrowable1) {
						localThrowable6 = localThrowable1;
						throw localThrowable1;
					} finally {
					}
				} catch (Throwable localThrowable2) {
					localThrowable5 = localThrowable2;
					throw localThrowable2;
				} finally {
				}
			} catch (Throwable localThrowable3) {
				localThrowable4 = localThrowable3;
				throw localThrowable3;
			} finally {
				if (connection != null)
					if (localThrowable4 != null)
						try {
							connection.close();
						} catch (Throwable x2) {
							localThrowable4.addSuppressed(x2);
						}
					else
						connection.close();
			}
		} catch (Throwable e) {
			resourceProvider.log(e);
		}

		if (!StringHelper.isEmpty(value)) {
			CACHE.put(key, value);
		}
		return value;
	}

	public void setProperty(String key, String value) {
		if ((StringHelper.isEmpty(key)) || (StringHelper.isEmpty(value)))
			return;
		try {
			Connection connection = getConnection();
			Throwable localThrowable3 = null;
			try {
				PreparedStatement pstmt = connection
						.prepareStatement("UPDATE _1010 SET F02 = ? WHERE F01 = ?");

				Throwable localThrowable4 = null;
				try {
					pstmt.setString(1, value);
					pstmt.setString(2, key);
					pstmt.executeUpdate();
					invalidProperty(key);
				} catch (Throwable localThrowable1) {
					localThrowable4 = localThrowable1;
					throw localThrowable1;
				} finally {
				}
			} catch (Throwable localThrowable2) {
				localThrowable3 = localThrowable2;
				throw localThrowable2;
			} finally {
				if (connection != null)
					if (localThrowable3 != null)
						try {
							connection.close();
						} catch (Throwable x2) {
							localThrowable3.addSuppressed(x2);
						}
					else
						connection.close();
			}
		} catch (Throwable e) {
			resourceProvider.log(e);
		}
	}

	public Envionment createEnvionment() {
		return new Envionment() {
			Map<String, String> local = new HashMap();
			Map<String, Object> arrays = null;

			public void set(String key, String value) {
				if (StringHelper.isEmpty(key)) {
					return;
				}
				local.put(key, value);
			}

			public String get(String key) {
				if (local.containsKey(key)) {
					return (String) local.get(key);
				}
				return getProperty(key);
			}

			public Object getArray(String key) {
				return arrays == null ? DefaultConfigureProvider.this
						.getArray(key) : arrays.get(key);
			}

			public void setArray(String key, Object value) {
				if (StringHelper.isEmpty(key)) {
					return;
				}
				if (arrays == null) {
					arrays = new HashMap();
				}
				arrays.put(key, value);
			}
		};
	}

	public Envionment createEnvionment(final Envionment envionment) {
		return new Envionment() {
			Map<String, String> local = new HashMap();
			Map<String, Object> arrays = null;

			public void set(String key, String value) {
				if (StringHelper.isEmpty(key)) {
					return;
				}
				local.put(key, value);
			}

			public String get(String key) {
				if (local.containsKey(key)) {
					return (String) local.get(key);
				}
				return envionment == null ? getProperty(key) : envionment
						.get(key);
			}

			public Object getArray(String key) {
				return arrays == null ? envionment.getArray(key) : arrays
						.get(key);
			}

			public void setArray(String key, Object value) {
				if (StringHelper.isEmpty(key)) {
					return;
				}
				if (arrays == null) {
					arrays = new HashMap();
				}
				arrays.put(key, value);
			}
		};
	}

	public Envionment createEnvionment(final Map<String, String> values) {
		return new Envionment() {
			Map<String, String> local;
			Map<String, Object> arrays;

			public void set(String key, String value) {
				if (StringHelper.isEmpty(key)) {
					return;
				}
				local.put(key, value);
			}

			public String get(String key) {
				if (local.containsKey(key)) {
					return (String) local.get(key);
				}
				return getProperty(key);
			}

			public Object getArray(String key) {
				return arrays == null ? DefaultConfigureProvider.this
						.getArray(key) : arrays.get(key);
			}

			public void setArray(String key, Object value) {
				if (StringHelper.isEmpty(key)) {
					return;
				}
				if (arrays == null) {
					arrays = new HashMap();
				}
				arrays.put(key, value);
			}
		};
	}

	public void initilize(Connection connection) throws Throwable {
		Statement stmt = connection.createStatement();
		Throwable localThrowable2 = null;
		try {
			stmt.execute("CREATE TABLE IF NOT EXISTS _1010 (F01 varchar(100) NOT NULL,F02 text NOT NULL,F03 varchar(100) NOT NULL,F04 text DEFAULT NULL,PRIMARY KEY (F01), KEY F03 (F03) USING BTREE) DEFAULT CHARSET=utf8");
			stmt.executeBatch();
		} catch (Throwable localThrowable1) {
			localThrowable2 = localThrowable1;
			throw localThrowable1;
		} finally {
			if (stmt != null)
				if (localThrowable2 != null)
					try {
						stmt.close();
					} catch (Throwable x2) {
						localThrowable2.addSuppressed(x2);
					}
				else
					stmt.close();
		}
	}

	private class ConfigureMonitor extends Thread {
		private ConfigureMonitor() {
		}

		public void run() {
			try {
				MulticastSocket socket = new MulticastSocket(
						groupAddress.getPort());
				Throwable localThrowable2 = null;
				try {
					socket.joinGroup(groupAddress.getAddress());
					DatagramPacket packet = new DatagramPacket(new byte[1024],
							1024);
					while (notClose) {
						try {
							socket.receive(packet);
							byte[] buf = packet.getData();
							String key = new String(buf, packet.getOffset(),
									packet.getLength());

							CACHE.remove(key);
							resourceProvider.log(String.format(
									"上下文: %s 收到来自: %s 通知,配置参数  %s 已失效.",
									new Object[] {
											resourceProvider.getContextPath(),
											packet.getAddress()
													.getHostAddress(), key }));
						} catch (Throwable e) {
							resourceProvider.log(e);
						}
					}
					socket.leaveGroup(groupAddress.getAddress());
				} catch (Throwable localThrowable1) {
					localThrowable2 = localThrowable1;
					throw localThrowable1;
				} finally {
					if (socket != null)
						if (localThrowable2 != null)
							try {
								socket.close();
							} catch (Throwable x2) {
								localThrowable2.addSuppressed(x2);
							}
						else
							socket.close();
				}
			} catch (IOException e) {
				resourceProvider.log(e);
			}

		}
	}
}