package com.quqian.framework.service.query;

public abstract interface Paging
{
  public abstract int getCurrentPage();

  public abstract int getSize();
}