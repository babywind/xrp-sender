package com.quqian.framework.service.achieve.proxy;

import com.quqian.framework.data.sql.SQLConnectionProvider;
import com.quqian.framework.log.Logger;
import com.quqian.framework.resource.InitParameterProvider;

public abstract class SQLConnectionProviderProxy extends SQLConnectionProvider
{
  protected final SQLConnectionProvider connectionProvider;

  public SQLConnectionProviderProxy(InitParameterProvider parameterProvider, Logger logger, SQLConnectionProvider connectionProvider)
  {
    super(parameterProvider, logger);
    this.connectionProvider = connectionProvider;
  }

  public String getName() {
    return connectionProvider.getName();
  }

  public void close()
  {
  }

  public String prefixMatch(String value) {
    return connectionProvider.prefixMatch(value);
  }

  public String subfixMatch(String value) {
    return connectionProvider.subfixMatch(value);
  }

  public String allMatch(String value) {
    return connectionProvider.allMatch(value);
  }

  public int hashCode() {
    return connectionProvider.hashCode();
  }

  public boolean equals(Object obj) {
    return connectionProvider.equals(obj);
  }

  public String toString() {
    return connectionProvider.toString();
  }
}