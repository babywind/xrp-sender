package com.quqian.framework.http.achieve.service;

import com.quqian.framework.http.service.UserStatisticsManage;
import com.quqian.framework.service.ServiceFactory;
import com.quqian.framework.service.ServiceResource;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserStatisticsManageImpl extends AbstractHttpService implements
		UserStatisticsManage {
	public UserStatisticsManageImpl(ServiceResource serviceResource) {
		super(serviceResource);
	}

	public int getLoginCount(Date date) throws Throwable {
		try (Connection connection = getConnection()) {
			if (date == null) {
				try (PreparedStatement pstmt = connection
						.prepareStatement("SELECT COUNT(*) FROM _1034")) {
					try (ResultSet resultSet = pstmt.executeQuery()) {
						if (resultSet.next()) {
							return resultSet.getInt(1);
						}
					}
				}
			} else {
				try (PreparedStatement pstmt = connection
						.prepareStatement("SELECT F02 FROM _1035 WHERE F01 = ?")) {
					pstmt.setDate(1, date);
					try (ResultSet resultSet = pstmt.executeQuery()) {
						if (resultSet.next())
							return resultSet.getInt(1);
					}
				}
			}
		}

		return 0;
	}

	public int getOnlineCount() throws Throwable {
		Connection connection = getConnection();
		try (PreparedStatement pstmt = connection
				.prepareStatement("SELECT COUNT(*) FROM _1030 WHERE F04 IS NOT NULL AND F05 > CURRENT_TIMESTAMP()")) {
			try (ResultSet resultSet = pstmt.executeQuery()) {
				if (resultSet.next())
					return resultSet.getInt(1);
			}
		}
		return 0;
	}

	public int[] getOnlineHistory(Date date) throws Throwable {
		int[] values = new int[24];
		try (Connection connection = getConnection()) {
			if (date == null) {
				try (PreparedStatement pstmt = connection
						.prepareStatement("SELECT F02,F03 FROM _1036 WHERE F01 = CURRENT_DATE()")) {
					try (ResultSet resultSet = pstmt.executeQuery()) {
						if (resultSet.next())
							values[(resultSet.getInt(1) % 24)] = resultSet
									.getInt(2);
					}
				}

			} else {
				try (PreparedStatement pstmt = connection
						.prepareStatement("SELECT F02,F03 FROM _1036 WHERE F01 = ?")) {
					pstmt.setDate(1, date);
					try (ResultSet resultSet = pstmt.executeQuery()) {
						if (resultSet.next())
							values[(resultSet.getInt(1) % 24)] = resultSet
									.getInt(2);
					}
				}
			}
		}
		return values;
	}

	public int getLoginCount(Date date, String schemaName) throws Throwable {
		try (Connection connection = getConnection(schemaName)) {
			if (date == null) {
				try (PreparedStatement pstmt = connection
						.prepareStatement("SELECT COUNT(*) FROM _1034")) {
					try (ResultSet resultSet = pstmt.executeQuery()) {
						if (resultSet.next())
							return resultSet.getInt(1);
					}
				}

			} else {
				try (PreparedStatement pstmt = connection
						.prepareStatement("SELECT F02 FROM _1035 WHERE F01 = ?")) {
					pstmt.setDate(1, date);
					try (ResultSet resultSet = pstmt.executeQuery()) {
						if (resultSet.next())
							return resultSet.getInt(1);
					}
				}
			}
		}
		return 0;
	}

	public int getOnlineCount(String schemaName) throws Throwable {
		try (Connection connection = getConnection(schemaName)) {
			try (PreparedStatement pstmt = connection
					.prepareStatement("SELECT COUNT(*) FROM _1030 WHERE F04 IS NOT NULL AND F05 > CURRENT_TIMESTAMP()")) {
				try (ResultSet resultSet = pstmt.executeQuery()) {
					if (resultSet.next())
						return resultSet.getInt(1);
				}
			}
		}
		return 0;
	}

	public int[] getOnlineHistory(Date date, String schemaName)
			throws Throwable {
		int[] values = new int[24];
		try (Connection connection = getConnection(schemaName)) {
			if (date == null) {
				try (PreparedStatement pstmt = connection
						.prepareStatement("SELECT F02,F03 FROM _1036 WHERE F01 = CURRENT_DATE()")) {
					try (ResultSet resultSet = pstmt.executeQuery()) {
						while (resultSet.next())
							values[(resultSet.getInt(1) % 24)] = resultSet
									.getInt(2);
					}
				}
			} else {
				try (PreparedStatement pstmt = connection
						.prepareStatement("SELECT F02,F03 FROM _1036 WHERE F01 = ?")) {
					pstmt.setDate(1, date);
					try (ResultSet resultSet = pstmt.executeQuery()) {
						while (resultSet.next())
							values[(resultSet.getInt(1) % 24)] = resultSet
									.getInt(2);
					}
				}
			}
		}
		return values;
	}

	public static class RightManageFactory implements
			ServiceFactory<UserStatisticsManage> {
		public UserStatisticsManage newInstance(ServiceResource serviceResource) {
			return new UserStatisticsManageImpl(serviceResource);
		}
	}
}