package com.quqian.framework.config.achieve.service;

import com.quqian.framework.config.ConfigureProvider;
import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.config.entity.VariableBean;
import com.quqian.framework.config.entity.VariableType;
import com.quqian.framework.config.service.VariableManage;
import com.quqian.framework.config.service.VariableManage.VariableQuery;
import com.quqian.framework.data.sql.SQLConnectionProvider;
import com.quqian.framework.resource.ResourceNotFoundException;
import com.quqian.framework.service.ServiceFactory;
import com.quqian.framework.service.ServiceResource;
import com.quqian.framework.service.query.ArrayParser;
import com.quqian.framework.service.query.Paging;
import com.quqian.framework.service.query.PagingResult;
import com.quqian.util.StringHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class VariableManageImpl extends AbstractConfigService implements
		VariableManage {
	private static final ArrayParser<VariableBean> ARRAY_PARSER = new ArrayParser() {
		public VariableBean[] parse(ResultSet resultSet) throws SQLException {
			List variableBeans = null;
			while (resultSet.next()) {
				if (variableBeans == null) {
					variableBeans = new ArrayList();
				}
				VariableBean variableBean = new VariableManageImpl.VariableBeanImpl(
						resultSet.getString(1), resultSet.getString(2),
						resultSet.getString(3), resultSet.getString(4));

				variableBeans.add(variableBean);
			}
			return variableBeans == null ? new VariableBean[0]
					: (VariableBean[]) variableBeans
							.toArray(new VariableBean[variableBeans.size()]);
		}
	};

	public VariableManageImpl(ServiceResource serviceResource) {
		super(serviceResource);
	}

	public String getProperty(String key) throws ResourceNotFoundException,
			SQLException {
		if (StringHelper.isEmpty(key)) {
			return null;
		}
		String value = null;
		Connection connection = getConnection();
		Throwable localThrowable4 = null;
		try {
			PreparedStatement pstmt = connection
					.prepareStatement("SELECT F02 FROM _1010 WHERE F01 = ?");

			Throwable localThrowable5 = null;
			try {
				pstmt.setString(1, key);
				ResultSet resultSet = pstmt.executeQuery();
				Throwable localThrowable6 = null;
				try {
					if (resultSet.next())
						value = resultSet.getString(1);
				} catch (Throwable localThrowable1) {
					localThrowable6 = localThrowable1;
					throw localThrowable1;
				} finally {
					resultSet.close();
				}
			} catch (Throwable localThrowable2) {
				localThrowable5 = localThrowable2;
				throw localThrowable2;
			} finally {
				pstmt.close();
			}
		} catch (Throwable localThrowable3) {
			localThrowable4 = localThrowable3;
			throw localThrowable3;
		} finally {
			if (connection != null)
				if (localThrowable4 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable4.addSuppressed(x2);
					}
				else
					connection.close();
		}
		return value;
	}

	public void setProperty(String key, String value)
			throws ResourceNotFoundException, SQLException {
		if ((StringHelper.isEmpty(key)) || (StringHelper.isEmpty(value))) {
			return;
		}
		Connection connection = getConnection();
		Throwable localThrowable3 = null;
		try {
			PreparedStatement pstmt = connection
					.prepareStatement("UPDATE _1010 SET F02 = ? WHERE F01 = ?");

			Throwable localThrowable4 = null;
			try {
				pstmt.setString(1, value);
				pstmt.setString(2, key);
				pstmt.executeUpdate();
			} catch (Throwable localThrowable1) {
				localThrowable4 = localThrowable1;
				throw localThrowable1;
			} finally {
				pstmt.close();
			}
		} catch (Throwable localThrowable2) {
			localThrowable3 = localThrowable2;
			throw localThrowable2;
		} finally {
			if (connection != null)
				if (localThrowable3 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable3.addSuppressed(x2);
					}
				else
					connection.close();
		}
		((ConfigureProvider) serviceResource
				.getResource(ConfigureProvider.class)).invalidProperty(key);
	}

	public PagingResult<VariableBean> search(
			VariableManage.VariableQuery variableQuery, Paging paging)
			throws Throwable {
		StringBuilder builder = new StringBuilder(
				"SELECT F01, F02, F03, F04 FROM _1010 WHERE 1 = 1 ");

		ArrayList parameters = new ArrayList();
		SQLConnectionProvider connectionProvider = getConnectionProvider();
		if (variableQuery != null) {
			if (!StringHelper.isEmpty(variableQuery.getKey())) {
				builder.append(" AND F01 LIKE ?");
				parameters.add(connectionProvider.allMatch(variableQuery
						.getKey()));
			}

			if (!StringHelper.isEmpty(variableQuery.getValue())) {
				builder.append(" AND F02 LIKE ?");
				parameters.add(connectionProvider.allMatch(variableQuery
						.getValue()));
			}

			if (!StringHelper.isEmpty(variableQuery.getType())) {
				builder.append(" AND F03 = ?");
				parameters.add(variableQuery.getType());
			}
			if (!StringHelper.isEmpty(variableQuery.getDescription())) {
				builder.append(" AND F04 LIKE ?");
				parameters.add(connectionProvider.allMatch(variableQuery
						.getDescription()));
			}
		}

		Connection connection = getConnection();
		Throwable localThrowable2 = null;
		try {
			return selectPaging(connection, ARRAY_PARSER, paging,
					builder.toString(), parameters);
		} catch (Throwable localThrowable3) {
			localThrowable2 = localThrowable3;
			throw localThrowable3;
		} finally {
			if (connection != null)
				if (localThrowable2 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable2.addSuppressed(x2);
					}
				else
					connection.close();
		}
	}

	public VariableBean get(String key) throws Throwable {
		if (StringHelper.isEmpty(key)) {
			return null;
		}
		VariableBean value = null;
		Connection connection = getConnection();
		Throwable localThrowable4 = null;
		try {
			PreparedStatement pstmt = connection
					.prepareStatement("SELECT F01,F02,F03,F04 FROM _1010 WHERE F01 = ?");

			Throwable localThrowable5 = null;
			try {
				pstmt.setString(1, key);
				ResultSet resultSet = pstmt.executeQuery();
				Throwable localThrowable6 = null;
				try {
					if (resultSet.next())
						value = new VariableBeanImpl(resultSet.getString(1),
								resultSet.getString(2), resultSet.getString(3),
								resultSet.getString(4));
				} catch (Throwable localThrowable1) {
					localThrowable6 = localThrowable1;
					throw localThrowable1;
				} finally {
					resultSet.close();
				}
			} catch (Throwable localThrowable2) {
				localThrowable5 = localThrowable2;
				throw localThrowable2;
			} finally {
				pstmt.close();
			}
		} catch (Throwable localThrowable3) {
			localThrowable4 = localThrowable3;
			throw localThrowable3;
		} finally {
			if (connection != null)
				if (localThrowable4 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable4.addSuppressed(x2);
					}
				else
					connection.close();
		}
		return value;
	}

	public void synchronize() throws Throwable {
		SystemDefine systemDefine = serviceResource.getSystemDefine();
		VariableType[] variableTypes = systemDefine.getVariableTypes();
		if (variableTypes == null) {
			return;
		}
		Connection connection = getConnection();
		Throwable localThrowable5 = null;
		try {
			Throwable localThrowable6 = null;
			Set keys = new HashSet();
			{
				PreparedStatement pstmt = connection
						.prepareStatement("SELECT F01 FROM _1010");
				try {
					ResultSet resultSet = pstmt.executeQuery();
					Throwable localThrowable7 = null;
					try {
						while (resultSet.next())
							keys.add(resultSet.getString(1));
					} catch (Throwable localThrowable1) {
						localThrowable7 = localThrowable1;
						throw localThrowable1;
					} finally {
						resultSet.close();
					}
				} catch (Throwable localThrowable2) {
					localThrowable6 = localThrowable2;
					throw localThrowable2;
				} finally {
					pstmt.close();
				}
			}
			{
				PreparedStatement pstmt = connection
						.prepareStatement("INSERT IGNORE INTO _1010 SET F01 = ?, F02 = ?, F03 = ?, F04 = ?");
				localThrowable6 = null;
				try {
					boolean notEmpty = false;
					for (VariableType variableType : variableTypes) {
						VariableBean[] defalutVariables = variableType
								.getVariableBeans();
						if ((defalutVariables != null)
								&& (defalutVariables.length != 0)) {
							for (VariableBean defalutVariable : defalutVariables)
								if ((defalutVariable != null)
										&& (!StringHelper
												.isEmpty(defalutVariable
														.getKey()))
										&& (!StringHelper
												.isEmpty(defalutVariable
														.getValue()))
										&& (!keys.contains(defalutVariable
												.getKey()))) {
									pstmt.setString(1, defalutVariable.getKey());
									pstmt.setString(2,
											defalutVariable.getValue());
									pstmt.setString(3,
											defalutVariable.getType());
									pstmt.setString(4,
											defalutVariable.getDescription());
									pstmt.addBatch();
									notEmpty = true;
								}
						}
					}
					if (notEmpty)
						pstmt.executeBatch();
				} catch (Throwable localThrowable3) {
					localThrowable6 = localThrowable3;
					throw localThrowable3;
				} finally {
					pstmt.close();
				}
			}
		} catch (Throwable localThrowable4) {
			localThrowable5 = localThrowable4;
			throw localThrowable4;
		} finally {
			if (connection != null)
				if (localThrowable5 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable5.addSuppressed(x2);
					}
				else
					connection.close();
		}
	}

	public void reset() throws Throwable {
		Connection connection = getConnection();
		Throwable localThrowable4 = null;
		try {
			Throwable localThrowable5 = null;
			{
				PreparedStatement pstmt = connection
						.prepareStatement("DELETE FROM _1010 ");
				try {
					pstmt.execute();
				} catch (Throwable localThrowable1) {
					localThrowable5 = localThrowable1;
					throw localThrowable1;
				} finally {
					pstmt.close();
				}
			}
			SystemDefine systemDefine = serviceResource.getSystemDefine();
			VariableType[] variableTypes = systemDefine.getVariableTypes();
			if (variableTypes == null) {
				return;
			}
			{
				PreparedStatement pstmt = connection
						.prepareStatement("INSERT IGNORE INTO _1010 SET F01 = ?, F02 = ?, F03 = ?, F04 = ?");
				Throwable localThrowable6 = null;
				try {
					boolean notEmpty = false;
					for (VariableType variableType : variableTypes) {
						VariableBean[] defalutVariables = variableType
								.getVariableBeans();

						if ((defalutVariables != null)
								&& (defalutVariables.length != 0)) {
							for (VariableBean defalutVariable : defalutVariables)
								if ((defalutVariable != null)
										&& (!StringHelper
												.isEmpty(defalutVariable
														.getKey()))
										&& (!StringHelper
												.isEmpty(defalutVariable
														.getValue()))) {
									pstmt.setString(1, defalutVariable.getKey());
									pstmt.setString(2,
											defalutVariable.getValue());
									pstmt.setString(3,
											defalutVariable.getType());
									pstmt.setString(4,
											defalutVariable.getDescription());
									pstmt.addBatch();
									notEmpty = true;
								}
						}
					}
					if (notEmpty)
						pstmt.executeBatch();
				} catch (Throwable localThrowable2) {
					localThrowable6 = localThrowable2;
					throw localThrowable2;
				} finally {
					pstmt.close();
				}
			}
		} catch (Throwable localThrowable3) {
			localThrowable4 = localThrowable3;
			throw localThrowable3;
		} finally {
			if (connection != null)
				if (localThrowable4 != null)
					try {
						connection.close();
					} catch (Throwable x2) {
						localThrowable4.addSuppressed(x2);
					}
				else
					connection.close();
		}
	}

	private static class VariableBeanImpl implements VariableBean {
		protected final String key;
		protected final String value;
		protected final String type;
		protected final String desc;

		public VariableBeanImpl(String key, String value, String type,
				String desc) {
			this.key = key;
			this.value = value;
			this.type = type;
			this.desc = desc;
		}

		public String getType() {
			return type;
		}

		public String getKey() {
			return key;
		}

		public String getValue() {
			return value;
		}

		public String getDescription() {
			return desc;
		}
	}

	public static class RightManageFactory implements
			ServiceFactory<VariableManage> {
		public VariableManage newInstance(ServiceResource serviceResource) {
			return new VariableManageImpl(serviceResource);
		}
	}
}