package com.quqian.framework.message.achieve.email;

import com.quqian.framework.message.email.Extracter;
import com.quqian.framework.message.email.entity.EmailTask;
import com.quqian.framework.service.ServiceFactory;
import com.quqian.framework.service.ServiceResource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class EmailExtracterImpl extends AbstractEmailService implements
		Extracter {
	public EmailExtracterImpl(ServiceResource serviceResource) {
		super(serviceResource);
	}

	public EmailTask[] extract(int maxCount, int expiresMinutes)
			throws Throwable {
		if (maxCount <= 0) {
			return null;
		}
		if (expiresMinutes <= 0) {
			expiresMinutes = 30;
		}
		List<EmailTask> emailTasks = null;
		try (Connection connection = getConnection()) {
			try (PreparedStatement ps = connection
					.prepareStatement("SELECT F01,F02,F03,F05 FROM _1046 WHERE F07=? ORDER BY F06 ASC LIMIT 0,?")) {
				ps.setString(1, "W");
				ps.setInt(2, maxCount);
				try (ResultSet resultSet = ps.executeQuery()) {
					while (resultSet.next()) {
						if (emailTasks == null) {
							emailTasks = new ArrayList<EmailTask>();
						}
						EmailTask emailTask = new EmailTask();
						emailTask.id = resultSet.getLong(1);
						emailTask.subject = resultSet.getString(2);
						emailTask.content = resultSet.getString(3);
						emailTask.type = resultSet.getInt(4);
						emailTasks.add(emailTask);
					}
				}
			}

			if (emailTasks == null) {
				return null;
			}

			try (PreparedStatement ps = connection
					.prepareStatement("UPDATE _1046 SET F06=?,F07=? WHERE F01=?")) {
				long l = System.currentTimeMillis();
				for (Iterator<EmailTask> i$ = emailTasks.iterator(); i$
						.hasNext();) {
					EmailTask emailTask = (EmailTask) i$.next();
					ps.setTimestamp(1, new Timestamp(l + expiresMinutes * 60
							* 1000));

					ps.setString(2, "Z");
					ps.setLong(3, ((EmailTask) emailTask).id);
					ps.addBatch();
				}
				ps.executeBatch();
			}

			for (EmailTask emailTask : emailTasks) {
				try (PreparedStatement ps = connection
						.prepareStatement("SELECT F02 FROM _1047 WHERE F01=?")) {
					ps.setLong(1, emailTask.id);
					try (ResultSet resultSet = ps.executeQuery()) {
						List<String> addresses = null;
						while (resultSet.next()) {
							if (addresses == null) {
								addresses = new ArrayList<String>();
							}
							addresses.add(resultSet.getString(1));
						}
						emailTask.addresses = (addresses == null ? null
								: (String[]) addresses
										.toArray(new String[addresses.size()]));
					}
				}
			}
		}
		return emailTasks == null ? null : (EmailTask[]) emailTasks
				.toArray(new EmailTask[emailTasks.size()]);
	}

	public void mark(long id) throws Throwable {
		if (id <= 0L) {
			return;
		}
		try (Connection connection = getConnection()) {
			try (PreparedStatement ps = connection
					.prepareStatement("INSERT INTO _1048(F01,F02,F03,F04,F05) SELECT F01,F02,F03,F04,F05 FROM _1046 WHERE F01=?")) {
				ps.setLong(1, id);
				ps.addBatch();
				ps.execute();
			}
			try (PreparedStatement ps = connection
					.prepareStatement("DELETE FROM _1046 WHERE F01=?")) {
				ps.setLong(1, id);
				ps.execute();
			}

		}
	}

	public static class EmailExtracterFactory implements
			ServiceFactory<Extracter> {
		public Extracter newInstance(ServiceResource serviceResource) {
			return new EmailExtracterImpl(serviceResource);
		}
	}
}