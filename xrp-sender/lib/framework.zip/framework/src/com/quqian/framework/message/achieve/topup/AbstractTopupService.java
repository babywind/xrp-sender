package com.quqian.framework.message.achieve.topup;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.quqian.framework.config.SystemDefine;
import com.quqian.framework.data.sql.SQLConnectionProvider;
import com.quqian.framework.message.MessageProvider;
import com.quqian.framework.resource.ResourceNotFoundException;
import com.quqian.framework.service.AbstractService;
import com.quqian.framework.service.ServiceResource;
import com.quqian.framework.service.query.ItemParser;
import com.quqian.util.P2PConst;

public abstract class AbstractTopupService extends AbstractService {
	public AbstractTopupService(ServiceResource serviceResource) {
		super(serviceResource);
	}

	protected SQLConnectionProvider getConnectionProvider() {
		SystemDefine systemDefine = serviceResource.getSystemDefine();
		return (SQLConnectionProvider) serviceResource
				.getDataConnectionProvider(SQLConnectionProvider.class,
						systemDefine.getDataProvider(MessageProvider.class));
	}

	protected Connection getConnection() throws ResourceNotFoundException,
			SQLException {
		SystemDefine systemDefine = serviceResource.getSystemDefine();
		return ((SQLConnectionProvider) serviceResource
				.getDataConnectionProvider(SQLConnectionProvider.class,
						systemDefine.getDataProvider(MessageProvider.class)))
				.getConnection(P2PConst.DB_USER);
	}

	protected String selectString(Connection connection, String sql,
			Object... paramters) throws SQLException {
		final String decimal = "";
		return select(connection, new ItemParser<String>() {
			@Override
			public String parse(ResultSet resultSet) throws SQLException {
				if (resultSet.next()) {
					return resultSet.getString(1);
				}
				return decimal;
			}
		}, sql, paramters);
	}
}