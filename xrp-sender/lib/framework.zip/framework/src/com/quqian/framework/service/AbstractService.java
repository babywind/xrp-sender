package com.quqian.framework.service;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import com.quqian.framework.data.sql.SQLConnectionProvider;
import com.quqian.framework.resource.ResourceNotFoundException;
import com.quqian.framework.service.query.ArrayParser;
import com.quqian.framework.service.query.ItemParser;
import com.quqian.framework.service.query.Paging;
import com.quqian.framework.service.query.PagingResult;
import com.quqian.util.P2PConst;

public abstract class AbstractService implements Service {
	protected final ServiceResource serviceResource;

	public AbstractService(ServiceResource serviceResource) {
		this.serviceResource = serviceResource;
	}

	protected Connection getConnection(String db) throws ResourceNotFoundException, SQLException {
		return serviceResource.getDataConnectionProvider(SQLConnectionProvider.class, P2PConst.DB_MASTER_PROVIDER)
				.getConnection(db);
	}

	protected void execute(Connection connection, String sql, Object... parameters) throws SQLException {
		try (PreparedStatement pstmt = connection.prepareStatement(sql);) {
			serviceResource.setParameters(pstmt, parameters);
			pstmt.execute();
		}
	}

	protected void execute(Connection connection, String sql, Collection<Object> parameters) throws SQLException {
		try (PreparedStatement pstmt = connection.prepareStatement(sql);) {
			serviceResource.setParameters(pstmt, parameters);
			pstmt.execute();
		}
	}

	protected int insert(Connection connection, String sql, Object... parameters) throws SQLException {
		try (PreparedStatement pstmt = connection.prepareStatement(sql, 1);) {
			serviceResource.setParameters(pstmt, parameters);
			pstmt.execute();
			try (ResultSet resultSet = pstmt.getGeneratedKeys();) {
				if (resultSet.next()) {
					return resultSet.getInt(1);
				}
				return 0;
			}
		}
	}

	protected int insert(Connection connection, String sql, Collection<Object> parameters) throws SQLException {
		try (PreparedStatement pstmt = connection.prepareStatement(sql, 1);) {
			serviceResource.setParameters(pstmt, parameters);
			pstmt.execute();
			try (ResultSet resultSet = pstmt.getGeneratedKeys();) {
				if (resultSet.next()) {
					return resultSet.getInt(1);
				}
				return 0;
			}
		}
	}

	protected String selectString(String db, String sql, Object... paramters) throws SQLException {
		final String decimal = "";
		return select(getConnection(db), new ItemParser<String>() {
			@Override
			public String parse(ResultSet resultSet) throws SQLException {
				if (resultSet.next()) {
					return resultSet.getString(1);
				}
				return decimal;
			}
		}, sql, paramters);
	}

	protected BigDecimal selectBigDecimal(String db, String sql, Object... paramters) throws SQLException {
		final BigDecimal decimal = new BigDecimal(0);
		return select(getConnection(db), new ItemParser<BigDecimal>() {
			@Override
			public BigDecimal parse(ResultSet resultSet) throws SQLException {
				if (resultSet.next()) {
					return resultSet.getBigDecimal(1);
				}
				return decimal;
			}
		}, sql, paramters);
	}

	protected Integer selectInt(String db, String sql, Object... paramters) throws SQLException {
		final Integer decimal =0;
		return select(getConnection(db), new ItemParser<Integer>() {
			@Override
			public Integer parse(ResultSet resultSet) throws SQLException {
				if (resultSet.next()) {
					return resultSet.getInt(1);
				}
				return decimal;
			}
		}, sql, paramters);
	}

	protected <T> T select(Connection connection, ItemParser<T> parser, String sql, Collection<Object> parameters)
			throws SQLException {
		try (PreparedStatement pstmt = connection.prepareStatement(sql);) {
			serviceResource.setParameters(pstmt, parameters);
			try (ResultSet resultSet = pstmt.executeQuery();) {
				return parser.parse(resultSet);
			}
		}
	}

	protected <T> T select(Connection connection, ItemParser<T> parser, String sql, Object... parameters)
			throws SQLException {
		try (PreparedStatement pstmt = connection.prepareStatement(sql);) {
			serviceResource.setParameters(pstmt, parameters);
			try (ResultSet resultSet = pstmt.executeQuery();) {
				return parser.parse(resultSet);
			}
		}
	}

	protected <T> T[] selectAll(Connection connection, ArrayParser<T> parser, String sql, Collection<Object> parameters)
			throws SQLException {
		try (PreparedStatement pstmt = connection.prepareStatement(sql);) {
			serviceResource.setParameters(pstmt, parameters);
			try (ResultSet resultSet = pstmt.executeQuery();) {
				return parser.parse(resultSet);
			}
		}
	}

	protected <T> T[] selectAll(Connection connection, ArrayParser<T> parser, String sql, Object... parameters)
			throws SQLException {
		try (PreparedStatement pstmt = connection.prepareStatement(sql);) {
			serviceResource.setParameters(pstmt, parameters);
			try (ResultSet resultSet = pstmt.executeQuery();) {
				return parser.parse(resultSet);
			}
		}
	}

	protected <T> PagingResult<T> selectPaging(Connection connection, ArrayParser<T> parser, Paging paging, String sql,
			Object... parameters) throws SQLException {
		int size = paging == null ? 10 : paging.getSize();
		int currentPage = paging == null ? 1 : paging.getCurrentPage();
		if (currentPage <= 0) {
			currentPage = 1;
		}
		int itemCount = 0;
		int pageCount = 0;
		if (size <= 0) {
			size = 10;
		}
		StringBuilder buf = new StringBuilder("SELECT COUNT(*) FROM (");
		buf.append(sql).append(") AS _A");

		try (PreparedStatement pstmt = connection.prepareStatement(buf.toString());) {
			serviceResource.setParameters(pstmt, parameters);
			try (ResultSet resultSet = pstmt.executeQuery();) {
				if (resultSet.next()) {
					itemCount = resultSet.getInt(1);
					pageCount = (int) Math.ceil(itemCount * 1.0 / size);
					if (pageCount <= 0)
						pageCount = 1;
				} else {
					pageCount = 1;
					itemCount = 0;
					currentPage = 1;
				}
			}
		}

		if (currentPage > pageCount) {
			currentPage = pageCount;
		}
		buf.setLength(0);
		buf.append("SELECT * FROM (").append(sql).append(") AS _A LIMIT ").append((currentPage - 1) * size).append(", ")
				.append(size);

		String pagingSql = buf.toString();
		T[] items;
		try (PreparedStatement pstmt = connection.prepareStatement(pagingSql);) {

			serviceResource.setParameters(pstmt, parameters);
			try (ResultSet resultSet = pstmt.executeQuery();) {
				items = parser.parse(resultSet);
			}

		}
		return new PagingResultImpl<T>(size, currentPage, itemCount, pageCount, items);

	}

	protected <T> PagingResult<T> selectPaging(Connection connection, ArrayParser<T> parser, Paging paging, String sql,
			Collection<Object> parameters) throws SQLException {
		int size = paging == null ? 10 : paging.getSize();
		int currentPage = paging == null ? 1 : paging.getCurrentPage();
		if (currentPage <= 0) {
			currentPage = 1;
		}
		int itemCount = 0;
		int pageCount = 0;
		if (size <= 0) {
			size = 10;
		}
		StringBuilder buf = new StringBuilder("SELECT COUNT(*) FROM (");
		buf.append(sql).append(") AS _A");
		{
			try (PreparedStatement pstmt = connection.prepareStatement(buf.toString());) {
				serviceResource.setParameters(pstmt, parameters);
				try (ResultSet resultSet = pstmt.executeQuery();) {
					if (resultSet.next()) {
						itemCount = resultSet.getInt(1);
						pageCount = (int) Math.ceil(itemCount * 1.0 / size);
						if (pageCount <= 0)
							pageCount = 1;
					} else {
						pageCount = 1;
						itemCount = 0;
						currentPage = 1;
					}
				}
			}
		}
		if (currentPage > pageCount) {
			currentPage = pageCount;
		}
		buf.setLength(0);
		buf.append("SELECT * FROM (").append(sql).append(") AS _A LIMIT ").append((currentPage - 1) * size).append(", ")
				.append(size);

		String pagingSql = buf.toString();
		T[] items;
		try (PreparedStatement pstmt = connection.prepareStatement(pagingSql);) {

			serviceResource.setParameters(pstmt, parameters);
			try (ResultSet resultSet = pstmt.executeQuery();) {
				items = parser.parse(resultSet);
			}
		}
		return new PagingResultImpl<T>(size, currentPage, itemCount, pageCount, items);
	}

	private class PagingResultImpl<T> implements PagingResult<T> {
		private final int size;
		private final int currentPage;
		private final int itemCount;
		private final int pageCount;
		private final T[] items;

		public PagingResultImpl(int size, int currentPage, int itemCount, int pageCount, T[] items) {
			this.size = size;
			this.currentPage = currentPage;
			this.itemCount = itemCount;
			this.pageCount = pageCount;
			this.items = items;
		}

		public int getCurrentPage() {
			return currentPage;
		}

		public int getSize() {
			return size;
		}

		public int getItemCount() {
			return itemCount;
		}

		public int getPageCount() {
			return pageCount;
		}

		public T[] getItems() {
			return items;
		}
	}
}