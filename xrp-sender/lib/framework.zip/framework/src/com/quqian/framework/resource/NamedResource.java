package com.quqian.framework.resource;

public abstract class NamedResource extends Resource
{
  public NamedResource(ResourceProvider resourceProvider)
  {
    super(resourceProvider);
  }

  public abstract String getName();
}