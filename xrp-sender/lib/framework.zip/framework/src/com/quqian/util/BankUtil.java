package com.quqian.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BankUtil {

	public static boolean isBank(String binkName) {
		Pattern pattern = Pattern.compile("[\u4e00-\u9fa5]{4,30}");
		Matcher m = pattern.matcher(binkName);
		if(binkName.endsWith("银行")&&m.matches()){
			return true;
		}
		return false;
	}
	
	public static boolean checkBranchBank(String branchBank) {
		Pattern pattern = Pattern.compile("[\u4e00-\u9fa5]{4,30}");
		Matcher m = pattern.matcher(branchBank);
		if(m.matches()){
			return true;
		}
		return false;
	}
	/**
	 * 校验银行卡卡号
	 * 
	 * @param cardId
	 * @return
	 */
	public static boolean checkBankCard(String cardId) {
		if (cardId.trim().length() < 16) {
			return false;
		}
		char bit = getBankCardCheckCode(cardId.substring(0, cardId.length() - 1));
		if (bit == 'N') {
			return false;
		}
		return cardId.charAt(cardId.length() - 1) == bit;
	}

	protected static char getBankCardCheckCode(String nonCheckCodeCardId) {
		if (nonCheckCodeCardId == null || nonCheckCodeCardId.trim().length() == 0
				|| !nonCheckCodeCardId.matches("\\d+")) {
			// 如果传的不是数据返回N
			return 'N';
		}
		char[] chs = nonCheckCodeCardId.trim().toCharArray();
		int luhmSum = 0;
		for (int i = chs.length - 1, j = 0; i >= 0; i--, j++) {
			int k = chs[i] - '0';
			if (j % 2 == 0) {
				k *= 2;
				k = k / 10 + k % 10;
			}
			luhmSum += k;
		}
		return (luhmSum % 10 == 0) ? '0' : (char) ((10 - luhmSum % 10) + '0');
	}


}
