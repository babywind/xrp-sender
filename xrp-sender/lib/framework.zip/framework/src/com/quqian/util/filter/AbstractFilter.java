package com.quqian.util.filter;

import java.io.IOException;

public abstract class AbstractFilter
  implements Appendable
{
  protected final Appendable out;

  public AbstractFilter(Appendable out)
  {
    this.out = out;
  }

  public Appendable append(CharSequence csq) throws IOException
  {
    if ((csq == null) || (csq.length() == 0)) {
      return this;
    }
    append(csq, 0, csq.length());
    return this;
  }

  public Appendable append(CharSequence csq, int start, int end)
    throws IOException
  {
    if ((csq == null) || (start >= end) || (start >= csq.length()) || (end > csq.length()))
    {
      return this;
    }
    for (int index = start; index < end; index++) {
      append(csq.charAt(index));
    }
    return this;
  }
}