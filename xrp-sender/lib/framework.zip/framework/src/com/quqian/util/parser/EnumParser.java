package com.quqian.util.parser;

import com.quqian.util.StringHelper;

import java.lang.reflect.Array;

public class EnumParser {
	public static <E extends Enum<E>> E parse(Class<E> enumClass, String value) {
		if (StringHelper.isEmpty(value))
			return null;
		try {
			return Enum.valueOf(enumClass, value);
		} catch (IllegalArgumentException localIllegalArgumentException) {
		}
		return null;
	}

	public static <E extends Enum<E>> E[] parseArray(Class<E> enumClass,
			String[] values) {
		if ((values == null) || (values.length == 0)) {
			return null;
		}
		@SuppressWarnings("unchecked")
		E[] es = (E[]) Array.newInstance(enumClass, values.length);

		for (int i = 0; i < values.length; i++)
			if (values[i] != null) {
				try {
					es[i] = Enum.valueOf(enumClass, values[i]);
				} catch (IllegalArgumentException e) {
					es[i] = null;
				}
			}
		return es;
	}
}