package com.quqian.util.io;

import com.quqian.util.Formater;
import com.quqian.util.StringHelper;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Date;

public class CVSWriter
{
  protected Appendable out;
  protected transient boolean notFirst = false;

  public CVSWriter(Appendable out) {
    this.out = out;
  }

  public void newLine() throws IOException {
    notFirst = false;
    out.append('\r');
    out.append('\n');
  }

  public void write(String field) throws IOException {
    if (notFirst)
      out.append(',');
    else {
      notFirst = true;
    }
    if (!StringHelper.isEmpty(field))
    {
      out.append('"');
      int length = field.length();

      for (int index = 0; index < length; index++) {
        char ch = field.charAt(index);
        if (ch == '"') {
          out.append('"');
          out.append('"');
        } else {
          out.append(ch);
        }
      }
      out.append('"');
    }
  }

  public void write(Object field) throws IOException {
    if (field != null)
      write(field.toString());
  }

  public void write(Date field) throws IOException {
    if (field != null)
      write(Formater.formatDate(field));
  }

  public void write(Time field) throws IOException {
    if (field != null)
      write(Formater.formatTime(field));
  }

  public void write(Timestamp field) throws IOException {
    if (field != null)
      write(Formater.formatDateTime(field));
  }

  public void write(int field) throws IOException {
    write(Integer.toString(field));
  }

  public void write(double field) throws IOException {
    write(Double.toString(field));
  }

  public void write(BigDecimal field) throws IOException {
    if (field != null)
      write(Formater.formatAmount(field));
  }

  public void write(float field) throws IOException {
    write(Float.toString(field));
  }

  public void write(short field) throws IOException {
    write(Short.toString(field));
  }

  public void write(byte field) throws IOException {
    write(Byte.toString(field));
  }

  public void write(boolean field) throws IOException {
    write(field ? "true" : "false");
  }
}