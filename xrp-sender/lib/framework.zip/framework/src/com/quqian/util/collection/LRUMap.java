package com.quqian.util.collection;

import java.util.LinkedHashMap;
import java.util.Map;

public class LRUMap<K, V> extends LinkedHashMap<K, V> {
	private static final long serialVersionUID = -248574785443822095L;
	protected final int maxCapacity;

	public LRUMap(int maxCapacity) {
		super(1000, 0.75F, true);
		this.maxCapacity = maxCapacity;
	}

	protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
		return size() > maxCapacity;
	}
}