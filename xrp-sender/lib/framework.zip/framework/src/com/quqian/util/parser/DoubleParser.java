package com.quqian.util.parser;

import com.quqian.util.StringHelper;

public class DoubleParser
{
  public static double parse(String value)
  {
    if (StringHelper.isEmpty(value))
      return 0.0D;
    try
    {
      return Double.parseDouble(StringHelper.trim(value).replaceAll(",", ""));
    } catch (NumberFormatException e) {
    }
    return 0.0D;
  }

  public static double[] parseArray(String[] values)
  {
    if ((values == null) || (values.length == 0)) {
      return null;
    }
    double[] ds = new double[values.length];
    for (int i = 0; i < values.length; i++)
      if (!StringHelper.isEmpty(values[i]))
      {
        try
        {
          ds[i] = Double.parseDouble(StringHelper.trim(values[i]).replaceAll(",", ""));
        }
        catch (NumberFormatException e) {
          ds[i] = 0.0D;
        }
      }
    return ds;
  }

  public Double parseObject(String value) {
    return Double.valueOf(parse(value));
  }

  public static Double[] parseObjectArray(String[] values)
  {
    if ((values == null) || (values.length == 0)) {
      return null;
    }
    Double[] ds = new Double[values.length];
    for (int i = 0; i < values.length; i++)
      if (!StringHelper.isEmpty(values[i]))
      {
        try
        {
          ds[i] = Double.valueOf(values[i].replaceAll(",", ""));
        } catch (NumberFormatException e) {
          ds[i] = Double.valueOf(0.0D);
        }
      }
    return ds;
  }
}