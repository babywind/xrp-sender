package com.quqian.util.http;

import com.quqian.util.StringHelper;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

public class URLParameter {
	protected final String prefix;
	protected final boolean parameters;
	protected final StringBuilder builder = new StringBuilder();
	protected final int initialLenght;
	protected final String[] keys;
	protected final boolean multiSelect;
	private String charset = "UTF-8";
	private HttpServletRequest request;
	private Map<String, Set<String>> map = new HashMap<String, Set<String>>();

	public URLParameter(HttpServletRequest request) {
		this(request, null, false, new String[0]);
	}

	public URLParameter(HttpServletRequest request, String prefix) {
		this(request, prefix, false, new String[0]);
	}

	public URLParameter(HttpServletRequest request, String prefix,
			boolean multiSelect, String... keys) {
		this.request = request;

		this.prefix = (StringHelper.isEmpty(prefix) ? null : prefix);
		//parameters = (this.prefix != null);
		parameters = false;

		if (this.prefix != null) {
			builder.append(prefix);
		}
		this.request = request;
		initialLenght = builder.length();
		this.keys = keys;
		this.multiSelect = multiSelect;
		clear();
	}

	public void setCharset(String charset) {
		if (!StringHelper.isEmpty(charset))
			this.charset = charset;
	}

	public void set(String key, String value) {
		if ((StringHelper.isEmpty(key)) || (StringHelper.isEmpty(value))) {
			return;
		}
		Set list = (Set) map.get(key);
		if (list == null) {
			list = new LinkedHashSet(1);
			map.put(key, list);
		}
		if (multiSelect) {
			list.add(value);
		} else {
			list.clear();
			list.add(value);
		}
	}

	public boolean contains(String key) {
		Set set = (Set) map.get(key);
		return (set != null) && (set.size() > 0);
	}

	public boolean contains(String key, String value) {
		Set set = (Set) map.get(key);
		return (set != null) && (set.contains(value));
	}

	public String[] remove(String key) {
		Set list = (Set) map.get(key);
		String[] values = null;
		if ((list != null) && (list.size() > 0)) {
			values = (String[]) list.toArray(new String[list.size()]);
			list.clear();
		}
		return values;
	}

	public void remove(String key, String value) {
		Set list = (Set) map.get(key);
		if (list != null)
			list.remove(value);
	}

	public void clear() {
		map.clear();
		if ((keys != null) && (keys.length > 0) && (request != null))
			if (multiSelect)
				for (String key : keys) {
					String[] values = request.getParameterValues(key);
					if ((values != null) && (values.length != 0)) {
						Set valueList = (Set) map.get(key);
						if (valueList == null) {
							valueList = new LinkedHashSet(values.length);
							map.put(key, valueList);
						} else {
							valueList.clear();
						}
						for (String value : values)
							if (!StringHelper.isEmpty(value)) {
								valueList.add(value);
							}
					}
				}
			else
				for (String key : keys) {
					String value = request.getParameter(key);
					if (!StringHelper.isEmpty(value)) {
						Set valueList = (Set) map.get(key);
						if (valueList == null) {
							valueList = new LinkedHashSet(1);
							map.put(key, valueList);
						} else {
							valueList.clear();
						}
						valueList.add(value);
					}
				}
	}

	public String getQueryString() {
		if (map.size() <= 0) {
			return "";
		}
		StringBuilder builder = new StringBuilder();
		try {
			boolean hasParameters = false;
			for (Map.Entry entry : map.entrySet()) {
				Set<String> values = (Set<String>) entry.getValue();
				if ((values != null) && (values.size() != 0)) {
					String key = (String) entry.getKey();
					for (String value : values) {
						if (hasParameters) {
							builder.append('&');
						} else {
							builder.append('?');
							hasParameters = true;
						}
						builder.append(key).append('=')
								.append(URLEncoder.encode(value, charset));
					}
				}
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return builder.toString();
	}

	public String toString() {
		builder.setLength(initialLenght);
		try {
			boolean hasParameters = parameters;
			if (map.size() > 0)
				for (Map.Entry entry : map.entrySet()) {
					Set<String> values = (Set<String>) entry.getValue();
					if ((values != null) && (values.size() != 0)) {
						String key = (String) entry.getKey();
						for (String value : values) {
							if (hasParameters) {
								builder.append('&');
							} else {
								builder.append('?');
								hasParameters = true;
							}
							builder.append(key).append('=')
									.append(URLEncoder.encode(value, charset));
						}
					}
				}
			clear();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return builder.toString();
	}
}