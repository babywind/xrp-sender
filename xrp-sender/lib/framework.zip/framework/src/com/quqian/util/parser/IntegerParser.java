package com.quqian.util.parser;

import com.quqian.util.StringHelper;

public class IntegerParser
{
  public static int parse(Object value)
  {
    return value == null ? 0 : parse(value.toString(), 0);
  }

  public static Integer parseObject(Object value) {
    return Integer.valueOf(value == null ? Integer.valueOf(0).intValue() : parse(value.toString(), 0));
  }

  public static int parse(String value) {
    return parse(value, 0);
  }

  public static int parse(String value, int defaultValue) {
    if (StringHelper.isEmpty(value))
      return defaultValue;
    try
    {
      return Integer.parseInt(StringHelper.trim(value).replaceAll(",", ""));
    } catch (NumberFormatException e) {
    }
    return defaultValue;
  }

  public static int[] parseArray(String[] values)
  {
    if ((values == null) || (values.length == 0)) {
      return null;
    }
    int[] fs = new int[values.length];
    for (int i = 0; i < values.length; i++) {
      try {
        fs[i] = Integer.parseInt(StringHelper.trim(values[i]).replaceAll(",", ""));
      }
      catch (NumberFormatException e) {
        fs[i] = 0;
      }
    }
    return fs;
  }

  public static Integer parseObject(String value) {
    return Integer.valueOf(parse(value));
  }

  public static Integer[] parseObjectArray(String[] values) {
    if ((values == null) || (values.length == 0)) {
      return null;
    }
    Integer[] fs = new Integer[values.length];
    for (int i = 0; i < values.length; i++) {
      try {
        fs[i] = Integer.valueOf(StringHelper.trim(values[i]).replaceAll(",", ""));
      }
      catch (NumberFormatException e) {
        fs[i] = Integer.valueOf(0);
      }
    }
    return fs;
  }
}