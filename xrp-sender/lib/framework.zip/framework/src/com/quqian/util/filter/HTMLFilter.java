package com.quqian.util.filter;

import java.io.IOException;

public class HTMLFilter extends AbstractFilter
{
  public HTMLFilter(Appendable out)
  {
    super(out);
  }

  public Appendable append(char ch) throws IOException
  {
    if (Character.isISOControl(ch)) {
      return this;
    }
    switch (ch) {
    case '"':
    case '&':
    case '\'':
    case '<':
    case '>':
      out.append("&#");
      out.append(Integer.toString(ch));
      out.append(';');
      break;
    default:
      out.append(ch);
    }

    return this;
  }
}