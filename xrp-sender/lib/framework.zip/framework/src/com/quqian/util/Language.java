package com.quqian.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Hashtable;

public class Language {
	private Hashtable<String, LanProperty> lans = new Hashtable<String, LanProperty>();

	public final static String ZH_CN = "zh_cn";
	public final static String EN = "en";
	public final static String ZH_TW = "zh_tw";
	public static String DEFAULT_LANGUAGE = ZH_CN;
	private static volatile Language instance = null;

	private Language() {
		loadProerty();
	}

	public static Language getInstance() {
		if (instance == null) {
			synchronized (Language.class) {
				if (instance == null) {
					instance = new Language();
				}
			}
		}
		return instance;
	}

	public void loadProerty() {
		String p = "/WEB-INF/classes/lan.properties";
		String _p = "/lan.properties";
		try {
			try (InputStream is = (getClass().getResourceAsStream(p) != null ? getClass().getResourceAsStream(p)
					: getClass().getResourceAsStream(_p))) {
				String line = null;
				try (InputStreamReader isr = new InputStreamReader(is, "UTF-8")) {
					try (BufferedReader br = new BufferedReader(isr)) {
						ArrayList<LanProperty> list = new ArrayList<LanProperty>();
						while ((line = br.readLine()) != null) {
							if(line.indexOf('[') != -1&&line.indexOf(']') != -1){
								LanProperty lp = new LanProperty();
								line = line.replace("[", "").replace("]", "").trim();
								lans.put(line, lp);
								list.add(lp);
							}else{
								if (line.indexOf('=') != -1) {
									String[] s = line.split("=");
									if (s.length == 2) {
										if(list.size()>0){
											LanProperty lp = list.get(list.size()-1);
											for (Field f : lp.getClass().getFields()) {
												if (f.getName().equals(s[0].trim())) {
													f.set(lp, s[1]);
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public String get(String lan, String k) {
		try {
			if (lan == null) {
				lan = DEFAULT_LANGUAGE;
			}
			LanProperty lp = lans.get(getUnicode(k));
			String v = "";
			if (lp != null) {
				for (Field f : lp.getClass().getFields()) {
					if (f.getName().equals(lan)) {
						v = f.get(lp).toString();
					}
				}

				return StringHelper.isEmpty(v) ? k : v;
			}
			return k;
		} catch (Exception ex) {
			return k;
		}
	}

	class LanProperty {
		public String zh_cn = null;// 中文简体
		public String en = null;// 英文
		public String zh_tw = null;// 中文繁体
	}
	
	public static String getUnicode(String k){
		 char[] chars = k.toCharArray();
		    String returnStr = "";
		    for (int i = 0; i < chars.length; i++) {
		    	returnStr += "\\u" + Integer.toString(chars[i], 16);
		    }
			return returnStr;
	}
}
