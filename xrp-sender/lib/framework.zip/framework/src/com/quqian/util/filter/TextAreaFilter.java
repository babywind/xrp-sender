package com.quqian.util.filter;

import java.io.IOException;

public class TextAreaFilter extends AbstractFilter
{
  public TextAreaFilter(Appendable out)
  {
    super(out);
  }

  public Appendable append(char ch) throws IOException
  {
    switch (ch) {
    case '"':
    case '&':
    case '\'':
    case '<':
    case '>':
      out.append("&#");
      out.append(Integer.toString(ch));
      out.append(';');
      break;
    default:
      out.append(ch);
    }

    return this;
  }
}