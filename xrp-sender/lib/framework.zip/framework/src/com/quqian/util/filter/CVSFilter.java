package com.quqian.util.filter;

import java.io.IOException;

public class CVSFilter extends AbstractFilter
{
  public CVSFilter(Appendable out)
  {
    super(out);
  }

  public Appendable append(char ch) throws IOException
  {
    if (Character.isISOControl(ch)) {
      return this;
    }
    if (ch == '"') {
      out.append('"');
      out.append('"');
    }
    return this;
  }
}