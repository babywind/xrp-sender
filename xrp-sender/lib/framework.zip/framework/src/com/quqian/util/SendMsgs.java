package com.quqian.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMsgs {
	/**
	 * @param[0] 信息内容</br>
	 * @param[1] 发送地址/手机号</br>
	 * @param[2] 标题【可为空】</br>
	 * 
	 * @param parameter
	 */
	public static void sendMsg(String... parameter) {
		try {
			if (!StringHelper.isEmpty(parameter[1])) {
				if (parameter[1].indexOf('@') != -1) {
					if (parameter.length >= 3) {
						initEmail(parameter[0], parameter[1], parameter[2]);
					} else {
//						initEmail(parameter[0], parameter[1], "DabTrade");
						initEmail(parameter[0], parameter[1], "ALL-TOKEN全证网");
//						initEmail(parameter[0], parameter[1], "VVVEX");
//						initEmail(parameter[0], parameter[1], "S网");
					}
				} else {
					//sendSMS_5c(parameter[0], parameter[1]);
					sendSMS_mysubmail(parameter[0], parameter[1]);
				}
			}
		} catch (Exception e) {
			System.out.printf("发送信息失败,发送人:%s,发送内容%s\n", parameter[1], parameter[0]);
		}
	}

	public static void initEmail(String content, String emails, String title) throws Exception {
		/*Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());*/
		final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
		Properties props = System.getProperties();
		//props.setProperty("mail.host", "smtp.mxhichina.com");//阿里企业邮箱:smtp.mxhichina.com
//		props.setProperty("mail.host", "smtp.ym.163.com");//网易企业邮箱:smtp.exmail.qq.com
		props.setProperty("mail.host", "smtp.exmail.qq.com");//腾讯企业邮箱:smtp.exmail.qq.com
		props.setProperty("mail.smtp.socketFactory.class", SSL_FACTORY);
		props.setProperty("mail.smtp.socketFactory.fallback", "false");
		props.setProperty("mail.smtp.port", "465");
		props.setProperty("mail.smtp.socketFactory.port", "465");
		props.setProperty("mail.smtp.auth", "true");
		// Properties prop = new Properties();
		// prop.setProperty("mail.host", "smtp.z-trade.com");
		// prop.setProperty("mail.transport.protocol", "smtp");
		// prop.setProperty("mail.smtp.auth", "true");
		// 使用JavaMail发送邮件的5个步骤
		// 1、创建session
		// Session session = Session.getInstance(prop);
		// 建立邮件会话
		Session session = Session.getDefaultInstance(props, new Authenticator() {
			// 身份认证
			protected PasswordAuthentication getPasswordAuthentication() {
//				return new PasswordAuthentication("baigang@jingtum.com", "Jason9211");//dabtrade
//				return new PasswordAuthentication("service@utoken.vip", "ZSHadcex1688");//utoken
//				return new PasswordAuthentication("service1@all-token.com", "yhlqadmin1");//utoken
				return new PasswordAuthentication("all-token@dabland.cn", "Yhlqadmin1");//utoken
//				return new PasswordAuthentication("vvvex@qq.com", "vvvex0330");//vvvex
//				return new PasswordAuthentication("service@s.top", "Stop123456");//s.top
			}
		});
		// 开启Session的debug模式，这样就可以查看到程序发送Email的运行状态
		session.setDebug(true);
		// 2、通过session得到transport对象
		//Transport ts = session.getTransport();
		// 3、使用邮箱的用户名和密码连上邮件服务器，发送邮件时，发件人需要提交邮箱的用户名和密码给smtp服务器，用户名和密码都通过验证之后才能够正常发送邮件给收件人。
//		ts.connect("smtp.z-trade.com", "admin@z-trade.com", "Ztrade789");
		//ts.connect("service@utoken.vip", "ZSHadcex1688");
		// 4、创建邮件
		Message message = createSimpleMail(session, content, emails, title);
//		// 5、发送邮件
//		ts.sendMessage(message, message.getAllRecipients());
//		ts.close();
		//改为群发邮件
		//Transport.send(message);
		Transport.send(message, adds(emails));
	}

	public static MimeMessage createSimpleMail(Session session, String content, String emails, String title)
			throws Exception {
		// 创建邮件对象
		MimeMessage message = new MimeMessage(session);
		// 设置自定义发件人昵称
		String nick = "";
		try {
//			nick = javax.mail.internet.MimeUtility.encodeText("DabTrade");
			nick = javax.mail.internet.MimeUtility.encodeText("ALL-TOKEN全证网");
//			nick = javax.mail.internet.MimeUtility.encodeText("VVVEX");
//			nick = javax.mail.internet.MimeUtility.encodeText("S网");
		} catch (Exception e) {
			e.printStackTrace();
		}
		// 指明邮件的发件人
//		message.setFrom(new InternetAddress("baigang@jingtum.com", nick));//dabtrade
//		message.setFrom(new InternetAddress("service1@all-token.com", nick));//utoken
		message.setFrom(new InternetAddress("all-token@dabland.cn", nick));//utoken
//		message.setFrom(new InternetAddress("vvvex@qq.com", nick));//vvvex
//		message.setFrom(new InternetAddress("service@s.top", nick));//s.top
		
		// 指明邮件的收件人，现在发件人和收件人是一样的，那就是自己给自己发
		//message.setRecipient(Message.RecipientType.TO, new InternetAddress(Message.RecipientType.TO));
		//改为群发邮件
		message.setRecipients(Message.RecipientType.TO, adds(emails));
		//message.setRecipient(Message.RecipientType.TO, new InternetAddress(emails));
		// 邮件的标题
		message.setSubject(title);
		// 邮件的文本内容
		message.setContent(content, "text/html;charset=UTF-8");
		// 返回创建好的邮件对象
		return message;
	}

	/**
	 * 通过m.5c.com.cn短信平台发送短信（停用）
	 * 
	 * @param content	短信内容
	 * @param phone		手机号
	 * @throws Exception
	 */
	public static void sendSMS_5c(String content, String phone) throws Exception {
//		System.setProperty("sun.net.client.defaultConnectTimeout", "30000");
//		System.setProperty("sun.net.client.defaultReadTimeout", "30000");
//		StringBuffer buffer = new StringBuffer();
//		String encode = "UTF-8";
//		String username = "adcex";
//		String password_md5 = "41fa51c59ebced5485cd18ebb2795b45";
//		String mobile = phone;
//		String apikey = "0227dd6fc9af4da6493f4438032e59da";
//		try {
//			String contentUrlEncode = URLEncoder.encode(content, encode);
//			buffer.append("http://m.5c.com.cn/api/send/index.php?username=" + username + "&password_md5=" + password_md5
//					+ "&mobile=" + mobile + "&apikey=" + apikey + "&content=" + contentUrlEncode + "&encode=" + encode);
//			URL url = new URL(buffer.toString());
//			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//			connection.setRequestMethod("POST");
//			connection.setRequestProperty("Connection", "Keep-Alive");
//			BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
//			String result = reader.readLine();
//			System.out.printf("发送人：%s/t返回结果:%s/t/n", phone, result);
//		} catch (Exception e) {
//			throw e;
//		}
	}

	/**
	 * 通过赛邮短信平台发送短信
	 * 
	 * @param content	短信内容
	 * @param phone		手机号
	 * @throws Exception
	 */
	public static void sendSMS_mysubmail(String content, String phone) throws Exception {
		HashMap<String, Object> map = new HashMap<String, Object>();
		
//		//dabmall
//		String url = "https://api.mysubmail.com/message/send.json";
//		map.put("appid", "18173");
//		map.put("to", phone);
//		map.put("content", "【DabTrade】"+content);
//		map.put("signature", "507915e075ad27e678ca250633d35958");
//		String result = HttpRequest.sendPost(url, JsonUtil.GsonString(map));
//		System.out.printf("发送人：%s/t返回结果:%s/t/n", phone, result);
		
		//utoken
		String url = "https://api.mysubmail.com/message/send.json";
		map.put("appid", "21321");
		map.put("to", phone);
		map.put("content", "【ALL-TOKEN】"+content);// 短信模板内容：【UTOKEN】@var(txt)UTOKEN感谢您的使用。
		map.put("signature", "47c624e86b3b47aea24e0cd3f037a6d5");
		String result = HttpRequest.sendPost(url, JsonUtil.GsonString(map));
		System.out.printf("发送人：%s/t返回结果:%s/t/n", phone, result);
		
		//s.top
//		String url = "https://api.mysubmail.com/message/send.json";
//		map.put("appid", "22236");
//		map.put("to", phone);
//		map.put("content", "【S.TOP】"+content);
//		map.put("signature", "8a1034ebdf5d2f62ac39dbaf428b1070");
//		String result = HttpRequest.sendPost(url, JsonUtil.GsonString(map));
//		System.out.printf("发送人：%s/t返回结果:%s/t/n", phone, result);
		
		//vvvex.com
//		String url = "https://api.mysubmail.com/message/send.json";
//		map.put("appid", "22237");
//		map.put("to", phone);
//		map.put("content", "【VVVEX】"+content);
//		map.put("signature", "e4af7c2f1a3aac15e7bf4f7470cd075f");
//		String result = HttpRequest.sendPost(url, JsonUtil.GsonString(map));
//		System.out.printf("发送人：%s/t返回结果:%s/t/n", phone, result);
		
	}
	
	public static InternetAddress[] adds(String emails){
		if(emails!=null&&!emails.equals("")){
			try {
	             List<InternetAddress> list = new ArrayList<InternetAddress>();//不能使用string类型的类型，这样只能发送一个收件人
	             String [] median=emails.split(",");//对输入的多个邮件进行逗号分割
	             for(int i=0;i<median.length;i++){
	            	 list.add(new InternetAddress(median[i]));
	             }
	             InternetAddress[] address =(InternetAddress[])list.toArray(new InternetAddress[list.size()]);
	             return address;
	        } catch (AddressException e) {
	            e.printStackTrace();
	        }
		}
		return null;
	}
	
	public static void main(String[] args) {
		long begin = System.currentTimeMillis();
		SendMsgs.sendMsg("this is test ...","66171918@qq.com,baigang@jingtum.com","群发邮件测试！");
		long end = System.currentTimeMillis();
		System.out.println("time cost :-------------"+(end - begin)/1000);
	}
}
